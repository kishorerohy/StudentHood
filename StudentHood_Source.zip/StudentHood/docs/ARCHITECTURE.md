# StudentHood implementation notes

## One client, one backend

Expo Router supplies web/native routing. React Native components adapt to available width, rather than trying to identify a device brand. Phone widths use a compact header and bottom navigation; tablet widths add a sidebar; large screens add discovery panels. The official wordmark is the only header branding element.

Supabase Auth issues user sessions. Auth signup creates a profile through a database trigger. Postgres stores social content, memberships, applications and unread markers. Storage buckets are private. The client requests time-limited signed media URLs after storage RLS approves access.

`AppProvider` loads a current snapshot, subscribes to Postgres changes, batches refreshes and discards results from a previous signed-in user. Signing out clears media URL caches and user state. Foreground/reconnect/periodic refreshes catch gaps and renew signed URLs. Mutations run through the same API layer on every platform.

Without public configuration, a separately labeled sample preview loads illustrative content from `demo.ts`. Its changes are local AsyncStorage data. There is no simulated cross-device backend and no insertion of sample accounts into a configured database.

## Server permissions

Every application table enables row-level security. Client roles cannot write arbitrary Drops, thread memberships or group memberships. Ownership columns are immutable through restricted column grants. Definer RPCs pin their search path and derive the acting account from `auth.uid()`.

Peeps are unique per unordered pair. Pending requests are accepted only by the recipient. A direct Ping between accepted Peeps activates both participants; other conversations invite the recipient. Only active members can read/send messages or retrieve private Ping attachments. Invited users can see the request's metadata, but cannot see its messages before acceptance. Joining/leaving a group changes chat membership atomically.

Blocking is bidirectional for direct conversations and post/profile visibility. In shared group chats, messages from blocked authors are filtered; other members remain accessible. People who previously downloaded media retain those copies. Signed URLs can remain usable until their one-hour expiry even after permissions change; they are temporary bearer URLs, not an instant remote-deletion mechanism.

Drops can represent only likes, comments, Peeps, group joins and Gig activity. There is no message kind or message trigger. Ping unread counts and requests are computed separately. Native Ping push uses a server-only webhook secret and canonical database records; it does not trust a client-supplied recipient list.

Writes are throttled using server-controlled counters. Clients cannot reset limits by deleting content. Account deletion locks future writes/uploads, removes owned storage, then deletes the Auth account and cascades its social rows. Deleting a conversation creator removes that creator's direct/group threads and their history in this version.

## Deployment boundaries

The managed web host serves an Expo single-page export. The SQL database, Auth, Storage and server functions run in your Supabase project. Native applications are built and signed through your EAS/Apple/Google accounts. Client public configuration is compiled into each export/build; it cannot be supplied to an existing compiled static website by changing a runtime environment variable alone.

The optional `delete-account` and `ping-push` functions require backend deployment. Push additionally requires native provider credentials and receipt monitoring. The included push function is best effort, does not include message bodies, and can produce duplicate notifications on retries. Foreground in-app messages continue to work without push.

## Initial limits

- The timeline initially loads 40 posts and can request additional batches. The loaded directory is capped at 150 profiles; Hangs/Crews/Gigs initially load 60 each. Default API row limits also affect very large relation/count queries. This suits initial testing, not an unbounded social network.
- Search runs over loaded content. Counts are computed over rows returned by the backend. Add indexed server search, cursor-based per-section pagination and exact server aggregates before large-scale use.
- Chats load the latest 100 messages, with an earlier-message load control. Comments initially load up to 200. Profile/Saved tabs show posts currently loaded into the shared timeline.
- Scene uploads enforce file type/size but do not scan/transcode files, generate new thumbnails or create adaptive streams. The sample Scene is a labeled still cover; connected Scenes require real video files.
- Reports are stored for owner review. This version has no moderator console, automated content screening or automatic university-email verification.
- Gigs collect applications and decisions. No payments, contracts, escrow or commissions are processed.
- There is no offline write queue, background sync guarantee, end-to-end message encryption, recommendation algorithm or automatic message retention job. Messages are protected by authenticated transport and database/storage permissions.
- WebMCP read/navigation tools register only when the browser exposes `document.modelContext`. They share the normal route navigation and do not expose message content or perform writes. Browser WebMCP support was not available for runtime validation in this build environment.

## Verification

`tests/security.test.cjs` executes all migrations against PostgreSQL/PGlite with minimal mocked Supabase Auth and Storage schemas. It checks account creation, authenticated permissions, column immutability, author/file ownership, Scene video requirements, Ping privacy/request acceptance, Peep canonical relationships, group membership changes, blocking, Gig decisions, unread markers, Drops separation, throttling and deletion.

SQL tests do not exercise hosted API/WebSocket delivery, Auth email delivery, signed URL transport, Expo push or native signing. Web/native bundle exports verify compilation. Real device interaction and the guide's two-account checks are still required against your configured backend. Browser visual QA was unavailable in the managed preview environment; the build does not claim a screenshot-perfect device validation.
