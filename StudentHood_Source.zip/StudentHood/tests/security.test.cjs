const { test, before, beforeEach, after } = require('node:test');
const assert = require('node:assert/strict');
const { PGlite } = require('@electric-sql/pglite');
const fs = require('node:fs');
const path = require('node:path');
let db;
const a = '11111111-1111-4111-8111-111111111111',
  b = '22222222-2222-4222-8222-222222222222',
  c = '33333333-3333-4333-8333-333333333333';
async function as(user, role = 'authenticated') {
  await db.exec('reset role');
  await db.query("select set_config('test.user',$1,false)", [user ?? '']);
  await db.exec(`set role ${role}`);
}
async function admin() {
  await db.exec('reset role');
  await db.query("select set_config('test.user','',false)");
}
async function rows(sql, args = []) {
  return (await db.query(sql, args)).rows;
}
async function scalar(sql, args = []) {
  return Object.values((await rows(sql, args))[0])[0];
}
async function post(user = a) {
  await as(user);
  return scalar(
    "insert into public.posts(author_id,kind,body,city) values($1,'pulse','Campus life','Manchester') returning id",
    [user],
  );
}
async function ping() {
  await as(a);
  return scalar('select public.start_ping($1)', [b]);
}
before(async () => {
  db = new PGlite();
  await db.waitReady;
  await db.exec(`
 create role anon; create role authenticated; create role service_role bypassrls;
 create schema auth; create schema storage;
 create table auth.users(id uuid primary key,raw_user_meta_data jsonb default '{}'::jsonb);
 create function auth.uid() returns uuid language sql stable as $$ select nullif(current_setting('test.user',true),'')::uuid $$;
 grant usage on schema auth,storage to anon,authenticated,service_role;
 grant execute on function auth.uid() to anon,authenticated,service_role;
 create table storage.buckets(id text primary key,name text,public boolean,file_size_limit bigint,allowed_mime_types text[]);
 create table storage.objects(id uuid primary key default gen_random_uuid(),bucket_id text references storage.buckets,name text not null);
 alter table storage.objects enable row level security;
 grant select,insert,delete on storage.objects to authenticated;
 create publication supabase_realtime;
 `);
  const dir = path.join(__dirname, '../supabase/migrations');
  for (const file of fs
    .readdirSync(dir)
    .filter((f) => f.endsWith('.sql'))
    .sort())
    await db.exec(fs.readFileSync(path.join(dir, file), 'utf8'));
});
beforeEach(async () => {
  await admin();
  await db.exec('truncate auth.users cascade; truncate storage.objects');
  await db.query(
    'insert into auth.users(id,raw_user_meta_data) values($1,\'{"display_name":"Alex"}\'),($2,\'{"display_name":"Maya"}\'),($3,\'{"display_name":"Outsider"}\')',
    [a, b, c],
  );
});
after(async () => {
  await db.close();
});
test('signup creates a profile; anonymous callers cannot read posts or invoke Pings', async () => {
  assert.equal(await scalar('select count(*)::int from public.profiles'), 3);
  await as(null, 'anon');
  await assert.rejects(() => rows('select * from public.posts'), /permission denied/);
  await assert.rejects(() => rows('select public.start_ping($1)', [b]), /permission denied/);
});
test('only the owner can edit a profile; identifier columns cannot be changed', async () => {
  await as(a);
  assert.equal(
    (await rows("update public.profiles set bio='Hi' where id=$1 returning id", [b])).length,
    0,
  );
  await assert.rejects(
    () => rows('update public.profiles set id=$1 where id=$2', [c, a]),
    /permission denied/,
  );
  assert.equal(
    (await rows("update public.profiles set bio='My campus' where id=$1 returning id", [a])).length,
    1,
  );
});
test('posts cannot impersonate another account or attach another account’s file', async () => {
  await as(a);
  await assert.rejects(
    () =>
      rows("insert into public.posts(author_id,kind,body,city) values($1,'pulse','Spoof','X')", [
        b,
      ]),
    /Sign in as the author|row-level security/,
  );
  await assert.rejects(
    () =>
      rows(
        "insert into public.posts(author_id,kind,body,city,media_path,media_type) values($1,'pulse','Spoof','X',$2,'image')",
        [a, `${b}/photo.png`],
      ),
    /row-level security/,
  );
});
test('a Scene requires a video, and a client cannot insert a forged Drop', async () => {
  await as(a);
  await assert.rejects(
    () =>
      rows(
        "insert into public.posts(author_id,kind,body,city,media_path,media_type) values($1,'scene','Photo scene','X',$2,'image')",
        [a, `${a}/photo.png`],
      ),
    /check constraint/,
  );
  await assert.rejects(
    () => rows("insert into public.drops(recipient_id,kind,title) values($1,'peep','Forged')", [a]),
    /permission denied/,
  );
});
test('uninvited users cannot read, join, or inject private Pings', async () => {
  const t = await ping();
  await as(a);
  await rows("insert into public.messages(thread_id,author_id,body) values($1,$2,'Hello')", [t, a]);
  await as(c);
  assert.equal((await rows('select * from public.messages')).length, 0);
  assert.equal((await rows('select * from public.threads')).length, 0);
  await assert.rejects(
    () => rows('insert into public.thread_members(thread_id,user_id) values($1,$2)', [t, c]),
    /permission denied/,
  );
  await assert.rejects(
    () =>
      rows("insert into public.messages(thread_id,author_id,body) values($1,$2,'Intrusion')", [
        t,
        c,
      ]),
    /row-level security/,
  );
  await assert.rejects(() => rows('select public.mark_ping_read($1)', [t]), /Ping unavailable/);
});
test('Ping requests hide messages until the invited user accepts', async () => {
  const t = await ping();
  await as(a);
  await rows(
    "insert into public.messages(thread_id,author_id,body) values($1,$2,'Private hello')",
    [t, a],
  );
  await assert.rejects(
    () => rows('select public.respond_ping($1,true)', [t]),
    /request unavailable/,
  );
  await as(b);
  assert.equal((await rows('select * from public.messages')).length, 0);
  assert.equal((await rows('select * from public.ping_inbox()'))[0].status, 'invited');
  await assert.rejects(
    () =>
      rows("insert into public.messages(thread_id,author_id,body) values($1,$2,'Before accept')", [
        t,
        b,
      ]),
    /row-level security/,
  );
  await rows('select public.respond_ping($1,true)', [t]);
  assert.equal((await rows('select * from public.messages')).length, 1);
});
test('accepting a Peep is recipient-only and creates one canonical relationship', async () => {
  await as(a);
  const request = await scalar('select public.request_peep($1)', [b]);
  assert.equal(await scalar('select public.request_peep($1)', [b]), request);
  await assert.rejects(
    () => rows('select public.respond_peep($1,true)', [request]),
    /request unavailable/,
  );
  await as(b);
  await rows('select public.respond_peep($1,true)', [request]);
  assert.equal(await scalar('select public.request_peep($1)', [a]), request);
  const t = await scalar('select public.start_ping($1)', [a]);
  await as(a);
  assert.equal(
    await scalar('select status from public.thread_members where thread_id=$1 and user_id=$2', [
      t,
      a,
    ]),
    'active',
  );
});
test('likes create social Drops; Ping messages and requests never create Drops', async () => {
  const p = await post();
  await as(b);
  await rows('insert into public.post_likes(post_id,user_id) values($1,$2)', [p, b]);
  await as(a);
  assert.equal(await scalar("select count(*)::int from public.drops where kind='post_like'"), 1);
  const t = await ping();
  await rows("insert into public.messages(thread_id,author_id,body) values($1,$2,'No Drop')", [
    t,
    a,
  ]);
  await admin();
  assert.equal(await scalar('select count(*)::int from public.drops'), 1);
});
test('joining and leaving a Crew changes group chat access on the server', async () => {
  await as(a);
  const g = await scalar("select public.create_crew('Camera crew','Photo walks')");
  const t = await scalar('select thread_id from public.crews where id=$1', [g]);
  await as(b);
  await assert.rejects(
    () => rows('insert into public.crew_members(crew_id,user_id) values($1,$2)', [g, b]),
    /permission denied/,
  );
  await rows("select public.join_group($1,'crew',true)", [g]);
  await rows("insert into public.messages(thread_id,author_id,body) values($1,$2,'Joined!')", [
    t,
    b,
  ]);
  await rows("select public.join_group($1,'crew',false)", [g]);
  assert.equal((await rows('select * from public.messages where thread_id=$1', [t])).length, 0);
  await as(a);
  await assert.rejects(
    () => rows("select public.join_group($1,'crew',false)", [g]),
    /creator must delete/,
  );
});
test('blocking prevents direct conversation access and hides blocked posts', async () => {
  const p = await post(a),
    t = await ping();
  await as(b);
  await rows('select public.respond_ping($1,true)', [t]);
  await rows('insert into public.blocks(blocker_id,blocked_id) values($1,$2)', [b, a]);
  assert.equal((await rows('select * from public.posts where id=$1', [p])).length, 0);
  assert.equal((await rows('select * from public.threads where id=$1', [t])).length, 0);
  await as(a);
  await assert.rejects(() => rows('select public.start_ping($1)', [b]), /Ping unavailable/);
  await assert.rejects(
    () =>
      rows("insert into public.messages(thread_id,author_id,body) values($1,$2,'Blocked')", [t, a]),
    /row-level security/,
  );
});
test('private Ping attachment paths enforce ownership and active membership', async () => {
  const t = await ping(),
    name = `${a}/${t}/photo.png`;
  await as(a);
  await rows("insert into storage.objects(bucket_id,name) values('ping-files',$1)", [name]);
  await as(b);
  assert.equal((await rows('select * from storage.objects')).length, 0);
  await rows('select public.respond_ping($1,true)', [t]);
  assert.equal((await rows('select * from storage.objects')).length, 1);
  await as(c);
  assert.equal((await rows('select * from storage.objects')).length, 0);
  await assert.rejects(
    () =>
      rows("insert into storage.objects(bucket_id,name) values('ping-files',$1)", [
        `${c}/${t}/bad.png`,
      ]),
    /row-level security/,
  );
  await as(b);
  await assert.rejects(
    () =>
      rows("insert into storage.objects(bucket_id,name) values('avatars',$1)", [`${a}/spoof.png`]),
    /row-level security/,
  );
});
test('only the Gig owner can accept an application', async () => {
  await as(a);
  const g = await scalar(
    "insert into public.gigs(creator_id,title,description,city,amount) values($1,'Tutor','Maths tutor','Manchester',18) returning id",
    [a],
  );
  await as(b);
  const application = await scalar(
    "insert into public.gig_applications(gig_id,applicant_id,body) values($1,$2,'I can help') returning id",
    [g, b],
  );
  assert.equal(
    (
      await rows("update public.gig_applications set status='accepted' where id=$1 returning id", [
        application,
      ])
    ).length,
    0,
  );
  await as(c);
  assert.equal((await rows('select * from public.gig_applications')).length, 0);
  await as(a);
  await rows("update public.gig_applications set status='accepted' where id=$1", [application]);
  await as(b);
  assert.equal(
    await scalar('select status from public.gig_applications where id=$1', [application]),
    'accepted',
  );
});
test('read markers clear unread counts without granting outsiders access', async () => {
  const t = await ping();
  await as(b);
  await rows('select public.respond_ping($1,true)', [t]);
  await as(a);
  await rows("insert into public.messages(thread_id,author_id,body) values($1,$2,'New Ping')", [
    t,
    a,
  ]);
  await as(b);
  assert.equal(
    Number(await scalar('select unread_count from public.ping_inbox() where id=$1', [t])),
    1,
  );
  await rows('select public.mark_ping_read($1)', [t]);
  assert.equal(
    Number(await scalar('select unread_count from public.ping_inbox() where id=$1', [t])),
    0,
  );
  await assert.rejects(
    () => rows("update public.thread_members set status='active' where thread_id=$1", [t]),
    /permission denied/,
  );
});
test('write throttling uses server timestamps and rejects the seventh post', async () => {
  await as(a);
  for (let i = 0; i < 6; i++)
    await rows(
      "insert into public.posts(author_id,kind,body,city,created_at) values($1,'pulse','Hello','Manchester','2000-01-01')",
      [a],
    );
  assert.equal(
    await scalar("select count(*)::int from public.posts where created_at>'2000-01-02'"),
    6,
  );
  await assert.rejects(() => post(a), /Too many requests/);
});
test('deleting posts cannot reset the write limit', async () => {
  for (let i = 0; i < 6; i++) await post(a);
  await rows('delete from public.posts where author_id=$1', [a]);
  await assert.rejects(() => post(a), /Too many requests/);
  await assert.rejects(() => rows('select * from public.write_counters'), /permission denied/);
});
test('account deletion blocks writes from old tokens including storage', async () => {
  await admin();
  await rows('update public.profiles set deleting_at=now() where id=$1', [a]);
  await as(a);
  await assert.rejects(() => post(a), /deletion is in progress/);
  await assert.rejects(
    () => rows("update public.profiles set bio='Still posting' where id=$1", [a]),
    /deletion is in progress/,
  );
  await assert.rejects(
    () =>
      rows("insert into storage.objects(bucket_id,name) values('avatars',$1)", [`${a}/new.png`]),
    /row-level security/,
  );
  await assert.rejects(
    () => rows('update public.profiles set deleting_at=null where id=$1', [a]),
    /permission denied/,
  );
});
test('profile deletion cascades social content and private memberships', async () => {
  await post(a);
  const t = await ping();
  await as(a);
  await rows("insert into public.messages(thread_id,author_id,body) values($1,$2,'Hello')", [t, a]);
  await admin();
  await rows('delete from auth.users where id=$1', [a]);
  assert.equal(await scalar('select count(*)::int from public.posts'), 0);
  assert.equal(await scalar('select count(*)::int from public.messages'), 0);
  assert.equal(await scalar('select count(*)::int from public.threads'), 0);
});
