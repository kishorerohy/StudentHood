import React, { useEffect, useState } from 'react';
import { View, Image, Platform } from 'react-native';
import * as ImagePicker from 'expo-image-picker';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useApp } from '../lib/AppProvider';
import * as api from '../lib/api';
import { client } from '../lib/supabase';
import { enablePingPush, disablePingPush, removeCurrentPush } from '../lib/push';
import type { Post, Profile, Group, Gig, Comment, Application } from '../lib/types';
import { Avatar, Txt, Row, Card, Button, Field, color, Empty } from './ui';
import { Tabs, ProfilePage, id, age, useAction, type Navigate, type OpenDialog } from './Hub';

type CreateType = 'Pulse' | 'Scene' | 'Hang' | 'Crew' | 'Gig';
export type Dialog =
  | { kind: 'create'; preset?: CreateType }
  | { kind: 'profile'; item: Profile }
  | { kind: 'edit'; item: Profile }
  | { kind: 'comments'; item: Post }
  | { kind: 'post'; item: Post }
  | { kind: 'group'; item: Group; type: 'Hangs' | 'Crews' }
  | { kind: 'gig'; item: Gig }
  | { kind: 'apply'; item: Gig }
  | { kind: 'applications'; item: Gig }
  | { kind: 'settings' }
  | { kind: 'setup' };
type Props = {
  dialog: Dialog;
  close: () => void;
  go: Navigate;
  open: OpenDialog;
};
export function Dialogs({ dialog: d, close, go, open }: Props) {
  if (d.kind === 'create') return <Create preset={d.preset} close={close} go={go} />;
  if (d.kind === 'profile')
    return <PeepProfile person={d.item} go={go} open={open} close={close} />;
  if (d.kind === 'edit') return <EditProfile person={d.item} close={close} />;
  if (d.kind === 'comments') return <Comments post={d.item} />;
  if (d.kind === 'settings') return <Settings close={close} />;
  if (d.kind === 'setup')
    return (
      <View style={{ gap: 13 }}>
        <Txt size={19} weight="700">
          One app. One live backend.
        </Txt>
        <Txt muted>
          The preview uses sample data on this device. Real accounts, shared posts and Pings work
          after you connect your own Supabase project.
        </Txt>
        <Txt muted>
          Download the source and follow BUILD_GUIDE.md: create a project, run both database
          migrations, copy its URL and publishable key into .env, then rebuild.
        </Txt>
        <Txt size={12} style={{ color: color.purple }}>
          Never put the service role key in the app or website.
        </Txt>
      </View>
    );
  if (d.kind === 'apply') return <Apply gig={d.item} close={close} />;
  if (d.kind === 'applications') return <Applications gig={d.item} />;
  return <Manage dialog={d} close={close} />;
}
async function chooseMedia(videos = false) {
  if (videos && Platform.OS === 'ios') {
    const { granted } = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (!granted) throw new Error('Allow photo library access to select your video.');
  }
  const result = await ImagePicker.launchImageLibraryAsync({
    mediaTypes: videos ? ['videos'] : ['images'],
    allowsEditing: false,
    quality: 1,
  });
  return result.canceled ? undefined : result.assets[0];
}
function Create({
  preset = 'Pulse',
  close,
  go,
}: {
  preset?: CreateType;
  close: () => void;
  go: Navigate;
}) {
  const { data, perform } = useApp();
  const [type, setType] = useState<CreateType>(preset),
    [body, setBody] = useState(''),
    [title, setTitle] = useState(''),
    [location, setLocation] = useState(''),
    [date, setDate] = useState(''),
    [amount, setAmount] = useState(''),
    [currency, setCurrency] = useState('GBP'),
    [asset, setAsset] = useState<ImagePicker.ImagePickerAsset | undefined>(),
    [busy, setBusy] = useState(false),
    [error, setError] = useState('');
  const submit = async () => {
    setError('');
    setBusy(true);
    try {
      const now = new Date().toISOString(),
        newId = id();
      if (type === 'Pulse' || type === 'Scene') {
        if (type === 'Scene' && asset?.type !== 'video')
          throw new Error('Choose a video for your Scene.');
        if (!body.trim() && !asset) throw new Error('Write something or attach a photo.');
        await perform(
          () => api.createPost(data.me, body, type === 'Scene' ? 'scene' : 'pulse', asset),
          (s) => ({
            ...s,
            posts: [
              {
                id: newId,
                author_id: s.me.id,
                kind: type === 'Scene' ? 'scene' : 'pulse',
                body: body.trim(),
                city: s.me.city,
                university: s.me.university,
                media_path: null,
                media_type: asset?.type === 'video' ? 'video' : asset ? 'image' : null,
                media_url: asset?.uri,
                likes: 0,
                comments: 0,
                liked: false,
                saved: false,
                created_at: now,
              },
              ...s.posts,
            ],
          }),
        );
      } else {
        if (!title.trim()) throw new Error('Add a title.');
        if (type === 'Gig') {
          if (
            !body.trim() ||
            amount.trim() === '' ||
            !Number.isFinite(Number(amount)) ||
            Number(amount) < 0
          )
            throw new Error('Add a description and a valid payment amount.');
          await perform(
            () => api.createGig(data.me, title.trim(), body.trim(), Number(amount), currency),
            (s) => ({
              ...s,
              gigs: [
                {
                  id: newId,
                  creator_id: s.me.id,
                  title: title.trim(),
                  description: body.trim(),
                  city: s.me.city,
                  university: s.me.university,
                  amount: Number(amount),
                  currency,
                  created_at: now,
                  applied: false,
                },
                ...s.gigs,
              ],
            }),
          );
        } else {
          const isHang = type === 'Hang';
          let starts: string | undefined;
          if (isHang) {
            if (!location.trim() || !date.trim() || Number.isNaN(new Date(date).getTime()))
              throw new Error('Add a location and a date, for example 2026-10-10T18:00.');
            starts = new Date(date).toISOString();
            if (new Date(starts).getTime() < Date.now())
              throw new Error('Choose a future date for your Hang.');
          }
          const args = isHang
            ? {
                title_input: title.trim(),
                description_input: body.trim(),
                location_input: location.trim(),
                starts_input: starts,
              }
            : { title_input: title.trim(), description_input: body.trim() };
          await perform(
            () => api.rpc(isHang ? 'create_hang' : 'create_crew', args),
            (s) => {
              const group: Group = {
                id: newId,
                creator_id: s.me.id,
                thread_id: `thread-${newId}`,
                title: title.trim(),
                description: body.trim(),
                city: s.me.city,
                university: s.me.university,
                location,
                starts_at: starts,
                created_at: now,
                members: 1,
                joined: true,
              };
              return {
                ...s,
                [isHang ? 'hangs' : 'crews']: [group, ...(isHang ? s.hangs : s.crews)],
                pings: [
                  {
                    id: group.thread_id,
                    kind: isHang ? 'hang' : 'crew',
                    title: group.title,
                    peer_id: null,
                    status: 'active',
                    last_read_at: now,
                    last_message: null,
                    last_at: now,
                    unread_count: 0,
                  },
                  ...s.pings,
                ],
              };
            },
          );
        }
      }
      close();
      go(
        type === 'Scene'
          ? 'Scenes'
          : type === 'Hang'
            ? 'Hangs'
            : type === 'Crew'
              ? 'Crews'
              : type === 'Gig'
                ? 'Gigs'
                : 'Pulse',
      );
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Unable to create.');
    } finally {
      setBusy(false);
    }
  };
  const pick = async () => {
    try {
      const selected = await chooseMedia(type === 'Scene');
      if (selected) setAsset(selected);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Unable to choose media.');
    }
  };
  return (
    <View style={{ gap: 16 }}>
      <Tabs
        values={['Pulse', 'Scene', 'Hang', 'Crew', 'Gig']}
        value={type}
        onChange={(t) => {
          setType(t as CreateType);
          setAsset(undefined);
          setError('');
        }}
      />
      {!['Pulse', 'Scene'].includes(type) && (
        <Field
          label="Title"
          accessibilityLabel="Title"
          placeholder={`Name your ${type}`}
          value={title}
          onChangeText={setTitle}
          maxLength={120}
        />
      )}
      <Field
        label={type === 'Scene' ? 'Caption' : type === 'Pulse' ? 'Your Pulse' : 'Description'}
        accessibilityLabel="Content"
        placeholder={
          type === 'Pulse' ? 'What’s happening in your hood?' : 'Tell your Peeps about it…'
        }
        value={body}
        onChangeText={setBody}
        multiline
        maxLength={type === 'Pulse' || type === 'Scene' ? 4000 : 3000}
      />
      {(type === 'Pulse' || type === 'Scene') && (
        <>
          <Row>
            <Button
              label={type === 'Scene' ? 'Choose video' : 'Add photo'}
              icon={type === 'Scene' ? 'Scenes' : 'ImagePlus'}
              subtle
              small
              onPress={() => void pick()}
            />
            {asset && <Button label="Remove" small subtle onPress={() => setAsset(undefined)} />}
          </Row>
          {asset && (
            <Card>
              <Txt size={12} muted>
                {asset.fileName || 'Selected media'} ·{' '}
                {asset.fileSize ? `${(asset.fileSize / 1048576).toFixed(1)} MB` : 'Ready to upload'}
              </Txt>
              {asset.type !== 'video' && (
                <Image
                  source={{ uri: asset.uri }}
                  style={{ height: 180, width: '100%', borderRadius: 12 }}
                  resizeMode="contain"
                />
              )}
            </Card>
          )}
          <Txt size={11} muted>
            {type === 'Scene' ? 'MP4 or MOV · up to 50 MB.' : 'JPEG, PNG or WebP · up to 50 MB.'}{' '}
            Photos upload without retouching or cropping.
          </Txt>
        </>
      )}
      {type === 'Hang' && (
        <>
          <Field
            label="Location"
            accessibilityLabel="Hang location"
            value={location}
            onChangeText={setLocation}
            maxLength={200}
          />
          <Field
            label="Date and time in your local timezone"
            accessibilityLabel="Hang date and time"
            placeholder="YYYY-MM-DDTHH:mm"
            value={date}
            onChangeText={setDate}
            autoCapitalize="none"
          />
          <Txt size={11} muted>
            Example: 2026-10-10T18:00. Members see the time in their own timezone.
          </Txt>
        </>
      )}
      {type === 'Gig' && (
        <>
          <Field
            label="Payment amount"
            accessibilityLabel="Gig payment"
            value={amount}
            onChangeText={setAmount}
            keyboardType="decimal-pad"
          />
          <Tabs values={['GBP', 'INR', 'USD', 'EUR']} value={currency} onChange={setCurrency} />
          <Txt size={11} muted>
            Applications are shared with the Gig owner. Arrange payment directly; StudentHood does
            not process payments.
          </Txt>
        </>
      )}
      {!!error && (
        <Txt size={13} style={{ color: '#ff9daa' }}>
          {error}
        </Txt>
      )}
      <Button
        disabled={busy}
        label={busy ? 'Publishing…' : type === 'Scene' ? 'Share Scene' : `Create ${type}`}
        onPress={() => void submit()}
      />
    </View>
  );
}
function EditProfile({ person: p, close }: { person: Profile; close: () => void }) {
  const { perform } = useApp();
  const [form, setForm] = useState({
      display_name: p.display_name,
      handle: p.handle,
      university: p.university,
      city: p.city,
      bio: p.bio,
    }),
    [asset, setAsset] = useState<ImagePicker.ImagePickerAsset | undefined>(),
    [busy, setBusy] = useState(false),
    [error, setError] = useState('');
  const field = (key: keyof typeof form, label: string, maxLength: number, multiline = false) => (
    <Field
      key={key}
      label={label}
      accessibilityLabel={label}
      value={form[key]}
      onChangeText={(value) => setForm({ ...form, [key]: value })}
      maxLength={maxLength}
      multiline={multiline}
      autoCapitalize={key === 'handle' ? 'none' : 'sentences'}
    />
  );
  const save = async () => {
    setError('');
    setBusy(true);
    try {
      if (!/^[a-z0-9_]{3,30}$/.test(form.handle))
        throw new Error('Handle: 3–30 lowercase letters, numbers or underscores.');
      if (!form.display_name.trim() || !form.city.trim()) throw new Error('Add a name and city.');
      await perform(
        () => api.updateProfile(p, form, asset),
        (s) => ({
          ...s,
          me: { ...s.me, ...form, avatar_url: asset?.uri ?? s.me.avatar_url },
        }),
      );
      close();
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Unable to save.');
    } finally {
      setBusy(false);
    }
  };
  return (
    <View style={{ gap: 14 }}>
      <Row>
        <Avatar person={{ ...p, avatar_url: asset?.uri ?? p.avatar_url }} size={64} />
        <Button
          label="Change photo"
          small
          subtle
          icon="Camera"
          onPress={() =>
            void chooseMedia()
              .then((a) => a && setAsset(a))
              .catch((e) => setError(e.message))
          }
        />
      </Row>
      {field('display_name', 'Display name', 80)}
      {field('handle', 'Handle', 30)}
      {field('university', 'University', 120)}
      {field('city', 'City', 80)}
      {field('bio', 'Bio', 500, true)}
      {!!error && <Txt style={{ color: '#ff9daa' }}>{error}</Txt>}
      <Button
        label={busy ? 'Saving…' : 'Save Profile'}
        disabled={busy}
        onPress={() => void save()}
      />
    </View>
  );
}
function Comments({ post }: { post: Post }) {
  const { data, demo, perform, revision } = useApp();
  const [rows, setRows] = useState<Comment[]>([]),
    [body, setBody] = useState(''),
    [error, setError] = useState(''),
    [busy, setBusy] = useState(false);
  useEffect(() => {
    let alive = true;
    (demo
      ? AsyncStorage.getItem(`studenthood:demo:comments:${post.id}`).then((s) =>
          s ? JSON.parse(s) : [],
        )
      : api.fetchComments(post.id)
    )
      .then((r) => {
        if (alive) setRows(r);
      })
      .catch((e) => setError(e.message));
    return () => {
      alive = false;
    };
  }, [post.id, revision, demo]);
  const send = async () => {
    setBusy(true);
    setError('');
    try {
      if (!body.trim()) throw new Error('Write a comment.');
      if (demo) {
        const next = [
          ...rows,
          {
            id: id(),
            post_id: post.id,
            author_id: data.me.id,
            body: body.trim(),
            created_at: new Date().toISOString(),
          },
        ];
        await AsyncStorage.setItem(`studenthood:demo:comments:${post.id}`, JSON.stringify(next));
        setRows(next);
      }
      await perform(
        () => api.addComment(post.id, data.me.id, body),
        (s) => ({
          ...s,
          posts: s.posts.map((p) => (p.id === post.id ? { ...p, comments: p.comments + 1 } : p)),
        }),
      );
      setBody('');
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Unable to send.');
    } finally {
      setBusy(false);
    }
  };
  return (
    <View style={{ gap: 16 }}>
      {demo && (
        <Txt size={11} muted>
          Sample activity counts. Comments you add stay in this device preview.
        </Txt>
      )}
      {rows.map((c) => (
        <Row key={c.id} style={{ alignItems: 'flex-start' }}>
          <Avatar
            person={[data.me, ...data.profiles].find((p) => p.id === c.author_id)}
            size={33}
          />
          <View style={{ flex: 1, gap: 3 }}>
            <Txt size={12} weight="700">
              {[data.me, ...data.profiles].find((p) => p.id === c.author_id)?.display_name ??
                'Student'}
            </Txt>
            <Txt size={13}>{c.body}</Txt>
            <Txt size={10} muted>
              {age(c.created_at)}
            </Txt>
          </View>
        </Row>
      ))}
      <Field
        placeholder="Add a comment…"
        accessibilityLabel="Comment"
        value={body}
        onChangeText={setBody}
        multiline
        maxLength={2000}
      />
      {!!error && <Txt style={{ color: '#ff9daa' }}>{error}</Txt>}
      <Button
        disabled={busy || !body.trim()}
        label={busy ? 'Sending…' : 'Post comment'}
        onPress={() => void send()}
      />
    </View>
  );
}
function PeepProfile({
  person,
  go,
  open,
  close,
}: {
  person: Profile;
  go: Navigate;
  open: OpenDialog;
  close: () => void;
}) {
  const { data, perform, setToast } = useApp(),
    act = useAction();
  const [reason, setReason] = useState(''),
    [reporting, setReporting] = useState(false);
  return (
    <View style={{ gap: 16 }}>
      <ProfilePage
        person={person}
        go={(p, t) => {
          close();
          go(p, t);
        }}
        open={open}
      />
      {person.id !== data.me.id && (
        <>
          <Row>
            <Button
              label="Report Peep"
              small
              subtle
              icon="Flag"
              onPress={() => setReporting(!reporting)}
            />
            <Button
              label="Block Peep"
              small
              subtle
              danger
              icon="Ban"
              onPress={() =>
                void act(async () => {
                  await perform(
                    () => api.block(data.me.id, person.id),
                    (s) => ({
                      ...s,
                      blocks: [...s.blocks, person.id],
                      profiles: s.profiles.filter((p) => p.id !== person.id),
                      posts: s.posts.filter((p) => p.author_id !== person.id),
                      pings: s.pings.filter((p) => p.peer_id !== person.id),
                    }),
                  );
                  close();
                  setToast('Peep blocked. You can unblock them in Settings.');
                })
              }
            />
          </Row>
          {reporting && (
            <>
              <Field
                label="What happened?"
                accessibilityLabel="Report reason"
                value={reason}
                onChangeText={setReason}
                multiline
                maxLength={2000}
              />
              <Button
                label="Send report"
                disabled={reason.trim().length < 3}
                onPress={() =>
                  void act(async () => {
                    await perform(() => api.report(data.me.id, 'profile', person.id, reason));
                    setToast('Report received.');
                    setReporting(false);
                  })
                }
              />
            </>
          )}
        </>
      )}
    </View>
  );
}
function Apply({ gig, close }: { gig: Gig; close: () => void }) {
  const { data, perform } = useApp();
  const [body, setBody] = useState(''),
    [busy, setBusy] = useState(false),
    [error, setError] = useState('');
  const submit = async () => {
    setBusy(true);
    try {
      if (!body.trim()) throw new Error('Tell the owner why you’re a good fit.');
      await perform(
        () => api.applyGig(gig.id, data.me.id, body.trim()),
        (s) => ({
          ...s,
          gigs: s.gigs.map((g) => (g.id === gig.id ? { ...g, applied: true } : g)),
        }),
      );
      close();
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Unable to apply.');
    } finally {
      setBusy(false);
    }
  };
  return (
    <View style={{ gap: 14 }}>
      <Txt size={18} weight="700">
        {gig.title}
      </Txt>
      <Txt muted>{gig.description}</Txt>
      <Field
        label="Your application"
        accessibilityLabel="Your application"
        value={body}
        onChangeText={setBody}
        multiline
        maxLength={2000}
      />
      {!!error && <Txt style={{ color: '#ff9daa' }}>{error}</Txt>}
      <Button
        label={busy ? 'Sending…' : 'Send application'}
        disabled={busy}
        onPress={() => void submit()}
      />
    </View>
  );
}
function Applications({ gig }: { gig: Gig }) {
  const { demo, data, perform, revision, setToast } = useApp(),
    act = useAction();
  const [rows, setRows] = useState<Application[]>([]);
  useEffect(() => {
    let alive = true;
    if (!demo)
      api
        .gigApplications(gig.id)
        .then((r) => {
          if (alive) setRows(r);
        })
        .catch((e) => setToast(e.message));
    return () => {
      alive = false;
    };
  }, [gig.id, demo, revision, setToast]);
  return (
    <View style={{ gap: 14 }}>
      {rows.map((a) => (
        <Card key={a.id}>
          <Txt weight="700">
            {data.profiles.find((p) => p.id === a.applicant_id)?.display_name ?? 'Student'}
          </Txt>
          <Txt>{a.body}</Txt>
          <Txt muted size={12}>
            {a.status}
          </Txt>
          {a.status === 'submitted' && (
            <Row>
              {(['accepted', 'declined'] as const).map((status) => (
                <Button
                  key={status}
                  small
                  subtle
                  label={status === 'accepted' ? 'Accept' : 'Decline'}
                  onPress={() =>
                    void act(() => perform(() => api.respondApplication(a.id, status)))
                  }
                />
              ))}
            </Row>
          )}
        </Card>
      ))}
      {!rows.length && (
        <Empty
          icon="Gigs"
          title="No applications yet"
          description="Applications to your Gig will appear here."
        />
      )}
    </View>
  );
}
function Manage({
  dialog: d,
  close,
}: {
  dialog: Extract<Dialog, { kind: 'post' | 'group' | 'gig' }>;
  close: () => void;
}) {
  const { data, perform, setToast } = useApp(),
    act = useAction();
  const [reason, setReason] = useState(''),
    [confirm, setConfirm] = useState(false);
  const target =
    d.kind === 'post'
      ? 'post'
      : d.kind === 'group'
        ? d.type === 'Hangs'
          ? 'hang'
          : 'crew'
        : 'gig';
  const own =
    d.kind === 'post' ? d.item.author_id === data.me.id : d.item.creator_id === data.me.id;
  const deletion = async () => {
    await perform(
      () =>
        d.kind === 'post'
          ? api.deletePost(d.item)
          : d.kind === 'group'
            ? api.rpc('delete_group', {
                resource_id: d.item.id,
                resource_type: target,
              })
            : api.deleteGig(d.item.id),
      (s) => {
        if (d.kind === 'post') return { ...s, posts: s.posts.filter((p) => p.id !== d.item.id) };
        if (d.kind === 'gig') return { ...s, gigs: s.gigs.filter((g) => g.id !== d.item.id) };
        return {
          ...s,
          [d.type === 'Hangs' ? 'hangs' : 'crews']: (d.type === 'Hangs' ? s.hangs : s.crews).filter(
            (g) => g.id !== d.item.id,
          ),
          pings: s.pings.filter((p) => p.id !== d.item.thread_id),
        };
      },
    );
    close();
  };
  return (
    <View style={{ gap: 15 }}>
      {own ? (
        <>
          <Txt muted>
            Deleting this {target} removes it from StudentHood.
            {d.kind === 'group' ? ' Its group conversation is also removed.' : ''}
          </Txt>
          <Button
            label={confirm ? 'Confirm delete' : 'Delete'}
            danger
            subtle
            icon="Trash2"
            onPress={() => (confirm ? void act(deletion) : setConfirm(true))}
          />
        </>
      ) : (
        <>
          <Field
            label="Report reason"
            accessibilityLabel="Report reason"
            placeholder="Tell us what happened…"
            value={reason}
            onChangeText={setReason}
            multiline
            maxLength={2000}
          />
          <Button
            label="Send report"
            icon="Flag"
            disabled={reason.trim().length < 3}
            onPress={() =>
              void act(async () => {
                await perform(() => api.report(data.me.id, target, d.item.id, reason));
                setToast('Report received.');
                close();
              })
            }
          />
        </>
      )}
    </View>
  );
}
function Settings({ close }: { close: () => void }) {
  const { data, demo, perform, setToast } = useApp(),
    act = useAction();
  const [confirmation, setConfirmation] = useState(''),
    [deleting, setDeleting] = useState(false);
  const deleteSelf = async () => {
    setDeleting(true);
    try {
      await api.deleteAccount();
      close();
    } catch (e) {
      setToast(e instanceof Error ? e.message : 'Unable to delete account.');
    } finally {
      setDeleting(false);
    }
  };
  return (
    <View style={{ gap: 18 }}>
      <Txt weight="700">Notifications</Txt>
      <Txt size={12} muted>
        Messages and requests appear only in Ping. Mobile push needs your EAS project and the
        optional Ping webhook.
      </Txt>
      <Button
        label="Enable Ping push"
        subtle
        icon="Ping"
        onPress={() =>
          void act(async () => {
            if (demo)
              throw new Error(
                'Connect the live backend and create a native development build first.',
              );
            await enablePingPush(data.me.id);
            setToast('Device registered for Ping push.');
          })
        }
      />
      <Button
        label="Turn off push on all devices"
        small
        subtle
        onPress={() =>
          void act(async () => {
            if (!demo) await disablePingPush(data.me.id);
            setToast('Push registrations removed.');
          })
        }
      />
      <Txt weight="700">Blocked Peeps</Txt>
      {data.blocks.map((peer) => (
        <Row key={peer}>
          <Txt size={12} muted style={{ flex: 1 }}>
            {peer}
          </Txt>
          <Button
            small
            subtle
            label="Unblock"
            onPress={() =>
              void act(() =>
                perform(
                  () => api.unblock(data.me.id, peer),
                  (s) => ({ ...s, blocks: s.blocks.filter((p) => p !== peer) }),
                ),
              )
            }
          />
        </Row>
      ))}
      {!data.blocks.length && (
        <Txt size={12} muted>
          No blocked Peeps.
        </Txt>
      )}
      {!demo && (
        <Button
          label="Sign out"
          subtle
          icon="LogOut"
          onPress={() =>
            void act(async () => {
              await removeCurrentPush(data.me.id);
              const { error } = await client().auth.signOut({ scope: 'local' });
              if (error) throw error;
              close();
            })
          }
        />
      )}
      {demo ? (
        <Txt muted size={12}>
          Sample changes are saved only on this device. Connecting your backend starts with real
          accounts and an empty feed.
        </Txt>
      ) : (
        <Card style={{ borderColor: '#5f3142' }}>
          <Txt weight="700">Delete account</Txt>
          <Txt size={12} muted>
            This permanently removes your profile, posts, owned groups and conversations, and
            uploaded files. Type DELETE to confirm.
          </Txt>
          <Field
            accessibilityLabel="Delete account confirmation"
            placeholder="DELETE"
            value={confirmation}
            onChangeText={setConfirmation}
            autoCapitalize="characters"
          />
          <Button
            label={deleting ? 'Deleting…' : 'Delete my account'}
            danger
            subtle
            disabled={confirmation !== 'DELETE' || deleting}
            onPress={() => void deleteSelf()}
          />
        </Card>
      )}
    </View>
  );
}
