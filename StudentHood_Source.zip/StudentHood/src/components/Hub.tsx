import React, { useCallback, useEffect, useState } from 'react';
import {
  View,
  ScrollView,
  Pressable,
  Modal,
  ActivityIndicator,
  useWindowDimensions,
  Platform,
  Image,
  Share,
  KeyboardAvoidingView,
} from 'react-native';
import { router, useLocalSearchParams } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { useApp } from '../lib/AppProvider';
import { pages, type Page, type Profile, type Post, type Group, type Gig } from '../lib/types';
import * as api from '../lib/api';
import {
  color,
  Txt,
  Row,
  Card,
  Button,
  Icon,
  IconButton,
  Avatar,
  Wordmark,
  Field,
  Empty,
  styles,
  Video,
} from './ui';
import { AuthScreen } from './auth';
import { PingPane } from './ping';
import { Dialogs, type Dialog } from './dialogs';

export type OpenDialog = (dialog: Dialog) => void;
export type Navigate = (page: Page, thread?: string) => void;
export const age = (value: string) => {
  const mins = Math.max(0, Math.floor((Date.now() - new Date(value).getTime()) / 60000));
  return mins < 1
    ? 'Just now'
    : mins < 60
      ? `${mins}m`
      : mins < 1440
        ? `${Math.floor(mins / 60)}h`
        : new Date(value).toLocaleDateString(undefined, {
            day: 'numeric',
            month: 'short',
          });
};
export const id = () => `sample-${Date.now()}-${Math.random().toString(16).slice(2)}`;
export function useAction() {
  const { setToast } = useApp();
  return useCallback(
    async (fn: () => Promise<unknown>) => {
      try {
        await fn();
      } catch (e) {
        setToast(e instanceof Error ? e.message : 'Please try again.');
      }
    },
    [setToast],
  );
}
export function useBeginPing(go: Navigate) {
  const { data, perform } = useApp(),
    act = useAction();
  return (peer: Profile) =>
    act(async () => {
      const demoId = `sample-ping-${peer.id}`;
      const result = await perform(
        () => api.rpc('start_ping', { peer: peer.id }),
        (s) => ({
          ...s,
          pings: s.pings.some((p) => p.peer_id === peer.id)
            ? s.pings
            : [
                {
                  id: demoId,
                  kind: 'direct',
                  title: peer.display_name,
                  peer_id: peer.id,
                  status: 'active',
                  last_read_at: new Date().toISOString(),
                  last_message: null,
                  last_at: new Date().toISOString(),
                  unread_count: 0,
                },
                ...s.pings,
              ],
        }),
      );
      go(
        'Ping',
        typeof result === 'string'
          ? result
          : (data.pings.find((p) => p.peer_id === peer.id)?.id ?? demoId),
      );
    });
}

export default function Hub() {
  const app = useApp(),
    { data, ready, loading, demo, session, setToast } = app;
  const params = useLocalSearchParams<{
    page?: string;
    thread?: string;
    scene?: string;
  }>();
  const found = pages.find((p) => p.toLowerCase() === params.page?.toLowerCase());
  const page: Page = params.scene ? 'Scenes' : (found ?? 'Pulse');
  const { width } = useWindowDimensions(),
    insets = useSafeAreaInsets(),
    compact = width < 760,
    wide = width >= 1180;
  const [dialog, setDialog] = useState<Dialog | null>(null);
  const go: Navigate = useCallback(
    (p, t) =>
      router.push({
        pathname: '/[page]',
        params: { page: p.toLowerCase(), ...(t ? { thread: t } : {}) },
      }),
    [],
  );
  const act = useAction();
  const pingCount = data.pings.reduce(
      (n, p) => n + p.unread_count + (p.status === 'invited' ? 1 : 0),
      0,
    ),
    dropCount = data.drops.filter((d) => !d.read_at).length;
  useEffect(() => {
    if (Platform.OS !== 'web') return;
    document.title = `${page} · StudentHood`;
  }, [page]);
  useEffect(() => {
    if (Platform.OS !== 'web') return;
    const context = (
      document as unknown as {
        modelContext?: {
          registerTool: (tool: unknown) => void;
          unregisterTool?: (name: string) => void;
        };
      }
    ).modelContext;
    if (!context) return;
    context.registerTool({
      name: 'studenthood_read_view',
      description:
        'Read the current StudentHood section and connection mode. Does not expose private message content.',
      inputSchema: { type: 'object', properties: {} },
      annotations: { readOnlyHint: true },
      execute: async () => ({
        content: [
          {
            type: 'text',
            text: JSON.stringify({
              page,
              mode: demo ? 'sample preview' : 'connected account',
              signedIn: !!session,
            }),
          },
        ],
      }),
    });
    context.registerTool({
      name: 'studenthood_navigate',
      description:
        'Open a StudentHood section. This only navigates; it does not send messages or create content.',
      inputSchema: {
        type: 'object',
        properties: { page: { type: 'string', enum: pages } },
        required: ['page'],
        additionalProperties: false,
      },
      execute: async (args: { page: string }) => {
        const target = pages.find((p) => p === args.page);
        if (!target) throw new Error('Unknown section');
        go(target);
        return { content: [{ type: 'text', text: `Opened ${target}` }] };
      },
    });
    return () => {
      context.unregisterTool?.('studenthood_read_view');
      context.unregisterTool?.('studenthood_navigate');
    };
  }, [page, demo, session, go]);
  if (!ready || loading)
    return (
      <View
        style={{
          flex: 1,
          backgroundColor: color.bg,
          alignItems: 'center',
          justifyContent: 'center',
          gap: 20,
        }}
      >
        <Wordmark width={230} />
        <ActivityIndicator color={color.purple} />
        <Txt muted>Loading your hood…</Txt>
      </View>
    );
  if (!demo && !session) return <AuthScreen />;
  const section =
    page === 'Ping' ? (
      <PingPane go={go} threadId={params.thread} open={setDialog} />
    ) : page === 'Drops' ? (
      <Drops go={go} />
    ) : page === 'Discover' ? (
      <Discover go={go} open={setDialog} />
    ) : page === 'Hangs' || page === 'Crews' ? (
      <Groups type={page} go={go} open={setDialog} />
    ) : page === 'Gigs' ? (
      <Gigs open={setDialog} />
    ) : page === 'Profile' ? (
      <ProfilePage person={data.me} go={go} open={setDialog} />
    ) : (
      <Feed scenes={page === 'Scenes'} sceneId={params.scene} go={go} open={setDialog} />
    );
  return (
    <View style={{ flex: 1, backgroundColor: color.bg, paddingTop: insets.top }}>
      {demo && (
        <Pressable
          accessibilityRole="button"
          accessibilityLabel="Preview setup information"
          onPress={() => setDialog({ kind: 'setup' })}
          style={{
            padding: 8,
            backgroundColor: '#22203b',
            alignItems: 'center',
          }}
        >
          <Txt size={11} style={{ textAlign: 'center', color: '#d4c9fc' }}>
            Sample preview · Connect your Supabase project to enable live accounts
          </Txt>
        </Pressable>
      )}
      <Row
        style={{
          borderBottomWidth: 1,
          borderBottomColor: color.line,
          paddingHorizontal: compact ? 16 : 28,
          paddingVertical: compact ? 4 : 6,
          justifyContent: 'space-between',
        }}
      >
        <Pressable
          accessibilityRole="button"
          accessibilityLabel="Go to Pulse"
          onPress={() => go('Pulse')}
        >
          <Wordmark width={compact ? 150 : 190} />
        </Pressable>
        {!compact && (
          <Row style={{ flex: 1, maxWidth: 450, marginHorizontal: 25 }}>
            <Pressable
              accessibilityRole="button"
              accessibilityLabel="Search your hood"
              onPress={() => go('Discover')}
              style={{
                flex: 1,
                backgroundColor: color.panel,
                borderWidth: 1,
                borderColor: color.line,
                borderRadius: 14,
                padding: 12,
                flexDirection: 'row',
                gap: 12,
              }}
            >
              <Icon name="Search" size={18} />
              <Txt size={13} muted>
                Search Peeps, Hangs, Crews…
              </Txt>
            </Pressable>
          </Row>
        )}
        <Row style={{ gap: 3 }}>
          {!compact && (
            <Txt size={11} muted>
              {demo ? 'Preview' : app.connected ? '● Live' : 'Reconnecting'}
            </Txt>
          )}
          <IconButton
            icon="Ping"
            label="Ping"
            badge={pingCount}
            active={page === 'Ping'}
            onPress={() => go('Ping')}
          />
          <IconButton
            icon="Drops"
            label="Drops"
            badge={dropCount}
            active={page === 'Drops'}
            onPress={() => go('Drops')}
          />
          {!compact && <Avatar person={data.me} size={35} onPress={() => go('Profile')} />}
        </Row>
      </Row>
      <Row style={{ flex: 1, alignItems: 'stretch', gap: 0 }}>
        {!compact && (
          <ScrollView
            style={{
              width: width < 960 ? 180 : 214,
              flexGrow: 0,
              borderRightWidth: 1,
              borderRightColor: color.line,
            }}
            contentContainerStyle={{ padding: 18, gap: 8 }}
          >
            {pages.map((p) => (
              <Pressable
                key={p}
                accessibilityRole="button"
                accessibilityLabel={p}
                accessibilityState={{ selected: p === page }}
                onPress={() => go(p)}
                style={{
                  padding: 13,
                  borderRadius: 13,
                  backgroundColor: page === p ? '#25203d' : 'transparent',
                  flexDirection: 'row',
                  alignItems: 'center',
                  gap: 13,
                }}
              >
                <Icon name={p} tint={page === p ? color.purple : color.muted} />
                <Txt weight={page === p ? '700' : '500'} style={{ flex: 1 }}>
                  {p}
                </Txt>
                {(p === 'Ping' ? pingCount : p === 'Drops' ? dropCount : 0) > 0 && (
                  <Txt size={11} style={styles.link}>
                    {p === 'Ping' ? pingCount : dropCount}
                  </Txt>
                )}
              </Pressable>
            ))}
            <View style={{ height: 8 }} />
            <Button label="Create" icon="Plus" onPress={() => setDialog({ kind: 'create' })} />
            <View style={{ paddingTop: 30, gap: 8 }}>
              <Txt size={11} muted>
                Your campus. Your city.
              </Txt>
              <Txt size={11} muted>
                Your hood.
              </Txt>
              <Button
                label="Settings"
                small
                subtle
                icon="Settings"
                onPress={() => setDialog({ kind: 'settings' })}
              />
            </View>
          </ScrollView>
        )}
        <ScrollView
          key={page}
          style={{ flex: 1 }}
          contentContainerStyle={{
            padding: compact ? 14 : 26,
            paddingBottom: compact ? 24 : 40,
            gap: 18,
            maxWidth: page === 'Ping' ? 1200 : 900,
            width: '100%',
            alignSelf: 'center',
          }}
          keyboardShouldPersistTaps="handled"
        >
          <Row style={{ justifyContent: 'space-between' }}>
            <View>
              <Txt size={compact ? 25 : 30} weight="800">
                {page === 'Pulse' ? 'Your Pulse' : page === 'Profile' ? 'My Profile' : page}
              </Txt>
              <Txt size={12} muted>
                {page === 'Pulse'
                  ? `Good to see you, ${data.me.display_name.split(' ')[0]}.`
                  : page === 'Ping'
                    ? 'Every conversation lives here.'
                    : page === 'Drops'
                      ? 'Activity from your hood.'
                      : page === 'Discover'
                        ? 'Find your people. Make things happen.'
                        : page === 'Scenes'
                          ? 'Little moments. Big memories.'
                          : `${data.me.city || 'Your city'} · Your hood`}
              </Txt>
            </View>
            <IconButton icon="RefreshCw" label="Refresh" onPress={() => void act(app.refresh)} />
          </Row>
          {section}
        </ScrollView>
        {wide && page !== 'Ping' && (
          <ScrollView
            style={{
              width: 302,
              flexGrow: 0,
              borderLeftWidth: 1,
              borderLeftColor: color.line,
            }}
            contentContainerStyle={{ padding: 20, gap: 20 }}
          >
            <RightRail go={go} open={setDialog} />
          </ScrollView>
        )}
      </Row>
      {compact && (
        <Row
          style={{
            justifyContent: 'space-around',
            borderTopWidth: 1,
            borderTopColor: color.line,
            paddingTop: 7,
            paddingBottom: Math.max(8, insets.bottom),
            backgroundColor: '#10131e',
          }}
        >
          {(['Pulse', 'Discover', 'Create', 'Scenes', 'Profile'] as const).map((p) =>
            p === 'Create' ? (
              <Pressable
                key={p}
                accessibilityRole="button"
                accessibilityLabel="Create"
                onPress={() => setDialog({ kind: 'create' })}
              >
                <LinearGradient
                  colors={['#954deb', '#488af7']}
                  style={{
                    height: 45,
                    width: 48,
                    borderRadius: 16,
                    alignItems: 'center',
                    justifyContent: 'center',
                  }}
                >
                  <Icon name="Plus" tint="white" size={25} />
                </LinearGradient>
              </Pressable>
            ) : (
              <Pressable
                key={p}
                accessibilityRole="button"
                accessibilityLabel={p}
                onPress={() => go(p)}
                style={{ alignItems: 'center', gap: 3, width: 54 }}
              >
                <Icon name={p} tint={p === page ? color.purple : color.muted} />
                <Txt
                  size={9}
                  weight="600"
                  style={{ color: p === page ? color.purple : color.muted }}
                >
                  {p}
                </Txt>
              </Pressable>
            ),
          )}
        </Row>
      )}
      {!!app.toast && (
        <Pressable
          accessibilityRole="button"
          accessibilityLabel="Dismiss notification"
          onPress={() => setToast('')}
          style={{
            position: 'absolute',
            bottom: compact ? 90 : 30,
            left: 16,
            right: 16,
            alignSelf: 'center',
            borderWidth: 1,
            borderColor: '#79679e',
            backgroundColor: '#262139',
            padding: 15,
            borderRadius: 15,
            maxWidth: 680,
          }}
        >
          <Txt size={13}>{app.toast}</Txt>
        </Pressable>
      )}
      <Modal
        visible={!!dialog}
        animationType="fade"
        transparent
        onRequestClose={() => setDialog(null)}
      >
        <KeyboardAvoidingView
          behavior={Platform.OS === 'ios' ? 'padding' : undefined}
          style={{
            flex: 1,
            backgroundColor: '#000a',
            padding: compact ? 14 : 35,
            justifyContent: 'center',
          }}
        >
          <View
            style={{
              width: '100%',
              maxWidth: 680,
              maxHeight: '90%',
              alignSelf: 'center',
              borderRadius: 23,
              backgroundColor: color.panel,
              borderWidth: 1,
              borderColor: color.line,
              overflow: 'hidden',
            }}
          >
            <Row
              style={{
                justifyContent: 'space-between',
                padding: 16,
                borderBottomWidth: 1,
                borderBottomColor: color.line,
              }}
            >
              <Txt size={18} weight="700">
                {dialog?.kind === 'create'
                  ? 'Create something'
                  : dialog?.kind === 'profile'
                    ? 'Peep profile'
                    : dialog?.kind === 'comments'
                      ? 'Comments'
                      : dialog?.kind === 'settings'
                        ? 'Settings'
                        : dialog?.kind === 'edit'
                          ? 'Edit Profile'
                          : dialog?.kind === 'apply'
                            ? 'Apply for this Gig'
                            : dialog?.kind === 'applications'
                              ? 'Gig applications'
                              : dialog?.kind === 'setup'
                                ? 'Bring your hood online'
                                : 'Manage content'}
              </Txt>
              <IconButton icon="X" label="Close dialog" onPress={() => setDialog(null)} />
            </Row>
            {dialog && (
              <ScrollView
                keyboardShouldPersistTaps="handled"
                contentContainerStyle={{ padding: 20, gap: 15 }}
              >
                <Dialogs
                  key={`${dialog.kind}:${'item' in dialog ? dialog.item.id : ''}`}
                  dialog={dialog}
                  close={() => setDialog(null)}
                  go={go}
                  open={setDialog}
                />
              </ScrollView>
            )}
          </View>
        </KeyboardAvoidingView>
      </Modal>
    </View>
  );
}

function Tabs({
  values,
  value,
  onChange,
}: {
  values: string[];
  value: string;
  onChange: (v: string) => void;
}) {
  return (
    <ScrollView
      horizontal
      showsHorizontalScrollIndicator={false}
      contentContainerStyle={{ gap: 8 }}
    >
      {values.map((v) => (
        <Pressable
          key={v}
          accessibilityRole="button"
          accessibilityLabel={v}
          accessibilityState={{ selected: v === value }}
          onPress={() => onChange(v)}
          style={[styles.pill, { backgroundColor: value === v ? '#312644' : color.panel }]}
        >
          <Txt size={12} weight="600" style={{ color: value === v ? '#d2b9ff' : color.muted }}>
            {v}
          </Txt>
        </Pressable>
      ))}
    </ScrollView>
  );
}
export { Tabs };
function Feed({
  scenes,
  sceneId,
  go,
  open,
}: {
  scenes: boolean;
  sceneId?: string;
  go: Navigate;
  open: OpenDialog;
}) {
  const { data, more, demo, setToast } = useApp(),
    act = useAction();
  const [filter, setFilter] = useState('For you');
  const [shared, setShared] = useState<{ post: Post; author: Profile } | null>(null);
  useEffect(() => {
    if (!sceneId || demo || data.posts.some((p) => p.id === sceneId)) return;
    let alive = true;
    api
      .fetchSharedScene(sceneId, data.me.id)
      .then((value) => {
        if (alive) setShared(value);
      })
      .catch(() => {
        if (alive) setToast('This Scene is unavailable or you do not have access.');
      });
    return () => {
      alive = false;
    };
  }, [sceneId, demo, data.posts, data.me.id, setToast]);
  const list = data.posts.filter(
    (p) =>
      p.kind === (scenes ? 'scene' : 'pulse') &&
      (filter === 'For you' ||
        (filter === 'Campus' && p.university === data.me.university) ||
        (filter === 'My city' && p.city === data.me.city)),
  );
  const selected = sceneId
    ? (data.posts.find((p) => p.id === sceneId && p.kind === 'scene') ??
      (shared?.post.id === sceneId ? shared.post : undefined))
    : undefined;
  const sorted = selected ? [selected, ...list.filter((p) => p.id !== selected.id)] : list;
  return (
    <View style={{ gap: 18 }}>
      {!scenes && (
        <>
          <LinearGradient
            colors={['#211835', '#141a35']}
            start={{ x: 0, y: 0 }}
            end={{ x: 1, y: 1 }}
            style={{
              padding: 22,
              borderRadius: 21,
              borderColor: '#4a365d',
              borderWidth: 1,
              gap: 7,
            }}
          >
            <Txt size={23} weight="800">
              Your people. Your possibilities.
            </Txt>
            <Txt size={13} muted>
              Campus life, city energy. All in one hood.
            </Txt>
            <Row style={{ marginTop: 7 }}>
              <Button
                label="Discover your hood"
                icon="Discover"
                small
                onPress={() => go('Discover')}
              />
            </Row>
          </LinearGradient>
          <ScrollView
            horizontal
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={{ gap: 17, paddingVertical: 3 }}
          >
            <Pressable
              accessibilityRole="button"
              accessibilityLabel="Add a Scene"
              onPress={() => open({ kind: 'create', preset: 'Scene' })}
              style={{ alignItems: 'center', gap: 7 }}
            >
              <View
                style={{
                  width: 59,
                  height: 59,
                  borderRadius: 30,
                  borderColor: color.purple,
                  borderWidth: 2,
                  alignItems: 'center',
                  justifyContent: 'center',
                }}
              >
                <Icon name="Plus" tint={color.purple} />
              </View>
              <Txt size={10} muted>
                Your Scene
              </Txt>
            </Pressable>
            {[data.me, ...data.profiles.filter((p) => p.id !== data.me.id)].slice(0, 8).map((p) => (
              <Pressable
                key={p.id}
                accessibilityRole="button"
                accessibilityLabel={`${p.display_name}'s Scenes`}
                onPress={() => go('Scenes')}
                style={{ alignItems: 'center', gap: 7 }}
              >
                <LinearGradient
                  colors={['#db7ce4', '#5a8aff']}
                  style={{ padding: 3, borderRadius: 34 }}
                >
                  <Avatar person={p} size={54} />
                </LinearGradient>
                <Txt size={10} muted>
                  {p.display_name.split(' ')[0]}
                </Txt>
              </Pressable>
            ))}
          </ScrollView>
          <Card>
            <Row>
              <Avatar person={data.me} size={36} />
              <Pressable
                accessibilityRole="button"
                accessibilityLabel="Write a Pulse"
                onPress={() => open({ kind: 'create', preset: 'Pulse' })}
                style={{ flex: 1 }}
              >
                <Txt muted>What’s on your Pulse?</Txt>
              </Pressable>
              <IconButton
                icon="ImagePlus"
                label="Add a photo to Pulse"
                onPress={() => open({ kind: 'create', preset: 'Pulse' })}
              />
            </Row>
          </Card>
        </>
      )}
      <Row style={{ justifyContent: 'space-between' }}>
        <Tabs values={['For you', 'Campus', 'My city']} value={filter} onChange={setFilter} />
        {scenes && (
          <IconButton
            icon="Plus"
            label="Create a Scene"
            onPress={() => open({ kind: 'create', preset: 'Scene' })}
          />
        )}
      </Row>
      {sorted.map((p) => (
        <PostCard
          key={p.id}
          post={p}
          open={open}
          go={go}
          large={scenes}
          personOverride={shared?.post.id === p.id ? shared.author : undefined}
        />
      ))}
      {!sorted.length && (
        <Empty
          icon={scenes ? 'Scenes' : 'Pulse'}
          title={scenes ? 'Start the first Scene' : 'Your Pulse starts here'}
          description="Share something from your campus or city."
          action={
            <Button
              label={scenes ? 'Share Scene' : 'Create Pulse'}
              onPress={() => open({ kind: 'create', preset: scenes ? 'Scene' : 'Pulse' })}
            />
          }
        />
      )}
      {sorted.length >= 40 && <Button label="Load more" subtle onPress={() => void act(more)} />}
    </View>
  );
}
export function PostCard({
  post: p,
  open,
  go,
  large = false,
  personOverride,
}: {
  post: Post;
  open: OpenDialog;
  go: Navigate;
  large?: boolean;
  personOverride?: Profile;
}) {
  const { data, perform, demo, setToast } = useApp(),
    act = useAction();
  const person = personOverride ?? [data.me, ...data.profiles].find((x) => x.id === p.author_id);
  const source = p.media_url
    ? { uri: p.media_url }
    : p.local_media
      ? p.local_media === 'campus'
        ? require('../../assets/campus.png')
        : require('../../assets/scene-preview.png')
      : undefined;
  const share = () =>
    act(async () => {
      const base = Platform.OS === 'web' ? window.location.origin : process.env.EXPO_PUBLIC_WEB_URL;
      if (!base || demo) {
        setToast(
          demo
            ? 'This sample Scene is available in the preview only.'
            : 'Set EXPO_PUBLIC_WEB_URL to share Scene links.',
        );
        return;
      }
      const link = `${base}/scenes?scene=${p.id}`;
      if (Platform.OS === 'web') {
        if (navigator.share) await navigator.share({ title: 'StudentHood Scene', url: link });
        else {
          await navigator.clipboard.writeText(link);
          setToast('Scene link copied.');
        }
      } else
        await Share.share({
          message: `${person?.display_name ?? 'StudentHood'} on StudentHood: ${link}`,
          url: link,
        });
    });
  return (
    <Card style={{ padding: 0, overflow: 'hidden', gap: 0 }}>
      <Row style={{ padding: 17 }}>
        <Avatar person={person} onPress={() => person && open({ kind: 'profile', item: person })} />
        <View style={{ flex: 1 }}>
          <Txt weight="700">{person?.display_name ?? 'Student'}</Txt>
          <Txt size={10} muted>
            {p.university || p.city} · {age(p.created_at)}
          </Txt>
        </View>
        <IconButton
          icon="MoreHorizontal"
          label="Post actions"
          onPress={() => open({ kind: 'post', item: p })}
        />
      </Row>
      {!!p.body && <Txt style={{ paddingHorizontal: 18, paddingBottom: 15 }}>{p.body}</Txt>}
      {p.media_type === 'video' && p.media_url ? (
        <Video uri={p.media_url} large={large} />
      ) : (
        source && (
          <View>
            <Image
              source={source}
              style={{ width: '100%', height: large ? 440 : 310 }}
              resizeMode="cover"
            />
            {p.kind === 'scene' && demo && (
              <View
                style={{
                  position: 'absolute',
                  bottom: 14,
                  left: 14,
                  backgroundColor: '#10131ee6',
                  padding: 9,
                  borderRadius: 10,
                }}
              >
                <Txt size={11}>Sample Scene preview</Txt>
              </View>
            )}
          </View>
        )
      )}
      <Row
        style={{
          padding: 13,
          borderTopWidth: 1,
          borderTopColor: color.line,
          gap: 8,
        }}
      >
        <Pressable
          accessibilityRole="button"
          accessibilityLabel={p.liked ? 'Unlike post' : 'Like post'}
          onPress={() =>
            void act(() =>
              perform(
                () => api.toggleLike(p, data.me.id),
                (s) => ({
                  ...s,
                  posts: s.posts.map((x) =>
                    x.id === p.id
                      ? {
                          ...x,
                          liked: !x.liked,
                          likes: x.likes + (x.liked ? -1 : 1),
                        }
                      : x,
                  ),
                }),
              ),
            )
          }
          style={{
            flexDirection: 'row',
            alignItems: 'center',
            gap: 6,
            padding: 6,
          }}
        >
          <Icon name="Heart" fill={p.liked} tint={p.liked ? '#e885b4' : color.muted} />
          <Txt size={12} muted>
            {p.likes}
          </Txt>
        </Pressable>
        <Pressable
          accessibilityRole="button"
          accessibilityLabel="Open comments"
          onPress={() => open({ kind: 'comments', item: p })}
          style={{
            flexDirection: 'row',
            alignItems: 'center',
            gap: 6,
            padding: 6,
          }}
        >
          <Icon name="Ping" />
          <Txt size={12} muted>
            {p.comments}
          </Txt>
        </Pressable>
        <View style={{ flex: 1 }} />
        {p.kind === 'scene' && (
          <Pressable
            accessibilityRole="button"
            accessibilityLabel="Share Scene"
            onPress={() => void share()}
            style={{
              padding: 6,
              flexDirection: 'row',
              gap: 5,
              alignItems: 'center',
            }}
          >
            <Icon name="Share2" size={17} />
            <Txt size={11} muted>
              Share Scene
            </Txt>
          </Pressable>
        )}
        <IconButton
          icon="Bookmark"
          label={p.saved ? 'Unsave post' : 'Save post'}
          active={p.saved}
          onPress={() =>
            void act(() =>
              perform(
                () => api.toggleSave(p, data.me.id),
                (s) => ({
                  ...s,
                  posts: s.posts.map((x) => (x.id === p.id ? { ...x, saved: !x.saved } : x)),
                }),
              ),
            )
          }
        />
      </Row>
    </Card>
  );
}

function Discover({ go, open }: { go: Navigate; open: OpenDialog }) {
  const { data, perform } = useApp(),
    act = useAction(),
    begin = useBeginPing(go);
  const [search, setSearch] = useState(''),
    [type, setType] = useState('Peeps');
  const matches = (p: { city: string; university: string }, text: string) =>
    `${text} ${p.city} ${p.university}`.toLowerCase().includes(search.toLowerCase());
  return (
    <View style={{ gap: 17 }}>
      <Field
        placeholder="Search people, universities, Hangs…"
        accessibilityLabel="Discover search"
        value={search}
        onChangeText={setSearch}
      />
      <Tabs values={['Peeps', 'Hangs', 'Crews', 'Gigs']} value={type} onChange={setType} />
      {type === 'Peeps'
        ? data.profiles
            .filter((p) => p.id !== data.me.id && matches(p, `${p.display_name} ${p.handle}`))
            .map((p) => {
              const peep = data.peeps.find((x) => [x.requester_id, x.recipient_id].includes(p.id));
              return (
                <Card key={p.id}>
                  <Row>
                    <Avatar
                      person={p}
                      size={54}
                      onPress={() => open({ kind: 'profile', item: p })}
                    />
                    <View style={{ flex: 1 }}>
                      <Txt size={16} weight="700">
                        {p.display_name}
                      </Txt>
                      <Txt size={11} muted>
                        {p.university}
                      </Txt>
                      <Txt size={11} muted>
                        {p.city}
                      </Txt>
                    </View>
                  </Row>
                  {!!p.bio && (
                    <Txt size={13} muted>
                      {p.bio}
                    </Txt>
                  )}
                  <Row>
                    <Button
                      small
                      label={
                        peep?.status === 'accepted' ? 'Peeps' : peep ? 'Request sent' : 'Add Peep'
                      }
                      disabled={!!peep}
                      icon="Crews"
                      onPress={() =>
                        void act(() =>
                          perform(
                            () => api.rpc('request_peep', { peer: p.id }),
                            (s) => ({
                              ...s,
                              peeps: [
                                ...s.peeps,
                                {
                                  id: id(),
                                  requester_id: s.me.id,
                                  recipient_id: p.id,
                                  status: 'pending',
                                  created_at: new Date().toISOString(),
                                },
                              ],
                            }),
                          ),
                        )
                      }
                    />
                    <Button small label="Ping" subtle icon="Ping" onPress={() => void begin(p)} />
                  </Row>
                </Card>
              );
            })
        : type === 'Hangs' || type === 'Crews'
          ? (type === 'Hangs' ? data.hangs : data.crews)
              .filter((g) => matches(g, `${g.title} ${g.description}`))
              .map((g) => <GroupCard key={g.id} item={g} type={type} go={go} open={open} />)
          : data.gigs
              .filter((g) => matches(g, `${g.title} ${g.description}`))
              .map((g) => <GigCard key={g.id} item={g} open={open} />)}
      {type === 'Peeps' &&
        !data.profiles.filter(
          (p) => p.id !== data.me.id && matches(p, `${p.display_name} ${p.handle}`),
        ).length && (
          <Empty
            icon="Discover"
            title="Find your first Peeps"
            description="Invite a friend to StudentHood. People appear here after they create an account."
          />
        )}
    </View>
  );
}
function Groups({ type, go, open }: { type: 'Hangs' | 'Crews'; go: Navigate; open: OpenDialog }) {
  const { data } = useApp(),
    list = type === 'Hangs' ? data.hangs : data.crews;
  return (
    <View style={{ gap: 16 }}>
      <Row style={{ justifyContent: 'space-between' }}>
        <Txt muted>
          {type === 'Hangs' ? 'Make a plan. Bring your Peeps.' : 'Find people who get your thing.'}
        </Txt>
        <IconButton
          icon="Plus"
          label={`Create ${type === 'Hangs' ? 'Hang' : 'Crew'}`}
          onPress={() => open({ kind: 'create', preset: type === 'Hangs' ? 'Hang' : 'Crew' })}
        />
      </Row>
      {list.map((g) => (
        <GroupCard key={g.id} item={g} type={type} go={go} open={open} />
      ))}
      {!list.length && (
        <Empty
          icon={type}
          title={`Create your first ${type === 'Hangs' ? 'Hang' : 'Crew'}`}
          description="Start a group and invite your people through Discover."
          action={
            <Button
              label="Create"
              onPress={() =>
                open({
                  kind: 'create',
                  preset: type === 'Hangs' ? 'Hang' : 'Crew',
                })
              }
            />
          }
        />
      )}
    </View>
  );
}
function GroupCard({
  item: g,
  type,
  go,
  open,
}: {
  item: Group;
  type: 'Hangs' | 'Crews';
  go: Navigate;
  open: OpenDialog;
}) {
  const { data, perform } = useApp(),
    act = useAction();
  const resource = type === 'Hangs' ? 'hang' : 'crew';
  const join = () =>
    act(() =>
      perform(
        () =>
          api.rpc('join_group', {
            resource_id: g.id,
            resource_type: resource,
            joining: !g.joined,
          }),
        (s) => ({
          ...s,
          [type === 'Hangs' ? 'hangs' : 'crews']: (type === 'Hangs' ? s.hangs : s.crews).map((x) =>
            x.id === g.id
              ? {
                  ...x,
                  joined: !x.joined,
                  members: x.members + (x.joined ? -1 : 1),
                }
              : x,
          ),
          pings: g.joined
            ? s.pings.filter((p) => p.id !== g.thread_id)
            : [
                {
                  id: g.thread_id,
                  kind: resource,
                  title: g.title,
                  peer_id: null,
                  status: 'active',
                  last_read_at: new Date().toISOString(),
                  last_message: null,
                  last_at: new Date().toISOString(),
                  unread_count: 0,
                },
                ...s.pings.filter((p) => p.id !== g.thread_id),
              ],
        }),
      ),
    );
  return (
    <Card>
      <Row>
        <View
          style={{
            height: 46,
            width: 46,
            backgroundColor: '#2b2242',
            borderRadius: 14,
            alignItems: 'center',
            justifyContent: 'center',
          }}
        >
          <Icon name={type} tint={color.purple} size={24} />
        </View>
        <View style={{ flex: 1 }}>
          <Txt size={18} weight="700">
            {g.title}
          </Txt>
          <Txt size={11} muted>
            {g.city} · {g.members} {type === 'Hangs' ? 'going' : 'members'}
          </Txt>
        </View>
        <IconButton
          icon="MoreHorizontal"
          label="Group actions"
          onPress={() => open({ kind: 'group', item: g, type })}
        />
      </Row>
      <Txt muted size={13}>
        {g.description}
      </Txt>
      {g.starts_at && (
        <Row>
          <Icon name="Hangs" size={16} />
          <Txt size={12} muted>
            {new Date(g.starts_at).toLocaleString(undefined, {
              month: 'short',
              day: 'numeric',
              hour: 'numeric',
              minute: '2-digit',
            })}{' '}
            · {g.location}
          </Txt>
        </Row>
      )}
      <Row>
        {g.creator_id !== data.me.id && (
          <Button
            small
            label={g.joined ? 'Leave' : type === 'Hangs' ? 'Join Hang' : 'Join Crew'}
            icon={g.joined ? 'Check' : 'Plus'}
            subtle={g.joined}
            onPress={() => void join()}
          />
        )}{' '}
        {g.joined && (
          <Button
            small
            subtle
            label={type === 'Hangs' ? 'Hang Chat' : 'Crew Chat'}
            icon="Ping"
            onPress={() => go('Ping', g.thread_id)}
          />
        )}
      </Row>
    </Card>
  );
}
function Gigs({ open }: { open: OpenDialog }) {
  const { data } = useApp();
  return (
    <View style={{ gap: 16 }}>
      <Row style={{ justifyContent: 'space-between' }}>
        <Txt muted>Find work that fits student life.</Txt>
        <IconButton
          icon="Plus"
          label="Create Gig"
          onPress={() => open({ kind: 'create', preset: 'Gig' })}
        />
      </Row>
      {data.gigs.map((g) => (
        <GigCard key={g.id} item={g} open={open} />
      ))}
      {!data.gigs.length && (
        <Empty
          icon="Gigs"
          title="Your first Gig starts here"
          description="Share an opportunity with students in your city."
          action={
            <Button label="Post a Gig" onPress={() => open({ kind: 'create', preset: 'Gig' })} />
          }
        />
      )}
    </View>
  );
}
function GigCard({ item: g, open }: { item: Gig; open: OpenDialog }) {
  const { data } = useApp();
  return (
    <Card>
      <Row>
        <Icon name="Gigs" tint={color.blue} size={28} />
        <View style={{ flex: 1 }}>
          <Txt size={18} weight="700">
            {g.title}
          </Txt>
          <Txt size={11} muted>
            {g.city} · {g.university}
          </Txt>
        </View>
        <Txt weight="800" size={19} style={{ color: color.green }}>
          {new Intl.NumberFormat(undefined, {
            style: 'currency',
            currency: g.currency,
            maximumFractionDigits: 2,
          }).format(g.amount)}
        </Txt>
      </Row>
      <Txt size={13} muted>
        {g.description}
      </Txt>
      <Row>
        <Button
          small
          disabled={g.applied}
          label={
            g.creator_id === data.me.id
              ? 'Review applications'
              : g.applied
                ? 'Applied'
                : 'Apply for Gig'
          }
          onPress={() =>
            open({
              kind: g.creator_id === data.me.id ? 'applications' : 'apply',
              item: g,
            })
          }
        />
        <IconButton
          icon="MoreHorizontal"
          label="Gig actions"
          onPress={() => open({ kind: 'gig', item: g })}
        />
      </Row>
    </Card>
  );
}
function Drops({ go }: { go: Navigate }) {
  const { data, perform } = useApp(),
    act = useAction();
  return (
    <View style={{ gap: 14 }}>
      <Row style={{ justifyContent: 'space-between' }}>
        <Txt size={12} muted>
          Likes, comments, Peeps, groups and Gigs.
        </Txt>
        <Button
          label="Mark read"
          small
          subtle
          onPress={() =>
            void act(() =>
              perform(
                () => api.markDrops(data.me.id),
                (s) => ({
                  ...s,
                  drops: s.drops.map((d) => ({
                    ...d,
                    read_at: new Date().toISOString(),
                  })),
                }),
              ),
            )
          }
        />
      </Row>
      {data.peeps
        .filter((p) => p.status === 'pending' && p.recipient_id === data.me.id)
        .map((p) => (
          <Card key={p.id}>
            <Txt weight="700">
              {data.profiles.find((x) => x.id === p.requester_id)?.display_name ?? 'A student'}{' '}
              wants to be your Peep
            </Txt>
            <Row>
              {[true, false].map((accept) => (
                <Button
                  key={String(accept)}
                  label={accept ? 'Accept Peep' : 'Decline'}
                  small
                  subtle={!accept}
                  onPress={() =>
                    void act(() =>
                      perform(
                        () => api.rpc('respond_peep', { request_id: p.id, accept }),
                        (s) => ({
                          ...s,
                          peeps: accept
                            ? s.peeps.map((x) => (x.id === p.id ? { ...x, status: 'accepted' } : x))
                            : s.peeps.filter((x) => x.id !== p.id),
                        }),
                      ),
                    )
                  }
                />
              ))}
            </Row>
          </Card>
        ))}
      {data.drops.map((d) => (
        <Pressable
          key={d.id}
          accessibilityRole="button"
          accessibilityLabel={d.title}
          onPress={() => {
            go(
              d.kind === 'hang'
                ? 'Hangs'
                : d.kind === 'crew'
                  ? 'Crews'
                  : d.kind === 'gig'
                    ? 'Gigs'
                    : d.kind === 'peep'
                      ? 'Discover'
                      : 'Pulse',
            );
          }}
        >
          <Card style={{ backgroundColor: d.read_at ? color.panel : '#211d32' }}>
            <Row>
              <Icon
                name={
                  d.kind === 'post_like'
                    ? 'Heart'
                    : d.kind === 'hang'
                      ? 'Hangs'
                      : d.kind === 'crew' || d.kind === 'peep'
                        ? 'Crews'
                        : d.kind === 'gig'
                          ? 'Gigs'
                          : 'Drops'
                }
                tint={color.purple}
              />
              <View style={{ flex: 1 }}>
                <Txt size={13} weight="600">
                  {d.title}
                </Txt>
                <Txt size={10} muted>
                  {age(d.created_at)}
                </Txt>
              </View>
              {!d.read_at && (
                <View
                  style={{
                    width: 7,
                    height: 7,
                    borderRadius: 4,
                    backgroundColor: color.purple,
                  }}
                />
              )}
            </Row>
          </Card>
        </Pressable>
      ))}
      {!data.drops.length && (
        <Empty
          icon="Drops"
          title="You’re all caught up"
          description="Activity from your posts, Peeps, Hangs, Crews and Gigs will appear here. Open Ping for messages and message requests."
        />
      )}
    </View>
  );
}
export function ProfilePage({
  person: p,
  go,
  open,
}: {
  person: Profile;
  go: Navigate;
  open: OpenDialog;
}) {
  const { data } = useApp(),
    mine = p.id === data.me.id,
    begin = useBeginPing(go);
  const [tab, setTab] = useState('Pulse');
  const own = data.posts.filter((x) =>
    tab === 'Saved'
      ? mine && x.saved
      : x.author_id === p.id && x.kind === (tab === 'Scenes' ? 'scene' : 'pulse'),
  );
  return (
    <View style={{ gap: 17 }}>
      <Card>
        <LinearGradient
          colors={['#31234d', '#17314b']}
          style={{
            height: 94,
            margin: -19,
            marginBottom: -38,
            borderTopLeftRadius: 21,
            borderTopRightRadius: 21,
          }}
        />
        <Row style={{ alignItems: 'flex-end', marginTop: 4 }}>
          <View
            style={{
              borderWidth: 4,
              borderColor: color.panel,
              borderRadius: 50,
            }}
          >
            <Avatar person={p} size={78} />
          </View>
          <View style={{ flex: 1 }} />
          <Button
            label={mine ? 'Edit Profile' : 'Ping'}
            small
            subtle
            onPress={() => (mine ? open({ kind: 'edit', item: p }) : void begin(p))}
          />
          {mine && (
            <IconButton
              icon="Settings"
              label="Settings"
              onPress={() => open({ kind: 'settings' })}
            />
          )}
        </Row>
        <View>
          <Txt size={25} weight="800">
            {p.display_name}
          </Txt>
          <Txt muted size={12}>
            @{p.handle}
          </Txt>
        </View>
        <Row>
          <Icon name="MapPin" size={15} />
          <Txt size={12} muted>
            {p.university} · {p.city}
          </Txt>
        </Row>
        <Txt size={13}>{p.bio || 'Make yourself at home.'}</Txt>
        <Row style={{ gap: 22 }}>
          <Txt size={12} muted>
            {
              data.peeps.filter(
                (x) => x.status === 'accepted' && [x.recipient_id, x.requester_id].includes(p.id),
              ).length
            }{' '}
            Peeps
          </Txt>
          <Txt size={12} muted>
            {data.crews.filter((x) => x.joined).length} joined Crews
            {mine ? '' : ' (yours)'}
          </Txt>
        </Row>
      </Card>
      <Tabs
        values={mine ? ['Pulse', 'Scenes', 'Saved'] : ['Pulse', 'Scenes']}
        value={tab}
        onChange={setTab}
      />
      {own.map((post) => (
        <PostCard key={post.id} post={post} go={go} open={open} />
      ))}
      {!own.length && (
        <Empty
          icon="Profile"
          title={tab === 'Saved' ? 'Save something you love' : 'Make your first memory'}
          description={
            tab === 'Saved'
              ? 'Tap the bookmark on a post to keep it here.'
              : 'Your shared posts will appear here.'
          }
        />
      )}
    </View>
  );
}
function RightRail({ go, open }: { go: Navigate; open: OpenDialog }) {
  const { data } = useApp();
  return (
    <>
      <Card style={{ padding: 16 }}>
        <Row style={{ justifyContent: 'space-between' }}>
          <Txt size={14} weight="700">
            Happening near you
          </Txt>
          <Icon name="Hangs" size={18} tint={color.purple} />
        </Row>
        {data.hangs.slice(0, 2).map((g) => (
          <Pressable
            key={g.id}
            accessibilityRole="button"
            accessibilityLabel={g.title}
            onPress={() => go('Hangs')}
            style={{ gap: 4, paddingVertical: 7 }}
          >
            <Txt weight="600" size={13}>
              {g.title}
            </Txt>
            <Txt muted size={11}>
              {g.city} · {g.members} going
            </Txt>
          </Pressable>
        ))}
        <Button small subtle label="Explore Hangs" onPress={() => go('Hangs')} />
      </Card>
      <Card style={{ padding: 16 }}>
        <Txt weight="700">Crews for your thing</Txt>
        {data.crews.slice(0, 2).map((g) => (
          <Pressable
            key={g.id}
            accessibilityRole="button"
            accessibilityLabel={g.title}
            onPress={() => go('Crews')}
          >
            <Txt size={13}>{g.title}</Txt>
            <Txt size={11} muted>
              {g.members} members
            </Txt>
          </Pressable>
        ))}
        <Button small subtle label="Find a Crew" onPress={() => go('Crews')} />
      </Card>
      <Card style={{ padding: 16 }}>
        <Row style={{ justifyContent: 'space-between' }}>
          <Txt weight="700">Ping</Txt>
          <IconButton
            icon="Ping"
            label="Open Ping"
            badge={data.pings.filter((p) => p.status === 'invited').length}
            onPress={() => go('Ping')}
          />
        </Row>
        {data.pings.slice(0, 3).map((p) => (
          <Pressable
            key={p.id}
            accessibilityRole="button"
            accessibilityLabel={`Ping ${p.title}`}
            onPress={() => go('Ping', p.id)}
            style={{ gap: 4, paddingVertical: 5 }}
          >
            <Txt size={13} weight="600">
              {p.title}
            </Txt>
            <Txt size={11} muted numberOfLines={1}>
              {p.status === 'invited' ? 'Ping request' : p.last_message || 'Start a conversation'}
            </Txt>
          </Pressable>
        ))}
      </Card>
      <Button label="Create something" icon="Plus" onPress={() => open({ kind: 'create' })} />
      <Txt size={10} muted>
        Your campus. Your city. Your hood.
      </Txt>
    </>
  );
}
