import React from 'react';
import {
  View,
  Text,
  Pressable,
  TextInput,
  Image,
  StyleSheet,
  type ViewStyle,
  type ImageSourcePropType,
  type TextInputProps,
  type TextProps,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { useVideoPlayer, VideoView } from 'expo-video';
import {
  Activity,
  Compass,
  Clapperboard,
  CalendarDays,
  Users,
  Briefcase,
  MessageCircle,
  Bell,
  User,
  Search,
  Plus,
  Heart,
  Bookmark,
  Send,
  ArrowLeft,
  X,
  ChevronRight,
  Camera,
  ImagePlus,
  Play,
  MapPin,
  MoreHorizontal,
  Settings,
  LogOut,
  Check,
  Flag,
  Ban,
  RefreshCw,
  Globe,
  Zap,
  Mail,
  Lock,
  Trash2,
  Share2,
  type LucideIcon,
} from 'lucide-react-native';
import type { Profile, Page } from '../lib/types';

export const color = {
  bg: '#080a13',
  panel: '#121521',
  panel2: '#191d2c',
  line: '#272b3d',
  text: '#f4f5ff',
  muted: '#a5a9c0',
  purple: '#b591ff',
  blue: '#65baff',
  green: '#76e5b6',
};
export const navIcons: Record<Page, LucideIcon> = {
  Pulse: Activity,
  Discover: Compass,
  Scenes: Clapperboard,
  Hangs: CalendarDays,
  Crews: Users,
  Gigs: Briefcase,
  Ping: MessageCircle,
  Drops: Bell,
  Profile: User,
};
const icons = {
  Search,
  Plus,
  Heart,
  Bookmark,
  Send,
  ArrowLeft,
  X,
  ChevronRight,
  Camera,
  ImagePlus,
  Play,
  MapPin,
  MoreHorizontal,
  Settings,
  LogOut,
  Check,
  Flag,
  Ban,
  RefreshCw,
  Globe,
  Zap,
  Mail,
  Lock,
  Trash2,
  Share2,
  ...navIcons,
};
export type IconName = keyof typeof icons;
export function Icon({
  name,
  size = 20,
  tint = color.muted,
  fill,
}: {
  name: IconName;
  size?: number;
  tint?: string;
  fill?: boolean;
}) {
  const Component = icons[name];
  return <Component size={size} color={tint} strokeWidth={1.8} fill={fill ? tint : 'none'} />;
}
export function Txt({
  children,
  muted = false,
  size = 14,
  weight = '400',
  style,
  ...rest
}: TextProps & {
  children: React.ReactNode;
  muted?: boolean;
  size?: number;
  weight?: '400' | '500' | '600' | '700' | '800';
}) {
  return (
    <Text
      {...rest}
      style={[
        {
          color: muted ? color.muted : color.text,
          fontSize: size,
          fontWeight: weight,
          lineHeight: size * 1.45,
        },
        style,
      ]}
    >
      {children}
    </Text>
  );
}
export function Row({ children, style }: { children: React.ReactNode; style?: ViewStyle }) {
  return <View style={[styles.row, style]}>{children}</View>;
}
export function Card({ children, style }: { children: React.ReactNode; style?: ViewStyle }) {
  return <View style={[styles.card, style]}>{children}</View>;
}
export function Button({
  label,
  icon,
  onPress,
  small = false,
  subtle = false,
  danger = false,
  disabled = false,
  style,
}: {
  label: string;
  icon?: IconName;
  onPress: () => void;
  small?: boolean;
  subtle?: boolean;
  danger?: boolean;
  disabled?: boolean;
  style?: ViewStyle;
}) {
  const content = (
    <Row
      style={{
        justifyContent: 'center',
        gap: 8,
        paddingHorizontal: small ? 14 : 20,
        paddingVertical: small ? 9 : 13,
      }}
    >
      {icon && <Icon name={icon} size={small ? 16 : 19} tint={danger ? '#ffa3b1' : color.text} />}
      <Txt weight="700" size={small ? 12 : 14} style={{ color: danger ? '#ffa3b1' : color.text }}>
        {label}
      </Txt>
    </Row>
  );
  return (
    <Pressable
      accessibilityRole="button"
      accessibilityLabel={label}
      disabled={disabled}
      onPress={onPress}
      style={({ pressed }) => [
        {
          borderRadius: 13,
          overflow: 'hidden',
          opacity: disabled ? 0.45 : pressed ? 0.72 : 1,
        },
        style,
      ]}
    >
      {subtle ? (
        <View
          style={{
            backgroundColor: danger ? '#39202c' : color.panel2,
            borderColor: color.line,
            borderWidth: 1,
            borderRadius: 13,
          }}
        >
          {content}
        </View>
      ) : (
        <LinearGradient colors={['#914df4', '#4478f5']} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }}>
          {content}
        </LinearGradient>
      )}
    </Pressable>
  );
}
export function IconButton({
  icon,
  onPress,
  label,
  badge,
  active = false,
}: {
  icon: IconName;
  onPress: () => void;
  label: string;
  badge?: number;
  active?: boolean;
}) {
  return (
    <Pressable
      accessibilityRole="button"
      accessibilityLabel={label}
      onPress={onPress}
      style={({ pressed }) => ({
        width: 42,
        height: 42,
        borderRadius: 14,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: active ? color.panel2 : 'transparent',
        opacity: pressed ? 0.6 : 1,
      })}
    >
      <Icon name={icon} tint={active ? color.purple : color.muted} />
      {!!badge && (
        <View
          style={{
            position: 'absolute',
            right: 2,
            top: 0,
            minWidth: 16,
            paddingHorizontal: 4,
            borderRadius: 8,
            backgroundColor: '#ab56ed',
            alignItems: 'center',
          }}
        >
          <Txt size={9} weight="700">
            {badge > 99 ? '99+' : badge}
          </Txt>
        </View>
      )}
    </Pressable>
  );
}
export function Field(props: TextInputProps & { label?: string }) {
  const { label, ...input } = props;
  return (
    <View style={{ gap: 6 }}>
      {label && (
        <Txt size={12} muted>
          {label}
        </Txt>
      )}
      <TextInput
        placeholderTextColor="#838aa5"
        selectionColor={color.purple}
        {...input}
        style={[
          styles.input,
          input.multiline && { minHeight: 96, textAlignVertical: 'top' },
          input.style,
        ]}
      />
    </View>
  );
}
const avatars: Record<string, ImageSourcePropType> = {
  priya: require('../../assets/priya.png'),
  alex: require('../../assets/alex.png'),
  maya: require('../../assets/maya.png'),
};
export function Avatar({
  person,
  size = 42,
  onPress,
}: {
  person?: Profile;
  size?: number;
  onPress?: () => void;
}) {
  const source = person?.avatar_url
    ? { uri: person.avatar_url }
    : person?.local_avatar
      ? avatars[person.local_avatar]
      : undefined;
  const body = source ? (
    <Image source={source} style={{ width: size, height: size, borderRadius: size / 2 }} />
  ) : (
    <LinearGradient
      colors={['#8f59dd', '#356fc0']}
      style={{
        width: size,
        height: size,
        borderRadius: size / 2,
        alignItems: 'center',
        justifyContent: 'center',
      }}
    >
      <Txt size={size * 0.35} weight="700">
        {(person?.display_name || '?')
          .split(' ')
          .map((s) => s[0])
          .slice(0, 2)
          .join('')
          .toUpperCase()}
      </Txt>
    </LinearGradient>
  );
  return onPress ? (
    <Pressable
      accessibilityRole="button"
      accessibilityLabel={`View ${person?.display_name ?? 'profile'}`}
      onPress={onPress}
    >
      {body}
    </Pressable>
  ) : (
    body
  );
}
export function Wordmark({ width = 174 }: { width?: number }) {
  return (
    <Image
      accessibilityLabel="StudentHood"
      source={require('../../assets/wordmark.png')}
      style={{ width, height: width / 3 }}
      resizeMode="contain"
    />
  );
}
export function Empty({
  icon = 'Pulse',
  title,
  description,
  action,
}: {
  icon?: IconName;
  title: string;
  description: string;
  action?: React.ReactNode;
}) {
  return (
    <Card style={{ alignItems: 'center', gap: 12, padding: 32 }}>
      <Icon name={icon} size={32} tint={color.purple} />
      <Txt size={19} weight="700">
        {title}
      </Txt>
      <Txt muted style={{ textAlign: 'center', maxWidth: 400 }}>
        {description}
      </Txt>
      {action}
    </Card>
  );
}
export function Video({ uri, large = false }: { uri: string; large?: boolean }) {
  const player = useVideoPlayer(uri, (p) => {
    p.loop = true;
  });
  return (
    <VideoView
      player={player}
      style={{
        width: '100%',
        height: large ? 480 : 300,
        backgroundColor: '#05060a',
      }}
      nativeControls
      contentFit="contain"
      fullscreenOptions={{ enable: true }}
    />
  );
}
export const styles = StyleSheet.create({
  row: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  card: {
    borderRadius: 21,
    backgroundColor: color.panel,
    borderWidth: 1,
    borderColor: color.line,
    padding: 19,
    gap: 13,
  },
  input: {
    color: color.text,
    fontSize: 15,
    padding: 14,
    borderWidth: 1,
    borderColor: color.line,
    borderRadius: 13,
    backgroundColor: '#0c0f19',
  },
  divider: { height: 1, backgroundColor: color.line },
  pill: {
    borderRadius: 50,
    paddingHorizontal: 14,
    paddingVertical: 8,
    backgroundColor: color.panel2,
  },
  link: { color: color.purple },
});
