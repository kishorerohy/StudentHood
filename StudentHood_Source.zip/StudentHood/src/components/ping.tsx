import React, { useEffect, useRef, useState } from 'react';
import { View, ScrollView, Pressable, Image, useWindowDimensions } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import * as ImagePicker from 'expo-image-picker';
import { useApp } from '../lib/AppProvider';
import * as api from '../lib/api';
import { demoMessages } from '../lib/demo';
import type { Message, Ping } from '../lib/types';
import { Avatar, Card, Txt, Row, Field, Button, IconButton, Empty, color } from './ui';
import { Tabs, age, id, useAction, type Navigate, type OpenDialog } from './Hub';

export function PingPane({
  go,
  threadId,
  open,
}: {
  go: Navigate;
  threadId?: string;
  open: OpenDialog;
}) {
  const { data, demo, perform, revision } = useApp(),
    act = useAction(),
    { width } = useWindowDimensions(),
    split = width >= 1000;
  const [filter, setFilter] = useState('All'),
    [messages, setMessages] = useState<Message[]>([]),
    [text, setText] = useState(''),
    [asset, setAsset] = useState<ImagePicker.ImagePickerAsset | undefined>(),
    [busy, setBusy] = useState(false),
    [sending, setSending] = useState(false),
    [messageLimit, setMessageLimit] = useState(100);
  const listRef = useRef<ScrollView>(null);
  const current =
    data.pings.find((p) => p.id === threadId) ??
    (split && !threadId ? data.pings.find((p) => p.status === 'active') : undefined);
  const activeId = current?.id,
    unread = current?.unread_count,
    status = current?.status;
  const filtered = data.pings.filter((p) =>
    filter === 'Requests'
      ? p.status === 'invited'
      : p.status === 'active' &&
        (filter === 'All' ||
          (filter === 'Peeps' && p.kind === 'direct') ||
          (filter === 'Hang Chats' && p.kind === 'hang') ||
          (filter === 'Crew Chats' && p.kind === 'crew')),
  );
  useEffect(() => {
    setMessages([]);
    setText('');
    setAsset(undefined);
    setMessageLimit(100);
  }, [activeId]);
  useEffect(() => {
    if (!activeId || status !== 'active') {
      setMessages([]);
      return;
    }
    let alive = true;
    setBusy(true);
    (demo ? demoMessages(activeId) : api.fetchMessages(activeId, messageLimit))
      .then((rows) => {
        if (alive) {
          setMessages(rows);
          if (!demo && (unread ?? 0) > 0)
            void api.rpc('mark_ping_read', { t: activeId }).catch(() => {});
        }
      })
      .catch((e) => {
        if (alive)
          void act(async () => {
            throw e;
          });
      })
      .finally(() => {
        if (alive) setBusy(false);
      });
    return () => {
      alive = false;
    };
  }, [activeId, revision, status, unread, demo, messageLimit, act]);
  const send = async () => {
    if (!current || sending || (!text.trim() && !asset)) return;
    setSending(true);
    const body = text.trim(),
      thread = current.id,
      attachment = asset;
    try {
      if (demo) {
        const next = [
          ...messages,
          {
            id: id(),
            thread_id: thread,
            author_id: data.me.id,
            body,
            attachment_path: null,
            attachment_url: attachment?.uri,
            created_at: new Date().toISOString(),
          },
        ];
        await AsyncStorage.setItem(`studenthood:demo:messages:${thread}`, JSON.stringify(next));
        setMessages(next);
      }
      await perform(
        () => api.sendMessage(thread, data.me.id, body, attachment),
        (s) => ({
          ...s,
          pings: s.pings.map((p) =>
            p.id === thread
              ? {
                  ...p,
                  last_message: body || 'Sent a photo',
                  last_at: new Date().toISOString(),
                  unread_count: 0,
                }
              : p,
          ),
        }),
      );
      setText('');
      setAsset(undefined);
    } catch (e) {
      void act(async () => {
        throw e;
      });
    } finally {
      setSending(false);
    }
  };
  const pick = () =>
    act(async () => {
      const result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ['images'],
        allowsEditing: false,
        quality: 1,
      });
      if (!result.canceled) setAsset(result.assets[0]);
    });
  function item(p: Ping) {
    const peer = data.profiles.find((x) => x.id === p.peer_id);
    return (
      <Pressable
        key={p.id}
        accessibilityRole="button"
        accessibilityLabel={`${p.title}${p.status === 'invited' ? ', Ping request' : ''}`}
        onPress={() => go('Ping', p.id)}
        style={{
          padding: 14,
          borderRadius: 14,
          backgroundColor: current?.id === p.id ? '#25203c' : color.panel,
          borderWidth: 1,
          borderColor: color.line,
        }}
      >
        <Row>
          {peer ? (
            <Avatar person={peer} size={38} />
          ) : (
            <View
              style={{
                width: 38,
                height: 38,
                borderRadius: 12,
                backgroundColor: '#272a44',
                alignItems: 'center',
                justifyContent: 'center',
              }}
            >
              <Txt weight="700">{p.kind === 'hang' ? 'H' : 'C'}</Txt>
            </View>
          )}
          <View style={{ flex: 1 }}>
            <Txt size={13} weight="700">
              {p.title}
            </Txt>
            <Txt size={11} muted numberOfLines={1}>
              {p.status === 'invited' ? 'Ping request' : p.last_message || 'Say hello'}
            </Txt>
          </View>
          {p.unread_count > 0 && (
            <Txt size={11} style={{ color: color.purple }}>
              {p.unread_count}
            </Txt>
          )}
        </Row>
      </Pressable>
    );
  }
  return (
    <View style={{ gap: 15 }}>
      <Tabs
        values={['All', 'Peeps', 'Hang Chats', 'Crew Chats', 'Requests']}
        value={filter}
        onChange={setFilter}
      />
      <View
        style={{
          flexDirection: split ? 'row' : 'column',
          gap: 16,
          alignItems: 'stretch',
        }}
      >
        {(split || !current) && (
          <View style={{ gap: 10, width: split ? 248 : '100%' }}>
            {filtered.map(item)}
            {!filtered.length && (
              <Empty
                icon="Ping"
                title={filter === 'Requests' ? 'No Ping requests' : 'Start a Ping'}
                description="Find a Peep in Discover or join a Hang or Crew."
                action={<Button small label="Discover Peeps" onPress={() => go('Discover')} />}
              />
            )}
          </View>
        )}
        {current && (
          <Card
            style={{
              flex: 1,
              minHeight: split ? 570 : 500,
              padding: 0,
              overflow: 'hidden',
            }}
          >
            <Row
              style={{
                padding: 14,
                borderBottomWidth: 1,
                borderBottomColor: color.line,
              }}
            >
              {!split && (
                <IconButton icon="ArrowLeft" label="Back to Ping list" onPress={() => go('Ping')} />
              )}
              <View style={{ flex: 1 }}>
                <Txt weight="700">{current.title}</Txt>
                <Txt size={10} muted>
                  {current.status === 'invited'
                    ? 'Accept this request to read and reply.'
                    : current.kind === 'direct'
                      ? 'Peep conversation'
                      : current.kind === 'hang'
                        ? 'Hang Chat'
                        : 'Crew Chat'}
                </Txt>
              </View>
              {current.peer_id && (
                <IconButton
                  icon="MoreHorizontal"
                  label="Peep actions"
                  onPress={() => {
                    const p = data.profiles.find((x) => x.id === current.peer_id);
                    if (p) open({ kind: 'profile', item: p });
                  }}
                />
              )}
            </Row>
            {current.status === 'invited' ? (
              <View
                style={{
                  padding: 25,
                  gap: 18,
                  flex: 1,
                  justifyContent: 'center',
                }}
              >
                <Txt size={20} weight="700">
                  {current.title} wants to Ping you
                </Txt>
                <Txt muted>Accept to open the conversation. Declining removes the request.</Txt>
                <Row>
                  {[true, false].map((accept) => (
                    <Button
                      key={String(accept)}
                      label={accept ? 'Accept Ping' : 'Decline'}
                      subtle={!accept}
                      onPress={() =>
                        void act(async () => {
                          await perform(
                            () =>
                              api.rpc('respond_ping', {
                                t: current.id,
                                accept,
                              }),
                            (s) => ({
                              ...s,
                              pings: accept
                                ? s.pings.map((p) =>
                                    p.id === current.id ? { ...p, status: 'active' } : p,
                                  )
                                : s.pings.filter((p) => p.id !== current.id),
                            }),
                          );
                          if (!accept) go('Ping');
                        })
                      }
                    />
                  ))}
                </Row>
              </View>
            ) : (
              <>
                <ScrollView
                  ref={listRef}
                  style={{ height: split ? 380 : 340, flexGrow: 0 }}
                  contentContainerStyle={{ padding: 16, gap: 12 }}
                  onContentSizeChange={() => listRef.current?.scrollToEnd({ animated: false })}
                >
                  {messages.length >= messageLimit && (
                    <Button
                      label="Load earlier Pings"
                      small
                      subtle
                      onPress={() => setMessageLimit((n) => n + 100)}
                    />
                  )}
                  {busy && !messages.length && <Txt muted>Loading Pings…</Txt>}
                  {!busy && !messages.length && <Txt muted>Say hello to your hood.</Txt>}
                  {messages.map((m) => {
                    const mine = m.author_id === data.me.id,
                      person = [data.me, ...data.profiles].find((p) => p.id === m.author_id);
                    return (
                      <View
                        key={m.id}
                        style={{
                          alignSelf: mine ? 'flex-end' : 'flex-start',
                          maxWidth: '85%',
                          backgroundColor: mine ? '#6240a5' : '#24283a',
                          borderRadius: 16,
                          padding: 12,
                          gap: 5,
                        }}
                      >
                        {current.kind !== 'direct' && !mine && (
                          <Txt size={10} style={{ color: color.purple }}>
                            {person?.display_name ?? 'Member'}
                          </Txt>
                        )}
                        {m.attachment_url && (
                          <Image
                            source={{ uri: m.attachment_url }}
                            style={{
                              width: 220,
                              maxWidth: '100%',
                              height: 190,
                              borderRadius: 10,
                            }}
                            resizeMode="contain"
                          />
                        )}
                        {!!m.body && <Txt size={14}>{m.body}</Txt>}
                        <Txt
                          size={9}
                          style={{
                            color: mine ? '#dfd3f8' : color.muted,
                            alignSelf: 'flex-end',
                          }}
                        >
                          {age(m.created_at)}
                        </Txt>
                      </View>
                    );
                  })}
                </ScrollView>
                <View
                  style={{
                    padding: 12,
                    gap: 8,
                    borderTopWidth: 1,
                    borderTopColor: color.line,
                  }}
                >
                  {asset && (
                    <Row>
                      <Txt size={12} muted>
                        Photo attached
                      </Txt>
                      <IconButton
                        icon="X"
                        label="Remove attached photo"
                        onPress={() => setAsset(undefined)}
                      />
                    </Row>
                  )}
                  <Row>
                    <IconButton
                      icon="ImagePlus"
                      label="Attach a photo to Ping"
                      onPress={() => void pick()}
                    />
                    <View style={{ flex: 1 }}>
                      <Field
                        placeholder="Write a Ping…"
                        accessibilityLabel="Ping message"
                        value={text}
                        onChangeText={setText}
                        maxLength={4000}
                        onSubmitEditing={() => void send()}
                        returnKeyType="send"
                      />
                    </View>
                    <Button
                      label={sending ? '…' : 'Send'}
                      icon="Send"
                      small
                      disabled={sending || (!text.trim() && !asset)}
                      onPress={() => void send()}
                    />
                  </Row>
                </View>
              </>
            )}
          </Card>
        )}
      </View>
    </View>
  );
}
