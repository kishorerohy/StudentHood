import React, { useState } from 'react';
import { View, ScrollView, Pressable, KeyboardAvoidingView, Platform } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { client, authRedirect } from '../lib/supabase';
import { color, Txt, Row, Card, Button, Field, Wordmark } from './ui';

export function AuthScreen() {
  const [mode, setMode] = useState<'signin' | 'signup' | 'reset'>('signin');
  const [email, setEmail] = useState(''),
    [password, setPassword] = useState(''),
    [name, setName] = useState(''),
    [university, setUniversity] = useState(''),
    [city, setCity] = useState(''),
    [busy, setBusy] = useState(false),
    [notice, setNotice] = useState('');
  async function submit() {
    setNotice('');
    setBusy(true);
    try {
      if (!email.trim().includes('@')) throw new Error('Enter your email address.');
      const c = client();
      if (mode === 'reset') {
        const { error } = await c.auth.resetPasswordForEmail(email.trim(), {
          redirectTo: `${authRedirect()}?recovery=1`,
        });
        if (error) throw error;
        setNotice(
          'If that account exists, you’ll receive a password reset email. Open it on this device.',
        );
      } else if (mode === 'signin') {
        const { error } = await c.auth.signInWithPassword({
          email: email.trim(),
          password,
        });
        if (error) throw error;
      } else {
        if (!name.trim() || !university.trim() || !city.trim())
          throw new Error('Add your name, university and city.');
        if (password.length < 10) throw new Error('Use a password with at least 10 characters.');
        const { data, error } = await c.auth.signUp({
          email: email.trim(),
          password,
          options: {
            emailRedirectTo: authRedirect(),
            data: {
              display_name: name.trim(),
              university: university.trim(),
              city: city.trim(),
            },
          },
        });
        if (error) throw error;
        if (!data.session)
          setNotice(
            'Check your email to confirm your account. Open the link on this device, then sign in.',
          );
      }
    } catch (e) {
      setNotice(e instanceof Error ? e.message : 'Please try again.');
    } finally {
      setBusy(false);
    }
  }
  return (
    <KeyboardAvoidingView
      style={{ flex: 1, backgroundColor: color.bg }}
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
    >
      <ScrollView
        keyboardShouldPersistTaps="handled"
        contentContainerStyle={{
          flexGrow: 1,
          justifyContent: 'center',
          padding: 24,
        }}
      >
        <View style={{ width: '100%', maxWidth: 470, alignSelf: 'center', gap: 22 }}>
          <Wordmark width={250} />
          <LinearGradient
            colors={['#211632', '#15243a']}
            style={{ padding: 24, borderRadius: 22, gap: 8 }}
          >
            <Txt weight="800" size={28}>
              Your people. Your possibilities.
            </Txt>
            <Txt muted>Campus life, city energy. All in one hood.</Txt>
          </LinearGradient>
          <Card>
            <Txt size={22} weight="800">
              {mode === 'signup'
                ? 'Find your hood'
                : mode === 'reset'
                  ? 'Reset your password'
                  : 'Welcome back'}
            </Txt>
            {mode === 'signup' && (
              <>
                <Field
                  label="Your name"
                  accessibilityLabel="Your name"
                  value={name}
                  onChangeText={setName}
                  autoComplete="name"
                  maxLength={80}
                />
                <Field
                  label="University"
                  accessibilityLabel="University"
                  value={university}
                  onChangeText={setUniversity}
                  maxLength={140}
                />
                <Field
                  label="City"
                  accessibilityLabel="City"
                  value={city}
                  onChangeText={setCity}
                  maxLength={80}
                />
              </>
            )}
            <Field
              label="Email"
              accessibilityLabel="Email"
              value={email}
              onChangeText={setEmail}
              keyboardType="email-address"
              autoCapitalize="none"
              autoComplete="email"
            />
            {mode !== 'reset' && (
              <Field
                label="Password"
                accessibilityLabel="Password"
                value={password}
                onChangeText={setPassword}
                secureTextEntry
                autoCapitalize="none"
                autoComplete={mode === 'signup' ? 'new-password' : 'current-password'}
                onSubmitEditing={() => void submit()}
              />
            )}
            {!!notice && (
              <Txt size={13} style={{ color: color.purple }}>
                {notice}
              </Txt>
            )}
            <Button
              disabled={busy}
              label={
                busy
                  ? 'Please wait…'
                  : mode === 'signup'
                    ? 'Create account'
                    : mode === 'reset'
                      ? 'Send reset email'
                      : 'Sign in'
              }
              onPress={() => void submit()}
            />
            <Row style={{ justifyContent: 'space-between', flexWrap: 'wrap' }}>
              <Pressable
                accessibilityRole="button"
                onPress={() => {
                  setMode(mode === 'signup' ? 'signin' : 'signup');
                  setNotice('');
                }}
              >
                <Txt size={12} style={{ color: color.purple }}>
                  {mode === 'signup'
                    ? 'Already have an account? Sign in'
                    : 'New here? Create account'}
                </Txt>
              </Pressable>
              {mode === 'signin' && (
                <Pressable
                  accessibilityRole="button"
                  onPress={() => {
                    setMode('reset');
                    setNotice('');
                  }}
                >
                  <Txt size={12} muted>
                    Forgot password?
                  </Txt>
                </Pressable>
              )}
              {mode === 'reset' && (
                <Button small subtle label="Back to sign in" onPress={() => setMode('signin')} />
              )}
            </Row>
          </Card>
          <Txt size={11} muted style={{ textAlign: 'center' }}>
            Your campus. Your city. Your hood.
          </Txt>
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}
