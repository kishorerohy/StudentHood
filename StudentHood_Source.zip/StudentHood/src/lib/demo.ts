import AsyncStorage from '@react-native-async-storage/async-storage';
import { Snapshot, Message } from './types';
const me = '00000000-0000-4000-8000-000000000001',
  alex = '00000000-0000-4000-8000-000000000002',
  maya = '00000000-0000-4000-8000-000000000003';
const now = new Date().toISOString();
export const demoSeed: Snapshot = {
  me: {
    id: me,
    handle: 'priya_k',
    display_name: 'Priya Sharma',
    city: 'Manchester',
    university: 'University of Manchester',
    bio: 'Photography · Food · Travel\nGood food, good people, better stories.',
    avatar_path: null,
    local_avatar: 'priya',
  },
  profiles: [
    {
      id: alex,
      handle: 'alex_k',
      display_name: 'Alex Kim',
      city: 'Manchester',
      university: 'University of Manchester',
      bio: 'Football and good coffee.',
      avatar_path: null,
      local_avatar: 'alex',
    },
    {
      id: maya,
      handle: 'maya_p',
      display_name: 'Maya Patel',
      city: 'Manchester',
      university: 'Manchester Met',
      bio: 'Meet me at the next Hang.',
      avatar_path: null,
      local_avatar: 'maya',
    },
  ],
  posts: [
    {
      id: 'post-campus',
      author_id: me,
      kind: 'pulse',
      body: 'Golden hour on campus. Good people, better memories.',
      city: 'Manchester',
      university: 'University of Manchester',
      created_at: now,
      media_path: null,
      media_type: 'image',
      local_media: 'campus',
      likes: 342,
      comments: 28,
      liked: false,
      saved: false,
    },
    {
      id: 'post-football',
      author_id: alex,
      kind: 'pulse',
      body: 'A few of us are playing football at Platt Fields. Two spots left. Who’s in?',
      city: 'Manchester',
      university: 'University of Manchester',
      created_at: now,
      media_path: null,
      media_type: null,
      likes: 21,
      comments: 4,
      liked: false,
      saved: false,
    },
    {
      id: 'scene-demo',
      author_id: maya,
      kind: 'scene',
      body: 'Night market hits differently.',
      city: 'Manchester',
      university: 'Manchester Met',
      created_at: now,
      media_path: null,
      media_type: 'image',
      local_media: 'scene',
      likes: 1200,
      comments: 43,
      liked: false,
      saved: false,
    },
  ],
  hangs: [
    {
      id: 'hang-night',
      creator_id: maya,
      thread_id: 'thread-hang',
      title: 'Bollywood Night',
      description: 'Good music, new Peeps and a great night in Manchester.',
      city: 'Manchester',
      university: 'Manchester Met',
      location: 'Students’ Union',
      starts_at: new Date(Date.now() + 86400000).toISOString(),
      created_at: now,
      members: 420,
      joined: false,
    },
    {
      id: 'hang-walk',
      creator_id: alex,
      thread_id: 'thread-walk',
      title: 'Golden Hour Walk',
      description: 'Bring your camera and meet us on campus.',
      city: 'Manchester',
      university: 'University of Manchester',
      location: 'Campus quad',
      starts_at: new Date(Date.now() + 172800000).toISOString(),
      created_at: now,
      members: 38,
      joined: false,
    },
  ],
  crews: [
    {
      id: 'crew-photo',
      creator_id: alex,
      thread_id: 'thread-crew',
      title: 'UoM Photographers',
      description: 'Photo walks, new perspectives and your favourite golden hour.',
      city: 'Manchester',
      university: 'University of Manchester',
      created_at: now,
      members: 218,
      joined: true,
    },
  ],
  gigs: [
    {
      id: 'gig-photo',
      creator_id: alex,
      title: 'Event photographer',
      description: 'Capture a student society night in Manchester.',
      city: 'Manchester',
      university: 'University of Manchester',
      amount: 60,
      currency: 'GBP',
      created_at: now,
      applied: false,
    },
    {
      id: 'gig-maths',
      creator_id: maya,
      title: 'Maths tutor',
      description: 'Help an A-level student build confidence. Online, £18 per hour.',
      city: 'Manchester',
      university: 'Manchester Met',
      amount: 18,
      currency: 'GBP',
      created_at: now,
      applied: false,
    },
  ],
  peeps: [],
  pings: [
    {
      id: 'thread-alex',
      kind: 'direct',
      title: 'Alex Kim',
      peer_id: alex,
      status: 'active',
      last_read_at: now,
      last_message: 'Hey! Are you coming tonight?',
      last_at: now,
      unread_count: 1,
    },
    {
      id: 'thread-crew',
      kind: 'crew',
      title: 'UoM Photographers',
      peer_id: null,
      status: 'active',
      last_read_at: now,
      last_message: 'Ella: Golden hour at 6?',
      last_at: now,
      unread_count: 2,
    },
    {
      id: 'thread-maya',
      kind: 'direct',
      title: 'Maya Patel',
      peer_id: maya,
      status: 'invited',
      last_read_at: now,
      last_message: null,
      last_at: now,
      unread_count: 0,
    },
  ],
  drops: [
    {
      id: 'drop-1',
      recipient_id: me,
      actor_id: maya,
      kind: 'post_like',
      title: 'Maya liked your Scene',
      target_id: 'scene-demo',
      created_at: now,
      read_at: null,
    },
    {
      id: 'drop-2',
      recipient_id: me,
      actor_id: alex,
      kind: 'peep',
      title: 'Alex added you as a Peep',
      target_id: null,
      created_at: now,
      read_at: null,
    },
  ],
  blocks: [],
};
export async function loadDemo(): Promise<Snapshot> {
  const value = await AsyncStorage.getItem('studenthood:demo:v1');
  try {
    return value ? JSON.parse(value) : JSON.parse(JSON.stringify(demoSeed));
  } catch {
    return JSON.parse(JSON.stringify(demoSeed));
  }
}
export async function saveDemo(s: Snapshot) {
  await AsyncStorage.setItem('studenthood:demo:v1', JSON.stringify(s));
}
export async function demoMessages(t: string): Promise<Message[]> {
  const value = await AsyncStorage.getItem(`studenthood:demo:messages:${t}`);
  return value
    ? JSON.parse(value)
    : [
        {
          id: 'sample-message',
          thread_id: t,
          author_id: alex,
          body: 'Hey! Are you coming tonight?',
          attachment_path: null,
          created_at: now,
        },
      ];
}
