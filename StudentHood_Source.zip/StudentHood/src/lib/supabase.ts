import 'react-native-url-polyfill/auto';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { createClient, processLock } from '@supabase/supabase-js';
const url = process.env.EXPO_PUBLIC_SUPABASE_URL;
const key = process.env.EXPO_PUBLIC_SUPABASE_PUBLISHABLE_KEY;
export const configured = Boolean(url?.startsWith('https://') && key && !key.includes('replace_'));
export const supabase = configured
  ? createClient(url!, key!, {
      auth: {
        storage: AsyncStorage,
        autoRefreshToken: true,
        persistSession: true,
        detectSessionInUrl: false,
        flowType: 'pkce',
        lock: processLock,
      },
    })
  : null;
export function client() {
  if (!supabase)
    throw new Error('The preview uses sample data. Live accounts are not connected yet.');
  return supabase;
}
export function authRedirect() {
  return typeof window !== 'undefined' && window.location?.origin
    ? `${window.location.origin}/auth/callback`
    : 'studenthood://auth/callback';
}
