import React, { createContext, useContext, useEffect, useRef, useState, useCallback } from 'react';
import { AppState } from 'react-native';
import type { Session } from '@supabase/supabase-js';
import { supabase, configured } from './supabase';
import { clearMediaCache, loadSnapshot } from './api';
import { loadDemo, saveDemo } from './demo';
import { emptySnapshot, type Snapshot } from './types';

type Context = {
  data: Snapshot;
  session: Session | null;
  ready: boolean;
  loading: boolean;
  demo: boolean;
  connected: boolean;
  toast: string;
  setToast: (value: string) => void;
  revision: number;
  refresh: () => Promise<void>;
  more: () => Promise<void>;
  perform: <T>(
    live: () => Promise<T>,
    preview?: (s: Snapshot) => Snapshot,
  ) => Promise<T | undefined>;
};
const AppContext = createContext<Context | null>(null);
export function useApp() {
  const value = useContext(AppContext);
  if (!value) throw new Error('Missing app provider');
  return value;
}
export function AppProvider({ children }: { children: React.ReactNode }) {
  const [data, setData] = useState<Snapshot>(emptySnapshot),
    [session, setSession] = useState<Session | null>(null);
  const [ready, setReady] = useState(false),
    [loading, setLoading] = useState(false),
    [connected, setConnected] = useState(false),
    [toast, setToast] = useState(''),
    [revision, setRevision] = useState(0);
  const state = useRef(data),
    user = useRef<string | null>(null),
    limit = useRef(40),
    epoch = useRef(0),
    refreshing = useRef(false),
    queued = useRef(false),
    mounted = useRef(true);
  useEffect(() => {
    state.current = data;
  }, [data]);
  const refreshRef = useRef<() => Promise<void>>(async () => {});
  const refresh = useCallback(async () => {
    const id = user.current;
    if (!supabase || !id) return;
    if (refreshing.current) {
      queued.current = true;
      return;
    }
    refreshing.current = true;
    const generation = epoch.current;
    try {
      const next = await loadSnapshot(id, limit.current);
      if (mounted.current && generation === epoch.current) {
        setData(next);
        setRevision((x) => x + 1);
      }
    } catch (e) {
      if (mounted.current && generation === epoch.current)
        setToast(e instanceof Error ? e.message : 'Unable to refresh. Try again.');
    } finally {
      refreshing.current = false;
      if (queued.current) {
        queued.current = false;
        void refreshRef.current();
      }
    }
  }, []);
  useEffect(() => {
    refreshRef.current = refresh;
  }, [refresh]);
  useEffect(() => {
    mounted.current = true;
    if (!supabase) {
      loadDemo()
        .then((s) => {
          if (mounted.current) {
            setData(s);
            setReady(true);
          }
        })
        .catch(() => setReady(true));
      return () => {
        mounted.current = false;
      };
    }
    const c = supabase;
    const applySession = (next: Session | null) => {
      const id = next?.user.id ?? null;
      if (id !== user.current) {
        user.current = id;
        epoch.current++;
        clearMediaCache();
        limit.current = 40;
        setData(emptySnapshot);
        setConnected(false);
        setLoading(!!id);
      }
      setSession(next);
      setReady(true);
    };
    c.auth.getSession().then(({ data: s, error }) => {
      if (!mounted.current) return;
      if (error) setToast(error.message);
      applySession(s.session);
    });
    const { data: listener } = c.auth.onAuthStateChange((_event, next) => {
      applySession(next);
    });
    const app = AppState.addEventListener('change', (s) => {
      if (s === 'active') {
        c.auth.startAutoRefresh();
        void refreshRef.current();
      } else c.auth.stopAutoRefresh();
    });
    return () => {
      mounted.current = false;
      listener.subscription.unsubscribe();
      app.remove();
      c.auth.stopAutoRefresh();
    };
  }, []);
  useEffect(() => {
    if (!supabase) return;
    const id = session?.user.id ?? null;
    if (!id) return;
    void refreshRef.current().finally(() => {
      if (user.current === id) setLoading(false);
    });
    let timer: ReturnType<typeof setTimeout> | undefined;
    const channel = supabase
      .channel(`studenthood:${id}`)
      .on('postgres_changes', { event: '*', schema: 'public' }, () => {
        clearTimeout(timer);
        timer = setTimeout(() => void refreshRef.current(), 300);
      })
      .subscribe((status) => {
        if (!mounted.current || user.current !== id) return;
        setConnected(status === 'SUBSCRIBED');
        if (status === 'SUBSCRIBED') void refreshRef.current();
      });
    // A periodic refresh also renews signed media URLs and catches connection gaps.
    const fallback = setInterval(() => void refreshRef.current(), 60000);
    return () => {
      clearTimeout(timer);
      clearInterval(fallback);
      void supabase?.removeChannel(channel);
    };
  }, [session?.user.id]);
  useEffect(() => {
    if (!toast) return;
    const t = setTimeout(() => setToast(''), 6500);
    return () => clearTimeout(t);
  }, [toast]);
  async function perform<T>(
    live: () => Promise<T>,
    preview?: (s: Snapshot) => Snapshot,
  ): Promise<T | undefined> {
    if (!configured) {
      if (preview) {
        const next = preview(state.current);
        state.current = next;
        setData(next);
        setRevision((x) => x + 1);
        await saveDemo(next);
      } else throw new Error('This is a sample preview. Connect Supabase to use live accounts.');
      return;
    }
    const result = await live();
    await refreshRef.current();
    return result;
  }
  return (
    <AppContext.Provider
      value={{
        data,
        session,
        ready,
        loading,
        demo: !configured,
        connected,
        toast,
        setToast,
        revision,
        refresh,
        more: async () => {
          limit.current += 40;
          await refreshRef.current();
        },
        perform,
      }}
    >
      {children}
    </AppContext.Provider>
  );
}
