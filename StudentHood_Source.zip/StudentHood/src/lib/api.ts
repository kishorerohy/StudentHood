import { Platform } from 'react-native';
import { File } from 'expo-file-system';
import * as Crypto from 'expo-crypto';
import type { ImagePickerAsset } from 'expo-image-picker';
import { client } from './supabase';
import type {
  Snapshot,
  Profile,
  Post,
  Group,
  Gig,
  Message,
  Comment,
  Application,
  Ping,
} from './types';
const signed = new Map<string, { url: string; expires: number }>();
export function clearMediaCache() {
  signed.clear();
}
export async function mediaUrl(bucket: string, path: string | null) {
  if (!path) return undefined;
  const key = `${bucket}:${path}`;
  const old = signed.get(key);
  if (old && old.expires > Date.now()) return old.url;
  const { data, error } = await client().storage.from(bucket).createSignedUrl(path, 3600);
  if (error) throw error;
  signed.set(key, { url: data.signedUrl, expires: Date.now() + 3000000 });
  return data.signedUrl;
}
function check<T>(r: { data: T; error: { message: string } | null }): T {
  if (r.error) throw new Error(r.error.message);
  return r.data;
}
export async function loadSnapshot(userId: string, limit = 40): Promise<Snapshot> {
  const c = client();
  const [own, people, postRows, hangRows, crewRows, gigRows, peeps, pings, drops, blocks] =
    await Promise.all([
      c.from('profiles').select('*').eq('id', userId).single(),
      c.from('profiles').select('*').limit(150),
      c
        .from('posts')
        .select('*')
        .order('created_at', { ascending: false })
        .order('id', { ascending: false })
        .limit(limit),
      c.from('hangs').select('*').order('starts_at').limit(60),
      c.from('crews').select('*').order('created_at', { ascending: false }).limit(60),
      c.from('gigs').select('*').order('created_at', { ascending: false }).limit(60),
      c.from('peeps').select('*'),
      c.rpc('ping_inbox'),
      c.from('drops').select('*').order('created_at', { ascending: false }).limit(100),
      c.from('blocks').select('blocked_id'),
    ]);
  const me = check(own) as Profile;
  let profiles = check(people) as Profile[];
  const posts = check(postRows) as Post[];
  const missing = [...new Set(posts.map((p) => p.author_id))].filter(
    (id) => !profiles.some((p) => p.id === id),
  );
  if (missing.length) {
    profiles = [
      ...profiles,
      ...(check(await c.from('profiles').select('*').in('id', missing)) as Profile[]),
    ];
  }
  const hangs = check(hangRows) as Group[],
    crews = check(crewRows) as Group[],
    gigs = check(gigRows) as Gig[];
  const ids = posts.map((p) => p.id);
  const [likes, comments, bookmarks, hms, cms, apps] = await Promise.all([
    ids.length
      ? c.from('post_likes').select('post_id,user_id').in('post_id', ids)
      : Promise.resolve({ data: [], error: null }),
    ids.length
      ? c.from('comments').select('post_id').in('post_id', ids)
      : Promise.resolve({ data: [], error: null }),
    c.from('bookmarks').select('post_id'),
    c.from('hang_members').select('hang_id,user_id'),
    c.from('crew_members').select('crew_id,user_id'),
    c.from('gig_applications').select('gig_id,applicant_id'),
  ]);
  const l = check(likes) ?? [],
    cm = check(comments) ?? [],
    bm = check(bookmarks) ?? [],
    hm = check(hms) ?? [],
    crm = check(cms) ?? [],
    applications = check(apps) ?? [];
  await Promise.all(
    profiles.map(async (p) => {
      try {
        p.avatar_url = await mediaUrl('avatars', p.avatar_path);
      } catch {
        p.avatar_url = undefined;
      }
    }),
  );
  me.avatar_url = profiles.find((p) => p.id === me.id)?.avatar_url;
  await Promise.all(
    posts.map(async (p) => {
      p.likes = l.filter((x) => x.post_id === p.id).length;
      p.comments = cm.filter((x) => x.post_id === p.id).length;
      p.liked = l.some((x) => x.post_id === p.id && x.user_id === userId);
      p.saved = bm.some((x) => x.post_id === p.id);
      try {
        p.media_url = await mediaUrl('media', p.media_path);
      } catch {
        p.media_url = undefined;
      }
    }),
  );
  hangs.forEach((h) => {
    h.members = hm.filter((x) => x.hang_id === h.id).length;
    h.joined = hm.some((x) => x.hang_id === h.id && x.user_id === userId);
  });
  crews.forEach((h) => {
    h.members = crm.filter((x) => x.crew_id === h.id).length;
    h.joined = crm.some((x) => x.crew_id === h.id && x.user_id === userId);
  });
  gigs.forEach(
    (g) => (g.applied = applications.some((a) => a.gig_id === g.id && a.applicant_id === userId)),
  );
  return {
    me,
    profiles,
    posts,
    hangs,
    crews,
    gigs,
    peeps: check(peeps) ?? [],
    pings: (check(pings) ?? []) as Ping[],
    drops: check(drops) ?? [],
    blocks: (check(blocks) ?? []).map((x) => x.blocked_id),
  };
}
export async function upload(
  asset: ImagePickerAsset,
  bucket: 'media' | 'avatars' | 'ping-files',
  userId: string,
  threadId?: string,
) {
  const video = asset.type === 'video';
  const mime = asset.mimeType || (video ? 'video/mp4' : 'image/jpeg');
  const allowed = ['image/jpeg', 'image/png', 'image/webp', 'video/mp4', 'video/quicktime'];
  if (!allowed.includes(mime)) throw new Error('Choose a JPEG, PNG, WebP, MP4 or MOV file.');
  if (bucket !== 'media' && video) throw new Error('Choose a photo.');
  const max =
    bucket === 'avatars'
      ? 5 * 1024 * 1024
      : bucket === 'ping-files'
        ? 10 * 1024 * 1024
        : 50 * 1024 * 1024;
  if (asset.fileSize && asset.fileSize > max)
    throw new Error(`Choose a file smaller than ${max / 1024 / 1024} MB.`);
  const bytes =
    Platform.OS === 'web' && asset.file
      ? await asset.file.arrayBuffer()
      : await new File(asset.uri).arrayBuffer();
  if (bytes.byteLength > max) throw new Error('That file is too large.');
  const extension =
    mime === 'video/quicktime' ? 'mov' : mime.split('/')[1] === 'jpeg' ? 'jpg' : mime.split('/')[1];
  const path = `${userId}/${threadId ? `${threadId}/` : ''}${Crypto.randomUUID()}.${extension}`;
  check(
    await client().storage.from(bucket).upload(path, bytes, { contentType: mime, upsert: false }),
  );
  return path;
}
export async function removeUpload(bucket: string, path: string) {
  check(await client().storage.from(bucket).remove([path]));
  signed.delete(`${bucket}:${path}`);
}
export async function createPost(
  me: Profile,
  body: string,
  kind: 'pulse' | 'scene',
  asset?: ImagePickerAsset,
) {
  if (kind === 'scene' && asset?.type !== 'video')
    throw new Error('Choose a video for your Scene.');
  if (!body.trim() && !asset) throw new Error('Write something or add a photo.');
  const path = asset ? await upload(asset, 'media', me.id) : null;
  try {
    check(
      await client()
        .from('posts')
        .insert({
          author_id: me.id,
          kind,
          body: body.trim(),
          media_path: path,
          media_type: asset ? (asset.type === 'video' ? 'video' : 'image') : null,
          city: me.city,
          university: me.university,
        }),
    );
  } catch (error) {
    if (path) await removeUpload('media', path).catch(() => {});
    throw error;
  }
}
export async function toggleLike(p: Post, userId: string) {
  check(
    p.liked
      ? await client().from('post_likes').delete().eq('post_id', p.id).eq('user_id', userId)
      : await client().from('post_likes').insert({ post_id: p.id, user_id: userId }),
  );
}
export async function toggleSave(p: Post, userId: string) {
  check(
    p.saved
      ? await client().from('bookmarks').delete().eq('post_id', p.id).eq('user_id', userId)
      : await client().from('bookmarks').insert({ post_id: p.id, user_id: userId }),
  );
}
export async function fetchComments(postId: string): Promise<Comment[]> {
  return (
    check(
      await client()
        .from('comments')
        .select('*')
        .eq('post_id', postId)
        .order('created_at')
        .limit(200),
    ) ?? []
  );
}
export async function addComment(postId: string, userId: string, body: string) {
  if (!body.trim()) throw new Error('Write your comment.');
  check(
    await client()
      .from('comments')
      .insert({ post_id: postId, author_id: userId, body: body.trim() }),
  );
}
export async function fetchMessages(threadId: string, limit = 100): Promise<Message[]> {
  const rows = check(
    await client()
      .from('messages')
      .select('*')
      .eq('thread_id', threadId)
      .order('created_at', { ascending: false })
      .order('id', { ascending: false })
      .limit(limit),
  ) as Message[];
  await Promise.all(
    rows.map(async (m) => {
      if (m.attachment_path)
        try {
          m.attachment_url = await mediaUrl('ping-files', m.attachment_path);
        } catch {}
    }),
  );
  return rows.reverse();
}
export async function sendMessage(
  threadId: string,
  userId: string,
  body: string,
  asset?: ImagePickerAsset,
) {
  if (!body.trim() && !asset) throw new Error('Write a Ping or choose a photo.');
  const path = asset ? await upload(asset, 'ping-files', userId, threadId) : null;
  try {
    check(
      await client().from('messages').insert({
        thread_id: threadId,
        author_id: userId,
        body: body.trim(),
        attachment_path: path,
      }),
    );
  } catch (e) {
    if (path) await removeUpload('ping-files', path).catch(() => {});
    throw e;
  }
}
export async function rpc(name: string, args: Record<string, unknown>) {
  return check(await client().rpc(name, args));
}
export async function updateProfile(
  me: Profile,
  patch: Partial<Profile>,
  asset?: ImagePickerAsset,
) {
  const { display_name, handle, university, city, bio } = patch;
  const avatar_path = asset ? await upload(asset, 'avatars', me.id) : me.avatar_path;
  try {
    check(
      await client()
        .from('profiles')
        .update({ display_name, handle, university, city, bio, avatar_path })
        .eq('id', me.id),
    );
  } catch (e) {
    if (asset && avatar_path) await removeUpload('avatars', avatar_path).catch(() => {});
    throw e;
  }
  if (asset && me.avatar_path) await removeUpload('avatars', me.avatar_path).catch(() => {});
}
export async function createGig(
  me: Profile,
  title: string,
  description: string,
  amount: number,
  currency: string,
) {
  check(
    await client().from('gigs').insert({
      creator_id: me.id,
      title,
      description,
      amount,
      currency,
      city: me.city,
      university: me.university,
    }),
  );
}
export async function applyGig(id: string, userId: string, body: string) {
  check(await client().from('gig_applications').insert({ gig_id: id, applicant_id: userId, body }));
}
export async function gigApplications(id: string): Promise<Application[]> {
  return (
    check(
      await client().from('gig_applications').select('*').eq('gig_id', id).order('created_at'),
    ) ?? []
  );
}
export async function respondApplication(id: string, status: 'accepted' | 'declined') {
  check(await client().from('gig_applications').update({ status }).eq('id', id));
}
export async function markDrops(userId: string) {
  check(
    await client()
      .from('drops')
      .update({ read_at: new Date().toISOString() })
      .eq('recipient_id', userId)
      .is('read_at', null),
  );
}
export async function report(userId: string, targetType: string, targetId: string, reason: string) {
  check(
    await client().from('reports').insert({
      reporter_id: userId,
      target_type: targetType,
      target_id: targetId,
      reason,
    }),
  );
}
export async function block(userId: string, peer: string) {
  check(await client().from('blocks').insert({ blocker_id: userId, blocked_id: peer }));
  clearMediaCache();
}
export async function unblock(userId: string, peer: string) {
  check(await client().from('blocks').delete().eq('blocker_id', userId).eq('blocked_id', peer));
}
export async function deletePost(post: Post) {
  check(await client().from('posts').delete().eq('id', post.id));
  if (post.media_path) await removeUpload('media', post.media_path);
}
export async function deleteGig(id: string) {
  check(await client().from('gigs').delete().eq('id', id));
}
export async function deleteAccount() {
  const { error } = await client().functions.invoke('delete-account', {
    body: { confirm: 'DELETE' },
  });
  if (error) throw error;
  clearMediaCache();
  await client().auth.signOut();
}
export async function fetchSharedScene(postId: string, userId: string) {
  const c = client();
  const post = check(
    await c.from('posts').select('*').eq('id', postId).eq('kind', 'scene').single(),
  ) as Post;
  const [authorResult, likes, comments, bookmark] = await Promise.all([
    c.from('profiles').select('*').eq('id', post.author_id).single(),
    c.from('post_likes').select('user_id').eq('post_id', postId),
    c.from('comments').select('id', { count: 'exact', head: true }).eq('post_id', postId),
    c.from('bookmarks').select('post_id').eq('post_id', postId).eq('user_id', userId).maybeSingle(),
  ]);
  const author = check(authorResult) as Profile,
    liked = check(likes) ?? [];
  check(comments);
  post.likes = liked.length;
  post.liked = liked.some((l) => l.user_id === userId);
  post.comments = comments.count ?? 0;
  post.saved = !!check(bookmark);
  post.media_url = await mediaUrl('media', post.media_path);
  author.avatar_url = await mediaUrl('avatars', author.avatar_path);
  return { post, author };
}
