import { Platform } from 'react-native';
import Constants from 'expo-constants';
import * as Device from 'expo-device';
import * as Notifications from 'expo-notifications';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { client } from './supabase';

export async function enablePingPush(userId: string) {
  if (Platform.OS === 'web')
    throw new Error('Use the installed mobile or iPad app to enable Ping push notifications.');
  if (!Device.isDevice) throw new Error('Push notifications need a physical device.');
  const projectId = Constants.easConfig?.projectId ?? Constants.expoConfig?.extra?.eas?.projectId;
  if (!projectId)
    throw new Error('Run EAS init and create a development build first. See BUILD_GUIDE.md.');
  if (Platform.OS === 'android')
    await Notifications.setNotificationChannelAsync('ping', {
      name: 'Ping',
      importance: Notifications.AndroidImportance.HIGH,
    });
  let { status } = await Notifications.getPermissionsAsync();
  if (status !== 'granted') ({ status } = await Notifications.requestPermissionsAsync());
  if (status !== 'granted')
    throw new Error('Notification permission is off. You can enable it in device settings.');
  const { data: token } = await Notifications.getExpoPushTokenAsync({
    projectId,
  });
  const { error } = await client()
    .from('device_tokens')
    .upsert({ user_id: userId, token }, { onConflict: 'user_id,token', ignoreDuplicates: true });
  if (error) throw error;
  await AsyncStorage.setItem(`studenthood:push:${userId}`, token);
  return token;
}
export async function disablePingPush(userId: string) {
  const { error } = await client().from('device_tokens').delete().eq('user_id', userId);
  if (error) throw error;
}
export async function removeCurrentPush(userId: string) {
  const key = `studenthood:push:${userId}`,
    token = await AsyncStorage.getItem(key);
  if (token) {
    const { error } = await client()
      .from('device_tokens')
      .delete()
      .eq('user_id', userId)
      .eq('token', token);
    if (error) throw error;
    await AsyncStorage.removeItem(key);
  }
}
