export type Page =
  'Pulse' | 'Discover' | 'Scenes' | 'Hangs' | 'Crews' | 'Gigs' | 'Ping' | 'Drops' | 'Profile';
export type Profile = {
  id: string;
  handle: string;
  display_name: string;
  university: string;
  city: string;
  bio: string;
  avatar_path: string | null;
  avatar_url?: string;
  local_avatar?: string;
};
export type Post = {
  id: string;
  author_id: string;
  kind: 'pulse' | 'scene';
  body: string;
  media_path: string | null;
  media_type: 'image' | 'video' | null;
  city: string;
  university: string;
  created_at: string;
  media_url?: string;
  local_media?: 'campus' | 'scene';
  likes: number;
  comments: number;
  liked: boolean;
  saved: boolean;
};
export type Group = {
  id: string;
  creator_id: string;
  thread_id: string;
  title: string;
  description: string;
  city: string;
  university: string;
  location?: string;
  starts_at?: string;
  created_at: string;
  members: number;
  joined: boolean;
};
export type Gig = {
  id: string;
  creator_id: string;
  title: string;
  description: string;
  city: string;
  university: string;
  amount: number;
  currency: string;
  created_at: string;
  applied: boolean;
};
export type Peep = {
  id: string;
  requester_id: string;
  recipient_id: string;
  status: 'pending' | 'accepted';
  created_at: string;
};
export type Ping = {
  id: string;
  kind: 'direct' | 'hang' | 'crew';
  title: string;
  peer_id: string | null;
  status: 'active' | 'invited';
  last_read_at: string;
  last_message: string | null;
  last_at: string;
  unread_count: number;
};
export type Message = {
  id: string;
  thread_id: string;
  author_id: string;
  body: string;
  attachment_path: string | null;
  attachment_url?: string;
  created_at: string;
};
export type Drop = {
  id: string;
  recipient_id: string;
  actor_id: string | null;
  kind: 'peep' | 'post_like' | 'comment' | 'hang' | 'crew' | 'gig';
  title: string;
  target_id: string | null;
  read_at: string | null;
  created_at: string;
};
export type Comment = {
  id: string;
  post_id: string;
  author_id: string;
  body: string;
  created_at: string;
};
export type Application = {
  id: string;
  gig_id: string;
  applicant_id: string;
  body: string;
  status: 'submitted' | 'accepted' | 'declined';
  created_at: string;
};
export type Snapshot = {
  me: Profile;
  profiles: Profile[];
  posts: Post[];
  hangs: Group[];
  crews: Group[];
  gigs: Gig[];
  peeps: Peep[];
  pings: Ping[];
  drops: Drop[];
  blocks: string[];
};
export const pages: Page[] = [
  'Pulse',
  'Discover',
  'Scenes',
  'Hangs',
  'Crews',
  'Gigs',
  'Ping',
  'Drops',
  'Profile',
];
export const emptySnapshot: Snapshot = {
  me: {
    id: '',
    handle: '',
    display_name: 'Student',
    university: '',
    city: 'Manchester',
    bio: '',
    avatar_path: null,
  },
  profiles: [],
  posts: [],
  hangs: [],
  crews: [],
  gigs: [],
  peeps: [],
  pings: [],
  drops: [],
  blocks: [],
};
