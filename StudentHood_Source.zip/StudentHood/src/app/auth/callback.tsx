import React, { useEffect, useRef, useState } from 'react';
import { View, ScrollView } from 'react-native';
import { router, useLocalSearchParams } from 'expo-router';
import * as Linking from 'expo-linking';
import type { EmailOtpType } from '@supabase/supabase-js';
import { client } from '../../lib/supabase';
import { color, Card, Txt, Button, Field, Wordmark } from '../../components/ui';

export default function Callback() {
  const params = useLocalSearchParams<{
      code?: string;
      token_hash?: string;
      type?: string;
      recovery?: string;
    }>(),
    url = Linking.useURL();
  const started = useRef(false);
  const [notice, setNotice] = useState('Confirming your email…'),
    [recovery, setRecovery] = useState(false),
    [password, setPassword] = useState(''),
    [busy, setBusy] = useState(false);
  useEffect(() => {
    if (started.current) return;
    started.current = true;
    void (async () => {
      try {
        const c = client();
        let reset = params.recovery === '1' || params.type === 'recovery';
        if (params.code) {
          const { error } = await c.auth.exchangeCodeForSession(params.code);
          if (error) throw error;
        } else if (
          params.token_hash &&
          ['signup', 'recovery', 'email', 'invite', 'email_change'].includes(params.type ?? '')
        ) {
          const { error } = await c.auth.verifyOtp({
            token_hash: params.token_hash,
            type: params.type as EmailOtpType,
          });
          if (error) throw error;
        } else {
          const current = url ?? (typeof window !== 'undefined' ? window.location.href : '');
          const hash = new URLSearchParams(current.split('#')[1] ?? '');
          reset = reset || hash.get('type') === 'recovery';
          const access = hash.get('access_token'),
            refresh = hash.get('refresh_token');
          if (access && refresh) {
            const { error } = await c.auth.setSession({
              access_token: access,
              refresh_token: refresh,
            });
            if (error) throw error;
          } else {
            const { data, error } = await c.auth.getSession();
            if (error) throw error;
            if (!data.session)
              throw new Error(
                'This link has expired or was opened on a different device. Return to sign in and request a new email.',
              );
          }
        }
        if (reset) {
          setRecovery(true);
          setNotice('Choose your new password.');
        } else router.replace('/pulse');
      } catch (e) {
        setNotice(e instanceof Error ? e.message : 'Unable to confirm this link.');
      }
    })();
  }, [params.code, params.token_hash, params.type, params.recovery, url]);
  const save = async () => {
    setBusy(true);
    try {
      if (password.length < 10) throw new Error('Use at least 10 characters.');
      const { error } = await client().auth.updateUser({ password });
      if (error) throw error;
      router.replace('/pulse');
    } catch (e) {
      setNotice(e instanceof Error ? e.message : 'Please try again.');
    } finally {
      setBusy(false);
    }
  };
  return (
    <View style={{ flex: 1, backgroundColor: color.bg, justifyContent: 'center' }}>
      <ScrollView
        contentContainerStyle={{
          padding: 25,
          justifyContent: 'center',
          flexGrow: 1,
        }}
      >
        <View style={{ maxWidth: 480, width: '100%', alignSelf: 'center', gap: 20 }}>
          <Wordmark width={220} />
          <Card>
            <Txt>{notice}</Txt>
            {recovery ? (
              <>
                <Field
                  accessibilityLabel="New password"
                  label="New password"
                  value={password}
                  onChangeText={setPassword}
                  secureTextEntry
                  autoCapitalize="none"
                  autoComplete="new-password"
                />
                <Button
                  label={busy ? 'Updating…' : 'Update password'}
                  disabled={busy}
                  onPress={() => void save()}
                />
              </>
            ) : (
              <Button label="Return to sign in" subtle onPress={() => router.replace('/')} />
            )}
          </Card>
        </View>
      </ScrollView>
    </View>
  );
}
