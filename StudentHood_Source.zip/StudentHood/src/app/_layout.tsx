import React, { useEffect } from 'react';
import { Stack, router } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { Platform } from 'react-native';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import * as Notifications from 'expo-notifications';
import { AppProvider } from '../lib/AppProvider';

export default function RootLayout() {
  useEffect(() => {
    if (Platform.OS === 'web') return;
    const open = (r: Notifications.NotificationResponse) => {
      const t = r.notification.request.content.data?.thread_id;
      if (typeof t === 'string' && /^[0-9a-f-]{36}$/i.test(t))
        router.push({
          pathname: '/[page]',
          params: { page: 'ping', thread: t },
        });
    };
    const sub = Notifications.addNotificationResponseReceivedListener(open);
    Notifications.getLastNotificationResponseAsync().then((r) => {
      if (r) open(r);
    });
    return () => sub.remove();
  }, []);
  return (
    <SafeAreaProvider>
      <AppProvider>
        <StatusBar style="light" />
        <Stack
          screenOptions={{
            headerShown: false,
            contentStyle: { backgroundColor: '#080a13' },
            animation: 'fade',
          }}
        />
      </AppProvider>
    </SafeAreaProvider>
  );
}
