# Build StudentHood for web, mobile and iPad

This package contains the application source, branding, database schema, security policies, server functions and native build configuration. You do not need three separate codebases. The website and native apps connect to the same Supabase project, so a post or Ping sent on one device appears on another.

The provided website preview uses sample data until you connect a backend. No live Supabase project or Apple/Google signing account has been created for you.

## 1. Prepare your computer

Install Node.js **22.13 or newer** and an editor such as VS Code. Extract the source ZIP and open its `StudentHood` folder. Run:

```bash
npm ci
```

Keep `package-lock.json`. It records the tested versions, including Expo SDK 57 and React Native 0.86. For future native packages, use `npx expo install PACKAGE_NAME` to select SDK-compatible versions.

To inspect the sample website immediately:

```bash
npm run web
```

Use the address Expo prints. This preview is interactive, but its sample changes stay on that device.

## 2. Create the shared backend

Create your own project at [Supabase](https://supabase.com/dashboard). Use a **fresh, empty project** for these migrations. Keep your database password in your password manager.

In its SQL Editor, run the entire contents of these files, one at a time, in this order:

1. `supabase/migrations/202610030001_studenthood.sql`
2. `supabase/migrations/202610030002_inbox_and_limits.sql`
3. `supabase/migrations/202610030003_deletion_and_throttling.sql`

Each file is transactional. Do not run the same migration again after it succeeds. If a file fails, correct the reported error before continuing; do not remove security policies to make it pass.

The scripts create profiles, posts, social relationships, private conversations, groups, Gigs, activity notifications, reports, private media buckets and write limits. They also add the required public tables to the `supabase_realtime` publication. Account profiles are created automatically after Auth signup.

Check that Storage contains these **private** buckets:

| Bucket       | Purpose                       | Upload limit |
| ------------ | ----------------------------- | ------------ |
| `media`      | Pulse photos and Scene videos | 50 MB        |
| `avatars`    | Profile pictures              | 5 MB         |
| `ping-files` | Private message photos        | 10 MB        |

Photos accept JPEG, PNG and WebP. Scene videos accept MP4 and MOV. For broad playback compatibility, start with MP4 encoded using H.264/AAC. This version does not transcode videos or alter faces, crop photos or apply beauty filters.

For later schema changes, create a **new** numbered migration. Do not reset a database that already contains student accounts. You can use the [Supabase CLI migration workflow](https://supabase.com/docs/guides/deployment/database-migrations) instead of the SQL Editor when your team is ready.

## 3. Add public configuration

Copy `.env.example` to a new file named `.env` in the project root.

macOS/Linux:

```bash
cp .env.example .env
```

Windows PowerShell:

```powershell
Copy-Item .env.example .env
```

In Supabase's project settings/Connect dialog, copy the **Project URL** and **publishable API key**. Set:

```dotenv
EXPO_PUBLIC_SUPABASE_URL=https://YOUR_PROJECT_REF.supabase.co
EXPO_PUBLIC_SUPABASE_PUBLISHABLE_KEY=YOUR_PUBLISHABLE_KEY
EXPO_PUBLIC_WEB_URL=https://YOUR_WEBSITE_DOMAIN
```

These values are public configuration. Security comes from authenticated sessions and the SQL row-level security policies. **Never use the service role/secret API key in an `EXPO_PUBLIC_` variable.** Do not send it in chat or commit `.env`.

Use your eventual HTTPS website origin for `EXPO_PUBLIC_WEB_URL`, without a trailing slash. This is the destination used by mobile Share Scene links. You can leave it blank during initial local testing.

Stop Expo and restart it after changing configuration:

```bash
npx expo start --clear
```

With a configured backend, the sample preview banner disappears and the app opens its real sign-in screen. The connected feed starts empty.

## 4. Configure account emails and redirects

In Supabase Auth settings, enable email/password signup and email confirmation. Set a password minimum of **10 characters** or stronger. Configure your own SMTP sender before inviting real students; the default development sender has restrictions.

In **Auth → URL Configuration**:

- Set **Site URL** to your public HTTPS website origin.
- Allow `http://localhost:8081/**` for local web development, using the actual port Expo prints if it differs.
- Allow `https://YOUR_WEBSITE_DOMAIN/auth/callback` and `https://YOUR_WEBSITE_DOMAIN/auth/callback?recovery=1`.
- Allow `studenthood://auth/callback` and `studenthood://auth/callback?recovery=1` for the installed native app.

The app uses email confirmation and password-reset callbacks at `/auth/callback`. Its PKCE flow should be completed on the same device/browser where the email was requested. A different device can return to sign-in after email confirmation; request a new password-reset email from the device where you will complete it.

For production, keep redirect destinations specific to origins you control. Do not allow arbitrary third-party redirects. See [Supabase redirect URL documentation](https://supabase.com/docs/guides/auth/redirect-urls).

## 5. Deploy account deletion

Account deletion uses a server function because the browser and mobile app must never have an admin credential. Install/use the [Supabase CLI](https://supabase.com/docs/guides/local-development/cli/getting-started), then, from this project folder:

```bash
npx supabase@latest login
npx supabase@latest link --project-ref YOUR_PROJECT_REF
npx supabase@latest functions deploy delete-account
```

The Supabase server provides `SUPABASE_URL`, `SUPABASE_ANON_KEY` and `SUPABASE_SERVICE_ROLE_KEY` automatically. `verify_jwt = false` in `supabase/config.toml` is intentional: the function explicitly verifies the bearer session using Auth `getUser()` before it uses the server-only admin client. New publishable keys are not JWTs.

The function locks profile/storage writes, removes the user's files, then deletes the Auth account and related rows. It restores the lock/ban if a caught failure occurs. A process timeout can leave an account locked; see the recovery procedure below. Do not remove the third migration, which prevents old access tokens from uploading during deletion.

## 6. Run the live website locally

```bash
npm run web
```

Create Account A in one browser and Account B in an incognito window or another device. Confirm both emails and sign in. They share the same backend; their profiles should appear in Discover.

Run these acceptance checks:

1. A creates a Pulse with a photo. B sees it without reloading.
2. B likes/comments on it. A sees a Drop; no message entry is created in Drops.
3. A Pings B. B sees the request inside **Ping → Requests**. B cannot read/reply until accepting it.
4. B accepts, then both exchange text and photo Pings. Unread counts update, and opening the chat marks messages read.
5. A creates a Crew. B joins it and uses Crew Chat. After leaving, B loses chat access.
6. A creates a future Hang. B joins and opens its Hang Chat.
7. A posts a Gig. B applies; A reviews/accepts the application.
8. B blocks A. Direct conversation access and blocked posts disappear. Unblock in Settings to restore access.
9. Upload a Scene video and test playback and Share Scene on your target browsers/devices.
10. Create a temporary third account and test its complete account/file deletion. Do this only with test content.

The desktop header shows **Live** while the database channel is subscribed. Updates also refresh after reconnecting, on foregrounding the app and periodically. A temporary connection failure displays an error; Refresh retries the query.

Automated checks:

```bash
npm run typecheck
npm run lint
npm test
npm run build:web
npm run check:native
```

The native export check compiles iOS/Android JavaScript bundles. It does not create signed `.ipa`, `.apk` or `.aab` files.

## 7. Publish the website

The website export is an ordinary single-page app:

```bash
npm run build:web
```

The output is `dist/`. It needs SPA route fallback so direct visits to `/ping`, `/profile` and `/auth/callback` return `index.html`.

For the managed StudentHood website preview in this conversation, the source project is already linked to its website. Connecting the backend requires rebuilding that same project with your **public** configuration. The preview is private; students need a public website/domain when you launch.

For a portable deployment through your own Expo account:

```bash
npx eas-cli@latest login
npx eas-cli@latest init
npm run build:web
npx eas-cli@latest deploy
```

EAS prints the deployment URL. Set your Supabase Site URL/redirect allowlist and `EXPO_PUBLIC_WEB_URL` to the final public origin, then rebuild/redeploy. Follow [EAS Hosting setup](https://docs.expo.dev/eas/hosting/get-started/) for production aliases and custom domains. The project already uses `web.output = "single"`.

Any static host with HTTPS and SPA fallback can serve the export. The included `public/_redirects` is suitable for hosts that support that file; hosts that do not must be configured with their equivalent fallback. Supabase remains the shared backend regardless of the web host.

## 8. Build the iPhone, Android and iPad apps

### App identity

In `app.json`, set `ios.bundleIdentifier` and `android.package` to identifiers owned by you, for example `com.yourcompany.studenthood`. The supplied `com.rohy.studenthood` is an example, not proof of a registered store identity. Keep the same identifiers after first release.

The application name, official assets, dark interface, URL scheme and tablet support are already configured. `ios.supportsTablet = true` makes the **same iOS build** support iPhone and iPad. `orientation = "default"` allows the tablet interface to adapt in portrait and landscape. Test iPad Split View widths before release.

### Expo account and cloud configuration

Create/sign in to your own [Expo account](https://expo.dev/), then:

```bash
npx eas-cli@latest login
npx eas-cli@latest init
npx eas-cli@latest build:configure
```

`init` adds your real EAS project ID to the configuration. Do not invent it. EAS cloud builds can produce iOS and Android binaries without a local Mac; Apple signing still requires your own eligible Apple developer account.

In the EAS dashboard's environment-variable settings, add the same three `EXPO_PUBLIC_` values for **development**, **preview** and **production**. Use the actual intended backend for each environment; separate development/production Supabase projects are appropriate once real users exist.

These variables must be available at **build time**. A local ignored `.env` does not automatically travel to the cloud builder. Do not put server-only secrets in any EAS client environment.

### Development builds on real devices

```bash
npx eas-cli@latest build --platform android --profile development
npx eas-cli@latest build --platform ios --profile development
```

Follow EAS's signing/device-registration prompts. Install the resulting build links on your Android phone, iPhone and iPad. The iOS internal build must provision each test device or use the appropriate distribution method.

Then start Metro:

```bash
npx expo start --dev-client
```

Open the development build and connect using the printed link/QR. Keep the computer and device on a network they can reach. Use `--tunnel` only if local networking blocks access. Native development builds are the recommended path for this project; Expo Go is not a substitute for testing its native notification configuration.

### Test builds without the development server

```bash
npx eas-cli@latest build --platform android --profile preview
npx eas-cli@latest build --platform ios --profile preview
```

Android preview produces an installable APK. iOS internal distribution uses your signing/provisioning configuration. These builds bundle the app and communicate directly with Supabase; your computer does not need to stay running.

### Store builds and submission

```bash
npx eas-cli@latest build --platform all --profile production
npx eas-cli@latest submit --platform android --latest
npx eas-cli@latest submit --platform ios --latest
```

Use your Apple Developer/App Store Connect and Google Play Console accounts. EAS uploads the build; store listings, screenshots, privacy/data disclosures, test tracks, review and release decisions still happen in the store consoles. iPhone/iPad use the same iOS app listing with suitable device screenshots.

Before inviting real students, supply your own support contact, privacy policy/terms, report-review process and store disclosure answers. Reporting and blocking are coded; human review of reports is still your responsibility. The Supabase dashboard's `reports` table is the initial review surface.

## 9. Optional native Ping push

In-app real time works without push. Background push needs APNs/FCM credentials, a physical device, your EAS project ID and the optional server webhook.

1. Follow [Expo push setup](https://docs.expo.dev/push-notifications/push-notifications-setup/) for iOS APNs and Android FCM v1. Configure Android's Firebase file/credentials in your own project where required.
2. Generate a random webhook secret, at least 32 characters. Store it in Supabase's **Edge Function Secrets** as `PING_WEBHOOK_SECRET`. Never put it in `.env` with the public client values.
3. Deploy:

```bash
npx supabase@latest functions deploy ping-push
```

4. In Supabase **Database Webhooks**, create two INSERT webhooks: one for `public.messages`, one for `public.thread_members`. Both send HTTP POST to `https://YOUR_PROJECT_REF.supabase.co/functions/v1/ping-push`. Add `Content-Type: application/json` and `x-studenthood-webhook-secret: YOUR_RANDOM_SECRET`. No client publishable key replaces this private secret.
5. In the installed native app, open Settings → **Enable Ping push**. Grant notification permission.
6. Put one device in the background and send a Ping or new request from the other account. Tapping the notification opens Ping, subject to the same membership checks.

Notification text is generic; private message content is not placed on the lock screen. Native push is implemented for Ping messages/requests only. Browser push is not included. Drops stays free of message notifications.

If you enable Expo push access-token protection, put `EXPO_ACCESS_TOKEN` in Supabase's server secrets. The function removes immediate `DeviceNotRegistered` errors and logs successful push ticket IDs. For public operation, monitor the [Expo receipt API](https://docs.expo.dev/push-notifications/sending-notifications/) and remove invalid tokens; webhook/provider retries can produce duplicate notifications, and provider acceptance does not guarantee device delivery.

## 10. Troubleshooting and recovery

| Symptom                                    | What to check                                                                                                             |
| ------------------------------------------ | ------------------------------------------------------------------------------------------------------------------------- |
| Sample banner still appears                | Correct `.env` location/names; valid HTTPS project URL/public key; restart or rebuild after changes                       |
| Signed in but data query fails             | All three migrations completed; profile exists; exact Supabase project matches the client configuration                   |
| Confirmation/reset email link fails        | SMTP sender, Auth redirect allowlist, `/auth/callback` SPA fallback; open PKCE link on requesting device                  |
| Changes appear only after refresh          | Realtime publication includes required tables; WebSocket is allowed by the network; check Supabase service/channel status |
| Scene does not play                        | Use a compatible MP4/H.264/AAC file; browser/device codec support differs; MOV is not universally playable                |
| Upload is rejected                         | Supported MIME type, bucket size limit, own file path and active membership for private Ping files                        |
| Phone cannot connect to Metro              | Use the installed development build, correct local address and reachable network; investigate tunnel/firewall if needed   |
| Push token error                           | Physical device, real EAS project ID, native build, notification permission and APNs/FCM configuration                    |
| Account deletion says function unavailable | Deploy `delete-account`; verify its server environment and function logs                                                  |
| Too many requests                          | Database limits are intentional; wait for the current interval. Deleting content does not reset them                      |

For a rare timed-out account deletion, an owner/admin can inspect `profiles.deleting_at` and Auth user ban status. Check whether files were partially removed. To restore access before retrying, clear `deleting_at` using the SQL Editor and remove the user's ban in Auth administration. Do this only for the affected user's verified account. Existing test files removed during a failed deletion cannot be restored by this code.

## What is verified and what remains

The source is typechecked/linted and includes executable PostgreSQL security tests. The delivered web export and native JavaScript exports are separate from device/store verification. No claim is made that a signed app has already passed Apple/Google review or that your future Supabase project's network/email configuration has been tested.

This first release intentionally omits payments, automatic university verification, video transcoding, offline message queues and a dedicated moderation dashboard. It uses bounded directory/feed queries; add cursor pagination/server aggregates and stronger abuse tooling as usage grows. See [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md) for details.

Official references: [Expo SDK 57](https://docs.expo.dev/versions/v57.0.0/), [Expo Router](https://docs.expo.dev/router/introduction/), [EAS Build](https://docs.expo.dev/build/introduction/), [EAS Hosting](https://docs.expo.dev/eas/hosting/get-started/), [EAS environment variables](https://docs.expo.dev/eas/environment-variables/), [Supabase native Auth](https://supabase.com/docs/guides/auth/quickstarts/react-native), [Realtime Postgres Changes](https://supabase.com/docs/guides/realtime/postgres-changes), [Edge Function authentication](https://supabase.com/docs/guides/functions/auth).
