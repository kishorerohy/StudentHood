import { createClient } from 'npm:@supabase/supabase-js@2.117.2';
import { cors, json, required } from '../_shared/http.ts';

// The service key exists only in the Supabase server environment.
// Every call verifies the caller with Auth before using the admin client.
Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: cors });
  if (req.method !== 'POST') return json({ error: 'Method not allowed' }, 405);
  try {
    const authorization = req.headers.get('Authorization');
    if (!authorization?.startsWith('Bearer ')) return json({ error: 'Sign in first' }, 401);
    const url = required('SUPABASE_URL');
    const auth = createClient(url, required('SUPABASE_ANON_KEY'), {
      global: { headers: { Authorization: authorization } },
      auth: { persistSession: false },
    });
    const {
      data: { user },
      error,
    } = await auth.auth.getUser();
    if (error || !user) return json({ error: 'Invalid session' }, 401);
    const body = await req.json();
    if (body.confirm !== 'DELETE')
      return json({ error: 'Account deletion requires DELETE confirmation' }, 400);
    const admin = createClient(url, required('SUPABASE_SERVICE_ROLE_KEY'), {
      auth: { persistSession: false },
    });
    // Stop writes from old access tokens while files are being removed.
    const { error: lockError } = await admin
      .from('profiles')
      .update({ deleting_at: new Date().toISOString() })
      .eq('id', user.id);
    if (lockError) throw lockError;
    const removeFolder = async (bucket: string, prefix: string): Promise<void> => {
      let offset = 0;
      const names: string[] = [];
      const folders: string[] = [];
      while (true) {
        const { data, error } = await admin.storage.from(bucket).list(prefix, {
          limit: 100,
          offset,
          sortBy: { column: 'name', order: 'asc' },
        });
        if (error) throw error;
        if (!data?.length) break;
        for (const file of data) {
          const path = `${prefix}/${file.name}`;
          if (file.id) names.push(path);
          else folders.push(path);
        }
        offset += data.length;
      }
      for (const folder of folders) await removeFolder(bucket, folder);
      for (let i = 0; i < names.length; i += 100) {
        const { error } = await admin.storage.from(bucket).remove(names.slice(i, i + 100));
        if (error) throw error;
      }
    };
    try {
      const { error: banError } = await admin.auth.admin.updateUserById(user.id, {
        ban_duration: '876000h',
      });
      if (banError) throw banError;
      for (const bucket of ['media', 'avatars', 'ping-files']) await removeFolder(bucket, user.id);
      const { error: deleteError } = await admin.auth.admin.deleteUser(user.id);
      if (deleteError) throw deleteError;
    } catch (e) {
      await admin.from('profiles').update({ deleting_at: null }).eq('id', user.id);
      await admin.auth.admin.updateUserById(user.id, { ban_duration: 'none' });
      throw e;
    }
    return json({ deleted: true });
  } catch (e) {
    console.error('Account deletion failed', e instanceof Error ? e.message : 'unknown');
    return json(
      {
        error: 'Unable to finish deleting your account. Please retry or contact support.',
      },
      500,
    );
  }
});
