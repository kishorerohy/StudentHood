import { createClient } from 'npm:@supabase/supabase-js@2.117.2';
import { json, required } from '../_shared/http.ts';

async function sameSecret(a: string, b: string) {
  const digest = async (s: string) =>
    new Uint8Array(await crypto.subtle.digest('SHA-256', new TextEncoder().encode(s)));
  const [x, y] = await Promise.all([digest(a), digest(b)]);
  let mismatch = 0;
  for (let i = 0; i < x.length; i++) mismatch |= x[i] ^ y[i];
  return mismatch === 0;
}
type RecordData = { id?: string; thread_id?: string; user_id?: string };
Deno.serve(async (req) => {
  if (req.method !== 'POST') return json({ error: 'Method not allowed' }, 405);
  try {
    const secret = required('PING_WEBHOOK_SECRET');
    if (secret.length < 32) throw new Error('Use a webhook secret of at least 32 characters');
    if (!(await sameSecret(req.headers.get('x-studenthood-webhook-secret') ?? '', secret)))
      return json({ error: 'Unauthorized' }, 401);
    const payload = (await req.json()) as {
      type: string;
      schema: string;
      table: string;
      record: RecordData;
    };
    if (
      payload.type !== 'INSERT' ||
      payload.schema !== 'public' ||
      !['messages', 'thread_members'].includes(payload.table)
    )
      return json({ error: 'Unsupported event' }, 400);
    const admin = createClient(required('SUPABASE_URL'), required('SUPABASE_SERVICE_ROLE_KEY'), {
      auth: { persistSession: false },
    });
    let thread: string,
      actor: string,
      recipient: string | undefined,
      request = false;
    if (payload.table === 'messages') {
      const { data, error } = await admin
        .from('messages')
        .select('id,thread_id,author_id')
        .eq('id', payload.record.id ?? '')
        .single();
      if (error || !data) return json({ ignored: true });
      thread = data.thread_id;
      actor = data.author_id;
    } else {
      const { data, error } = await admin
        .from('thread_members')
        .select('thread_id,user_id,status')
        .eq('thread_id', payload.record.thread_id ?? '')
        .eq('user_id', payload.record.user_id ?? '')
        .single();
      if (error || !data || data.status !== 'invited') return json({ ignored: true });
      const { data: t, error: te } = await admin
        .from('threads')
        .select('created_by,kind')
        .eq('id', data.thread_id)
        .single();
      if (te || !t || t.kind !== 'direct') return json({ ignored: true });
      thread = data.thread_id;
      actor = t.created_by;
      recipient = data.user_id;
      request = true;
    }
    const { data: members, error: memberError } = await admin
      .from('thread_members')
      .select('user_id,status')
      .eq('thread_id', thread);
    if (memberError) throw memberError;
    const candidates = (members ?? [])
      .filter(
        (m) => m.user_id !== actor && (request ? m.user_id === recipient : m.status === 'active'),
      )
      .map((m) => m.user_id);
    if (!candidates.length) return json({ sent: 0 });
    // Query all blocks touching the author and apply the check per recipient.
    const { data: blocks, error: be } = await admin
      .from('blocks')
      .select('blocker_id,blocked_id')
      .or(`blocker_id.eq.${actor},blocked_id.eq.${actor}`);
    if (be) throw be;
    const allowed = candidates.filter(
      (user) =>
        !blocks?.some(
          (b) =>
            (b.blocker_id === actor && b.blocked_id === user) ||
            (b.blocker_id === user && b.blocked_id === actor),
        ),
    );
    if (!allowed.length) return json({ sent: 0 });
    const { data: tokens, error: te } = await admin
      .from('device_tokens')
      .select('user_id,token')
      .in('user_id', allowed);
    if (te) throw te;
    let sent = 0;
    const ticketIds: string[] = [];
    for (let i = 0; i < (tokens?.length ?? 0); i += 100) {
      const batch = tokens!.slice(i, i + 100);
      const access = Deno.env.get('EXPO_ACCESS_TOKEN');
      const response = await fetch('https://exp.host/--/api/v2/push/send', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(access ? { Authorization: `Bearer ${access}` } : {}),
        },
        body: JSON.stringify(
          batch.map((t) => ({
            to: t.token,
            title: 'StudentHood · Ping',
            body: request ? 'You have a new Ping request.' : 'You have a new Ping.',
            sound: 'default',
            channelId: 'ping',
            data: { thread_id: thread },
          })),
        ),
      });
      if (!response.ok) throw new Error(`Push provider returned ${response.status}`);
      const result = await response.json();
      if (!Array.isArray(result.data)) throw new Error('Invalid push response');
      for (let n = 0; n < result.data.length; n++) {
        const ticket = result.data[n];
        if (ticket.status === 'ok') {
          sent++;
          if (ticket.id) ticketIds.push(ticket.id);
        } else if (ticket.details?.error === 'DeviceNotRegistered') {
          await admin
            .from('device_tokens')
            .delete()
            .eq('user_id', batch[n].user_id)
            .eq('token', batch[n].token);
        }
      }
    }
    // Monitor these ticket IDs with Expo's receipt API before a public launch.
    // Delivery is best effort and webhook retries can produce duplicates.
    console.log('Ping push tickets', JSON.stringify(ticketIds));
    return json({ sent });
  } catch (e) {
    console.error('Ping push failed', e instanceof Error ? e.message : 'unknown');
    return json({ error: 'Push delivery failed' }, 500);
  }
});
