-- StudentHood v1. Run once on a fresh Supabase project, or use supabase db push.
begin;

create table public.profiles (
 id uuid primary key references auth.users(id) on delete cascade,
 handle text not null unique check(handle ~ '^[a-z0-9_]{3,30}$'),
 display_name text not null check(length(display_name) between 1 and 80),
 university text not null default '' check(length(university)<=120),
 city text not null default 'Manchester' check(length(city) between 1 and 80),
 bio text not null default '' check(length(bio)<=500), avatar_path text,
 created_at timestamptz not null default now()
);
create table public.blocks (
 blocker_id uuid references public.profiles on delete cascade,
 blocked_id uuid references public.profiles on delete cascade,
 primary key(blocker_id,blocked_id), check(blocker_id<>blocked_id)
);
create table public.peeps (
 id uuid primary key default gen_random_uuid(),
 requester_id uuid not null references public.profiles on delete cascade,
 recipient_id uuid not null references public.profiles on delete cascade,
 status text not null default 'pending' check(status in ('pending','accepted')),
 created_at timestamptz not null default now(), check(requester_id<>recipient_id)
);
create unique index peeps_pair on public.peeps(least(requester_id,recipient_id),greatest(requester_id,recipient_id));
create table public.posts (
 id uuid primary key default gen_random_uuid(), author_id uuid not null references public.profiles on delete cascade,
 kind text not null check(kind in ('pulse','scene')), body text not null default '' check(length(body)<=4000),
 media_path text, media_type text check(media_type in ('image','video')),
 city text not null, university text not null default '', created_at timestamptz not null default now(),
 check(length(trim(body))>0 or media_path is not null),
 check((media_path is null)=(media_type is null)),
 check(kind<>'scene' or (media_type='video' and media_path is not null))
);
create table public.post_likes (
 post_id uuid references public.posts on delete cascade, user_id uuid references public.profiles on delete cascade,
 created_at timestamptz not null default now(), primary key(post_id,user_id)
);
create table public.bookmarks (
 post_id uuid references public.posts on delete cascade, user_id uuid references public.profiles on delete cascade,
 primary key(post_id,user_id)
);
create table public.comments (
 id uuid primary key default gen_random_uuid(), post_id uuid not null references public.posts on delete cascade,
 author_id uuid not null references public.profiles on delete cascade, body text not null check(length(trim(body)) between 1 and 2000),
 created_at timestamptz not null default now()
);
create table public.threads (
 id uuid primary key default gen_random_uuid(), kind text not null check(kind in ('direct','hang','crew')),
 title text not null default '', created_by uuid not null references public.profiles on delete cascade,
 direct_key text unique, created_at timestamptz not null default now(),
 check((kind='direct')=(direct_key is not null))
);
create table public.thread_members (
 thread_id uuid references public.threads on delete cascade, user_id uuid references public.profiles on delete cascade,
 status text not null default 'active' check(status in ('invited','active')),
 last_read_at timestamptz not null default now(), primary key(thread_id,user_id)
);
create table public.messages (
 id uuid primary key default gen_random_uuid(), thread_id uuid not null references public.threads on delete cascade,
 author_id uuid not null references public.profiles on delete cascade,
 body text not null default '' check(length(body)<=4000), attachment_path text,
 created_at timestamptz not null default now(), check(length(trim(body))>0 or attachment_path is not null)
);
create table public.hangs (
 id uuid primary key default gen_random_uuid(), creator_id uuid not null references public.profiles on delete cascade,
 thread_id uuid not null unique references public.threads on delete cascade,
 title text not null check(length(trim(title)) between 1 and 120), description text not null default '' check(length(description)<=3000),
 city text not null, university text not null default '', location text not null check(length(location) between 1 and 200),
 starts_at timestamptz not null, created_at timestamptz not null default now()
);
create table public.hang_members (
 hang_id uuid references public.hangs on delete cascade, user_id uuid references public.profiles on delete cascade,
 created_at timestamptz not null default now(), primary key(hang_id,user_id)
);
create table public.crews (
 id uuid primary key default gen_random_uuid(), creator_id uuid not null references public.profiles on delete cascade,
 thread_id uuid not null unique references public.threads on delete cascade,
 title text not null check(length(trim(title)) between 1 and 120), description text not null default '' check(length(description)<=3000),
 city text not null, university text not null default '', created_at timestamptz not null default now()
);
create table public.crew_members (
 crew_id uuid references public.crews on delete cascade, user_id uuid references public.profiles on delete cascade,
 created_at timestamptz not null default now(), primary key(crew_id,user_id)
);
create table public.gigs (
 id uuid primary key default gen_random_uuid(), creator_id uuid not null references public.profiles on delete cascade,
 title text not null check(length(trim(title)) between 1 and 120), description text not null check(length(trim(description)) between 1 and 3000),
 city text not null, university text not null default '', amount numeric(10,2) not null check(amount>=0),
 currency text not null default 'GBP' check(currency in ('GBP','INR','USD','EUR')),
 created_at timestamptz not null default now()
);
create table public.gig_applications (
 id uuid primary key default gen_random_uuid(), gig_id uuid not null references public.gigs on delete cascade,
 applicant_id uuid not null references public.profiles on delete cascade,
 body text not null check(length(trim(body)) between 1 and 2000),
 status text not null default 'submitted' check(status in ('submitted','accepted','declined')),
 created_at timestamptz not null default now(), unique(gig_id,applicant_id)
);
create table public.drops (
 id uuid primary key default gen_random_uuid(), recipient_id uuid not null references public.profiles on delete cascade,
 actor_id uuid references public.profiles on delete cascade,
 kind text not null check(kind in ('peep','post_like','comment','hang','crew','gig')),
 title text not null, target_id uuid, read_at timestamptz,
 created_at timestamptz not null default now()
);
create table public.reports (
 id uuid primary key default gen_random_uuid(), reporter_id uuid not null references public.profiles on delete cascade,
 target_type text not null check(target_type in ('post','profile','message','hang','crew','gig')),
 target_id uuid not null, reason text not null check(length(trim(reason)) between 3 and 2000),
 created_at timestamptz not null default now()
);
create table public.device_tokens (
 user_id uuid references public.profiles on delete cascade, token text not null,
 created_at timestamptz not null default now(), primary key(user_id,token)
);

create index posts_timeline on public.posts(created_at desc,id desc);
create index posts_author on public.posts(author_id);
create index comments_post on public.comments(post_id,created_at);
create index peeps_recipient on public.peeps(recipient_id,status);
create index peeps_requester on public.peeps(requester_id,status);
create index thread_members_user on public.thread_members(user_id,status);
create index messages_thread on public.messages(thread_id,created_at desc);
create index drops_recipient on public.drops(recipient_id,created_at desc);
create index hang_members_user on public.hang_members(user_id);
create index crew_members_user on public.crew_members(user_id);
create index applications_owner on public.gig_applications(applicant_id);

-- Helpers bypass RLS only to answer membership/block checks. All mutating RPCs
-- explicitly use auth.uid(), never a client-supplied acting user.
create function public.is_blocked(peer uuid) returns boolean language sql stable security definer set search_path=public,pg_temp as $$
 select exists(select 1 from public.blocks where
 (blocker_id=auth.uid() and blocked_id=peer) or (blocker_id=peer and blocked_id=auth.uid()));
$$;
create function public.is_thread_member(t uuid,active_only boolean default true) returns boolean language sql stable security definer set search_path=public,pg_temp as $$
 select exists(select 1 from public.thread_members m where m.thread_id=t and m.user_id=auth.uid()
 and (not active_only or m.status='active'))
 and not exists(select 1 from public.threads x join public.thread_members other on other.thread_id=x.id
 where x.id=t and x.kind='direct' and other.user_id<>auth.uid() and public.is_blocked(other.user_id));
$$;
create function public.visible_post(p uuid) returns boolean language sql stable security definer set search_path=public,pg_temp as $$
 select auth.uid() is not null and exists(select 1 from public.posts where id=p and not public.is_blocked(author_id));
$$;
create function public.thread_from_path(p text) returns uuid language sql immutable set search_path=public,pg_temp as $$
 select case when split_part(p,'/',2) ~ '^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$'
 then split_part(p,'/',2)::uuid else null end;
$$;
create function public.profile_from_path(p text) returns uuid language sql immutable set search_path=public,pg_temp as $$
 select case when split_part(p,'/',1) ~ '^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$'
 then split_part(p,'/',1)::uuid else null end;
$$;
create function public.create_profile() returns trigger language plpgsql security definer set search_path=public,pg_temp as $$
begin
 insert into public.profiles(id,handle,display_name,university,city)
 values(new.id,'student_'||left(replace(new.id::text,'-',''),20),
 left(coalesce(nullif(new.raw_user_meta_data->>'display_name',''),'Student'),80),
 left(coalesce(new.raw_user_meta_data->>'university',''),120),
 left(coalesce(nullif(new.raw_user_meta_data->>'city',''),'Manchester'),80));
 return new;
end; $$;
create trigger on_student_signup after insert on auth.users for each row execute function public.create_profile();

create function public.request_peep(peer uuid) returns uuid language plpgsql security definer set search_path=public,pg_temp as $$
declare result uuid;
begin
 if auth.uid() is null or peer=auth.uid() or public.is_blocked(peer) then raise exception 'Peep unavailable'; end if;
 insert into public.peeps(requester_id,recipient_id) values(auth.uid(),peer) on conflict do nothing returning id into result;
 if result is null then select id into result from public.peeps where least(requester_id,recipient_id)=least(auth.uid(),peer) and greatest(requester_id,recipient_id)=greatest(auth.uid(),peer); end if;
 return result;
end; $$;
create function public.respond_peep(request_id uuid,accept boolean) returns void language plpgsql security definer set search_path=public,pg_temp as $$
begin
 if not exists(select 1 from public.peeps where id=request_id and recipient_id=auth.uid() and status='pending' and not public.is_blocked(requester_id)) then raise exception 'Peep request unavailable'; end if;
 if accept then update public.peeps set status='accepted' where id=request_id; else delete from public.peeps where id=request_id; end if;
end; $$;
create function public.start_ping(peer uuid) returns uuid language plpgsql security definer set search_path=public,pg_temp as $$
declare t uuid; k text; accepted boolean;
begin
 if auth.uid() is null or peer=auth.uid() or public.is_blocked(peer) or not exists(select 1 from public.profiles where id=peer) then raise exception 'Ping unavailable'; end if;
 k=least(auth.uid(),peer)::text||':'||greatest(auth.uid(),peer)::text;
 insert into public.threads(kind,created_by,direct_key) values('direct',auth.uid(),k) on conflict(direct_key) do nothing returning id into t;
 if t is null then select id into t from public.threads where direct_key=k; return t; end if;
 select exists(select 1 from public.peeps where status='accepted' and least(requester_id,recipient_id)=least(auth.uid(),peer) and greatest(requester_id,recipient_id)=greatest(auth.uid(),peer)) into accepted;
 insert into public.thread_members(thread_id,user_id,status) values(t,auth.uid(),'active'),(t,peer,case when accepted then 'active' else 'invited' end);
 return t;
end; $$;
create function public.respond_ping(t uuid,accept boolean) returns void language plpgsql security definer set search_path=public,pg_temp as $$
begin
 if not public.is_thread_member(t,false) or not exists(select 1 from public.thread_members where thread_id=t and user_id=auth.uid() and status='invited') then raise exception 'Ping request unavailable'; end if;
 if accept then update public.thread_members set status='active' where thread_id=t and user_id=auth.uid(); else delete from public.threads where id=t and kind='direct'; end if;
end; $$;
create function public.create_hang(title_input text,description_input text,location_input text,starts_input timestamptz) returns uuid language plpgsql security definer set search_path=public,pg_temp as $$
declare t uuid; h uuid; p public.profiles;
begin
 select * into p from public.profiles where id=auth.uid(); if p.id is null then raise exception 'Sign in first'; end if;
 insert into public.threads(kind,created_by,title) values('hang',p.id,title_input) returning id into t;
 insert into public.hangs(creator_id,thread_id,title,description,city,university,location,starts_at) values(p.id,t,title_input,description_input,p.city,p.university,location_input,starts_input) returning id into h;
 insert into public.hang_members values(h,p.id,now()); insert into public.thread_members(thread_id,user_id) values(t,p.id); return h;
end; $$;
create function public.create_crew(title_input text,description_input text) returns uuid language plpgsql security definer set search_path=public,pg_temp as $$
declare t uuid; c uuid; p public.profiles;
begin
 select * into p from public.profiles where id=auth.uid(); if p.id is null then raise exception 'Sign in first'; end if;
 insert into public.threads(kind,created_by,title) values('crew',p.id,title_input) returning id into t;
 insert into public.crews(creator_id,thread_id,title,description,city,university) values(p.id,t,title_input,description_input,p.city,p.university) returning id into c;
 insert into public.crew_members values(c,p.id,now()); insert into public.thread_members(thread_id,user_id) values(t,p.id); return c;
end; $$;
create function public.join_group(resource_id uuid,resource_type text,joining boolean default true) returns void language plpgsql security definer set search_path=public,pg_temp as $$
declare t uuid; owner_id uuid;
begin
 if auth.uid() is null then raise exception 'Sign in first'; end if;
 if resource_type='hang' then select thread_id,creator_id into t,owner_id from public.hangs where id=resource_id;
 elsif resource_type='crew' then select thread_id,creator_id into t,owner_id from public.crews where id=resource_id;
 else raise exception 'Invalid group'; end if;
 if t is null or public.is_blocked(owner_id) then raise exception 'Group unavailable'; end if;
 if not joining and owner_id=auth.uid() then raise exception 'The creator must delete the group instead'; end if;
 if joining then
  if resource_type='hang' then insert into public.hang_members(hang_id,user_id) values(resource_id,auth.uid()) on conflict do nothing;
  else insert into public.crew_members(crew_id,user_id) values(resource_id,auth.uid()) on conflict do nothing; end if;
  insert into public.thread_members(thread_id,user_id) values(t,auth.uid()) on conflict(thread_id,user_id) do update set status='active';
 else
  if resource_type='hang' then delete from public.hang_members where hang_id=resource_id and user_id=auth.uid();
  else delete from public.crew_members where crew_id=resource_id and user_id=auth.uid(); end if;
  delete from public.thread_members where thread_id=t and user_id=auth.uid();
 end if;
end; $$;
create function public.delete_group(resource_id uuid,resource_type text) returns void language plpgsql security definer set search_path=public,pg_temp as $$
declare t uuid;
begin
 if resource_type='hang' then select thread_id into t from public.hangs where id=resource_id and creator_id=auth.uid();
 elsif resource_type='crew' then select thread_id into t from public.crews where id=resource_id and creator_id=auth.uid(); end if;
 if t is null then raise exception 'Only the creator can delete this group'; end if;
 delete from public.threads where id=t;
end; $$;

-- Drops is deliberately incapable of representing a Ping or Ping request.
-- Client roles cannot insert Drops: only these database triggers create them.
create function public.activity_drop() returns trigger language plpgsql security definer set search_path=public,pg_temp as $$
declare recipient uuid; actor uuid; target uuid; activity text; headline text;
begin
 if tg_table_name='post_likes' then select author_id into recipient from public.posts where id=new.post_id; actor=new.user_id; target=new.post_id; activity='post_like'; headline='liked your post';
 elsif tg_table_name='comments' then select author_id into recipient from public.posts where id=new.post_id; actor=new.author_id; target=new.post_id; activity='comment'; headline='commented on your post';
 elsif tg_table_name='peeps' then
  if tg_op='INSERT' then recipient=new.recipient_id; actor=new.requester_id; headline='sent you a Peep request';
  elsif new.status='accepted' and old.status<>new.status then recipient=new.requester_id; actor=new.recipient_id; headline='accepted your Peep request'; else return new; end if;
  target=new.id; activity='peep';
 elsif tg_table_name='hang_members' then select creator_id into recipient from public.hangs where id=new.hang_id; actor=new.user_id; target=new.hang_id; activity='hang'; headline='joined your Hang';
 elsif tg_table_name='crew_members' then select creator_id into recipient from public.crews where id=new.crew_id; actor=new.user_id; target=new.crew_id; activity='crew'; headline='joined your Crew';
 elsif tg_table_name='gig_applications' then
  if tg_op='INSERT' then select creator_id into recipient from public.gigs where id=new.gig_id; actor=new.applicant_id; headline='applied for your Gig';
  elsif new.status<>old.status then recipient=new.applicant_id; select creator_id into actor from public.gigs where id=new.gig_id; headline='updated your Gig application'; else return new; end if;
  target=new.gig_id; activity='gig';
 end if;
 if recipient is not null and recipient<>actor and not exists(select 1 from public.blocks where (blocker_id=recipient and blocked_id=actor) or (blocker_id=actor and blocked_id=recipient)) then
 insert into public.drops(recipient_id,actor_id,kind,title,target_id) values(recipient,actor,activity,coalesce((select display_name from public.profiles where id=actor),'A Peep')||' '||headline,target);
 end if; return new;
end; $$;
create trigger liked_post after insert on public.post_likes for each row execute function public.activity_drop();
create trigger commented_post after insert on public.comments for each row execute function public.activity_drop();
create trigger peep_activity after insert or update on public.peeps for each row execute function public.activity_drop();
create trigger hang_activity after insert on public.hang_members for each row execute function public.activity_drop();
create trigger crew_activity after insert on public.crew_members for each row execute function public.activity_drop();
create trigger gig_activity after insert or update on public.gig_applications for each row execute function public.activity_drop();

-- Row-level security is the server-side permission boundary on every platform.
do $$ declare t text; begin foreach t in array array['profiles','blocks','peeps','posts','post_likes','bookmarks','comments','threads','thread_members','messages','hangs','hang_members','crews','crew_members','gigs','gig_applications','drops','reports','device_tokens'] loop
 execute format('alter table public.%I enable row level security',t);
 execute format('revoke all on public.%I from anon, authenticated',t);
 execute format('grant select on public.%I to authenticated',t);
 end loop; end $$;
grant usage on schema public to authenticated;
create policy profiles_read on public.profiles for select to authenticated using(not public.is_blocked(id));
create policy profiles_edit on public.profiles for update to authenticated using(id=auth.uid()) with check(id=auth.uid() and (avatar_path is null or public.profile_from_path(avatar_path)=auth.uid()));
grant update(handle,display_name,university,city,bio,avatar_path) on public.profiles to authenticated;
create policy blocks_read on public.blocks for select to authenticated using(blocker_id=auth.uid());
create policy blocks_add on public.blocks for insert to authenticated with check(blocker_id=auth.uid());
create policy blocks_remove on public.blocks for delete to authenticated using(blocker_id=auth.uid());
grant insert,delete on public.blocks to authenticated;
create policy peeps_read on public.peeps for select to authenticated using((requester_id=auth.uid() or recipient_id=auth.uid()) and not public.is_blocked(case when requester_id=auth.uid() then recipient_id else requester_id end));
create policy peeps_remove on public.peeps for delete to authenticated using(requester_id=auth.uid() or recipient_id=auth.uid());
grant delete on public.peeps to authenticated;
create policy posts_read on public.posts for select to authenticated using(not public.is_blocked(author_id));
create policy posts_add on public.posts for insert to authenticated with check(author_id=auth.uid() and (media_path is null or public.profile_from_path(media_path)=auth.uid()));
create policy posts_edit on public.posts for update to authenticated using(author_id=auth.uid()) with check(author_id=auth.uid() and (media_path is null or public.profile_from_path(media_path)=auth.uid()));
create policy posts_remove on public.posts for delete to authenticated using(author_id=auth.uid());
grant insert,delete on public.posts to authenticated; grant update(body,media_path,media_type) on public.posts to authenticated;
create policy likes_read on public.post_likes for select to authenticated using(public.visible_post(post_id) and not public.is_blocked(user_id));
create policy likes_add on public.post_likes for insert to authenticated with check(user_id=auth.uid() and public.visible_post(post_id));
create policy likes_remove on public.post_likes for delete to authenticated using(user_id=auth.uid());
grant insert,delete on public.post_likes to authenticated;
create policy bookmarks_read on public.bookmarks for select to authenticated using(user_id=auth.uid());
create policy bookmarks_add on public.bookmarks for insert to authenticated with check(user_id=auth.uid() and public.visible_post(post_id));
create policy bookmarks_remove on public.bookmarks for delete to authenticated using(user_id=auth.uid());
grant insert,delete on public.bookmarks to authenticated;
create policy comments_read on public.comments for select to authenticated using(public.visible_post(post_id) and not public.is_blocked(author_id));
create policy comments_add on public.comments for insert to authenticated with check(author_id=auth.uid() and public.visible_post(post_id));
create policy comments_remove on public.comments for delete to authenticated using(author_id=auth.uid());
grant insert,delete on public.comments to authenticated;
create policy threads_read on public.threads for select to authenticated using(public.is_thread_member(id,false));
create policy members_read on public.thread_members for select to authenticated using(public.is_thread_member(thread_id,false));
create policy members_read_marker on public.thread_members for update to authenticated using(user_id=auth.uid() and public.is_thread_member(thread_id)) with check(user_id=auth.uid());
grant update(last_read_at) on public.thread_members to authenticated;
create policy messages_read on public.messages for select to authenticated using(public.is_thread_member(thread_id) and not public.is_blocked(author_id));
create policy messages_add on public.messages for insert to authenticated with check(author_id=auth.uid() and public.is_thread_member(thread_id) and (attachment_path is null or (public.profile_from_path(attachment_path)=auth.uid() and public.thread_from_path(attachment_path)=thread_id)));
create policy messages_remove on public.messages for delete to authenticated using(author_id=auth.uid());
grant insert,delete on public.messages to authenticated;
create policy hangs_read on public.hangs for select to authenticated using(not public.is_blocked(creator_id));
create policy hang_members_read on public.hang_members for select to authenticated using(exists(select 1 from public.hangs where id=hang_id) and not public.is_blocked(user_id));
create policy crews_read on public.crews for select to authenticated using(not public.is_blocked(creator_id));
create policy crew_members_read on public.crew_members for select to authenticated using(exists(select 1 from public.crews where id=crew_id) and not public.is_blocked(user_id));
create policy gigs_read on public.gigs for select to authenticated using(not public.is_blocked(creator_id));
create policy gigs_add on public.gigs for insert to authenticated with check(creator_id=auth.uid());
create policy gigs_remove on public.gigs for delete to authenticated using(creator_id=auth.uid());
grant insert,delete on public.gigs to authenticated;
create policy applications_read on public.gig_applications for select to authenticated using(applicant_id=auth.uid() or exists(select 1 from public.gigs where id=gig_id and creator_id=auth.uid()));
create policy applications_add on public.gig_applications for insert to authenticated with check(applicant_id=auth.uid() and status='submitted' and exists(select 1 from public.gigs where id=gig_id and creator_id<>auth.uid() and not public.is_blocked(creator_id)));
create policy applications_edit on public.gig_applications for update to authenticated using(exists(select 1 from public.gigs where id=gig_id and creator_id=auth.uid())) with check(exists(select 1 from public.gigs where id=gig_id and creator_id=auth.uid()));
grant insert on public.gig_applications to authenticated; grant update(status) on public.gig_applications to authenticated;
create policy drops_read on public.drops for select to authenticated using(recipient_id=auth.uid() and (actor_id is null or not public.is_blocked(actor_id)));
create policy drops_mark on public.drops for update to authenticated using(recipient_id=auth.uid()) with check(recipient_id=auth.uid());
grant update(read_at) on public.drops to authenticated;
create policy reports_read on public.reports for select to authenticated using(reporter_id=auth.uid());
create policy reports_add on public.reports for insert to authenticated with check(reporter_id=auth.uid() and (
 (target_type='post' and public.visible_post(target_id)) or
 (target_type='profile' and exists(select 1 from public.profiles where id=target_id)) or
 (target_type='message' and exists(select 1 from public.messages where id=target_id)) or
 (target_type='hang' and exists(select 1 from public.hangs where id=target_id)) or
 (target_type='crew' and exists(select 1 from public.crews where id=target_id)) or
 (target_type='gig' and exists(select 1 from public.gigs where id=target_id))));
grant insert on public.reports to authenticated;
create policy tokens_read on public.device_tokens for select to authenticated using(user_id=auth.uid());
create policy tokens_add on public.device_tokens for insert to authenticated with check(user_id=auth.uid() and token ~ '^Expo(nent)?PushToken\[');
create policy tokens_delete on public.device_tokens for delete to authenticated using(user_id=auth.uid());
grant insert,delete on public.device_tokens to authenticated;

-- Never expose definer functions to anonymous callers.
revoke all on function public.is_blocked(uuid),public.is_thread_member(uuid,boolean),public.visible_post(uuid),public.thread_from_path(text),public.profile_from_path(text),public.create_profile(),public.activity_drop(),
 public.request_peep(uuid),public.respond_peep(uuid,boolean),public.start_ping(uuid),public.respond_ping(uuid,boolean),
 public.create_hang(text,text,text,timestamptz),public.create_crew(text,text),public.join_group(uuid,text,boolean),public.delete_group(uuid,text) from public,anon;
grant execute on function public.is_blocked(uuid),public.is_thread_member(uuid,boolean),public.visible_post(uuid),public.thread_from_path(text),public.profile_from_path(text),
 public.request_peep(uuid),public.respond_peep(uuid,boolean),public.start_ping(uuid),public.respond_ping(uuid,boolean),
 public.create_hang(text,text,text,timestamptz),public.create_crew(text,text),public.join_group(uuid,text,boolean),public.delete_group(uuid,text) to authenticated;

-- Files are private. A signed URL is created only after storage RLS approves
-- the requesting user. Ping attachments require active thread membership.
insert into storage.buckets(id,name,public,file_size_limit,allowed_mime_types) values
 ('media','media',false,52428800,array['image/jpeg','image/png','image/webp','video/mp4','video/quicktime']),
 ('avatars','avatars',false,5242880,array['image/jpeg','image/png','image/webp']),
 ('ping-files','ping-files',false,10485760,array['image/jpeg','image/png','image/webp']) on conflict(id) do nothing;
create policy student_files_read on storage.objects for select to authenticated using(bucket_id in ('media','avatars') and public.profile_from_path(name) is not null and not public.is_blocked(public.profile_from_path(name)));
create policy student_files_add on storage.objects for insert to authenticated with check(bucket_id in ('media','avatars') and public.profile_from_path(name)=auth.uid());
create policy student_files_delete on storage.objects for delete to authenticated using(bucket_id in ('media','avatars','ping-files') and public.profile_from_path(name)=auth.uid());
create policy ping_files_read on storage.objects for select to authenticated using(bucket_id='ping-files' and public.is_thread_member(public.thread_from_path(name)) and not public.is_blocked(public.profile_from_path(name)));
create policy ping_files_add on storage.objects for insert to authenticated with check(bucket_id='ping-files' and public.profile_from_path(name)=auth.uid() and public.is_thread_member(public.thread_from_path(name)));

-- Postgres Changes checks RLS for each subscriber.
do $$ declare t text; begin foreach t in array array['posts','post_likes','comments','peeps','thread_members','messages','hangs','hang_members','crews','crew_members','gigs','gig_applications','drops','blocks'] loop
 if not exists(select 1 from pg_publication_tables where pubname='supabase_realtime' and schemaname='public' and tablename=t) then
 execute format('alter publication supabase_realtime add table public.%I',t); end if;
 end loop; end $$;
commit;
