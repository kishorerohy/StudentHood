begin;
create function public.ping_inbox() returns table(
 id uuid,kind text,title text,peer_id uuid,status text,last_read_at timestamptz,
 last_message text,last_at timestamptz,unread_count bigint
) language sql stable security invoker set search_path=public,pg_temp as $$
 select t.id,t.kind,
 case when t.kind='direct' then coalesce((select p.display_name from public.thread_members m join public.profiles p on p.id=m.user_id where m.thread_id=t.id and m.user_id<>auth.uid() limit 1),'Peep') else t.title end,
 case when t.kind='direct' then (select m.user_id from public.thread_members m where m.thread_id=t.id and m.user_id<>auth.uid() limit 1) else null end,
 mine.status,mine.last_read_at,
 (select coalesce(nullif(x.body,''),'Shared a photo') from public.messages x where x.thread_id=t.id order by x.created_at desc,x.id desc limit 1),
 coalesce((select max(x.created_at) from public.messages x where x.thread_id=t.id),t.created_at),
 (select count(*) from public.messages x where x.thread_id=t.id and x.author_id<>auth.uid() and x.created_at>mine.last_read_at)
 from public.threads t join public.thread_members mine on mine.thread_id=t.id and mine.user_id=auth.uid()
 order by 8 desc;
$$;
create function public.mark_ping_read(t uuid) returns void language plpgsql security definer set search_path=public,pg_temp as $$
begin
 if not public.is_thread_member(t) then raise exception 'Ping unavailable'; end if;
 update public.thread_members set last_read_at=now() where thread_id=t and user_id=auth.uid();
end; $$;
-- Limits are checked inside the database; concurrent requests share a lock.
create function public.limit_student_writes() returns trigger language plpgsql security definer set search_path=public,pg_temp as $$
declare actor uuid; field_name text; n integer; cap integer; window_size interval;
begin
 field_name=case tg_table_name when 'posts' then 'author_id' when 'comments' then 'author_id'
 when 'messages' then 'author_id' when 'peeps' then 'requester_id' when 'reports' then 'reporter_id'
 when 'gig_applications' then 'applicant_id' end;
 actor=(to_jsonb(new)->>field_name)::uuid;
 if actor is null or actor<>auth.uid() then raise exception 'Sign in as the author'; end if;
 cap=case tg_table_name when 'posts' then 6 when 'peeps' then 20 when 'reports' then 5 else 30 end;
 window_size=case tg_table_name when 'peeps' then interval '1 hour' when 'reports' then interval '1 day' else interval '1 minute' end;
 perform pg_advisory_xact_lock(hashtextextended(actor::text||':'||tg_table_name,0));
 execute format('select count(*) from public.%I where %I=$1 and created_at>now()-$2',tg_table_name,field_name) into n using actor,window_size;
 if n>=cap then raise exception 'Too many requests. Try again later.'; end if;
 new.created_at=now(); return new;
end; $$;
create trigger rate_posts before insert on public.posts for each row execute function public.limit_student_writes();
create trigger rate_comments before insert on public.comments for each row execute function public.limit_student_writes();
create trigger rate_messages before insert on public.messages for each row execute function public.limit_student_writes();
create trigger rate_peeps before insert on public.peeps for each row execute function public.limit_student_writes();
create trigger rate_reports before insert on public.reports for each row execute function public.limit_student_writes();
create trigger rate_applications before insert on public.gig_applications for each row execute function public.limit_student_writes();
revoke all on function public.ping_inbox(),public.mark_ping_read(uuid),public.limit_student_writes() from public,anon;
grant execute on function public.ping_inbox(),public.mark_ping_read(uuid) to authenticated;
commit;
