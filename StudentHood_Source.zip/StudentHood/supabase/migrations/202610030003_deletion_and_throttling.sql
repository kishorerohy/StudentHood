begin;
-- A server-controlled flag stops new writes during account/file deletion.
-- It is deliberately absent from the profile columns clients may update.
alter table public.profiles add column deleting_at timestamptz;
create function public.account_active() returns boolean language sql stable security definer set search_path=public,pg_temp as $$
 select exists(select 1 from public.profiles where id=auth.uid() and deleting_at is null);
$$;
create function public.guard_student_writes() returns trigger language plpgsql security definer set search_path=public,pg_temp as $$
begin
 if auth.uid() is not null and not public.account_active() then raise exception 'Account deletion is in progress'; end if;
 return new;
end; $$;
do $$ declare t text; begin
 foreach t in array array['profiles','blocks','peeps','posts','post_likes','bookmarks','comments','threads','thread_members','messages','hangs','hang_members','crews','crew_members','gigs','gig_applications','reports','device_tokens'] loop
  execute format('create trigger guard_account before insert or update on public.%I for each row execute function public.guard_student_writes()',t);
 end loop;
end $$;
-- Old access tokens must also be unable to add storage while deletion runs.
drop policy student_files_add on storage.objects;
create policy student_files_add on storage.objects for insert to authenticated with check(bucket_id in ('media','avatars') and public.profile_from_path(name)=auth.uid() and public.account_active());
drop policy ping_files_add on storage.objects;
create policy ping_files_add on storage.objects for insert to authenticated with check(bucket_id='ping-files' and public.profile_from_path(name)=auth.uid() and public.is_thread_member(public.thread_from_path(name)) and public.account_active());

-- Persistent counters cannot be bypassed by deleting and reposting content.
create table public.write_counters (
 user_id uuid references public.profiles on delete cascade,
 action text not null, window_started timestamptz not null default now(),
 count integer not null default 0, primary key(user_id,action)
);
alter table public.write_counters enable row level security;
revoke all on public.write_counters from public,anon,authenticated;
create function public.take_write_slot(action_input text,cap_input integer,seconds_input integer) returns void language plpgsql security definer set search_path=public,pg_temp as $$
declare n integer;
begin
 if not public.account_active() then raise exception 'Sign in first'; end if;
 insert into public.write_counters(user_id,action,window_started,count) values(auth.uid(),action_input,now(),1)
 on conflict(user_id,action) do update set
  count=case when write_counters.window_started<now()-make_interval(secs=>seconds_input) then 1 else write_counters.count+1 end,
  window_started=case when write_counters.window_started<now()-make_interval(secs=>seconds_input) then now() else write_counters.window_started end
 returning count into n;
 if n>cap_input then raise exception 'Too many requests. Try again later.'; end if;
end; $$;
create or replace function public.limit_student_writes() returns trigger language plpgsql security definer set search_path=public,pg_temp as $$
declare actor uuid; field_name text; cap integer; seconds integer;
begin
 field_name=case tg_table_name when 'posts' then 'author_id' when 'comments' then 'author_id'
 when 'messages' then 'author_id' when 'peeps' then 'requester_id' when 'reports' then 'reporter_id'
 when 'gig_applications' then 'applicant_id' end;
 actor=(to_jsonb(new)->>field_name)::uuid;
 if actor is null or actor<>auth.uid() then raise exception 'Sign in as the author'; end if;
 cap=case tg_table_name when 'posts' then 6 when 'peeps' then 20 when 'reports' then 5 else 30 end;
 seconds=case tg_table_name when 'peeps' then 3600 when 'reports' then 86400 else 60 end;
 perform public.take_write_slot(tg_table_name,cap,seconds);
 new.created_at=now();return new;
end; $$;
-- Limit new private requests and group creation too. Invites remain in Ping.
create function public.limit_threads() returns trigger language plpgsql security definer set search_path=public,pg_temp as $$
begin
 perform public.take_write_slot('threads',20,3600);return new;
end; $$;
create trigger rate_threads before insert on public.threads for each row execute function public.limit_threads();
revoke all on function public.account_active(),public.guard_student_writes(),public.take_write_slot(text,integer,integer),public.limit_threads() from public,anon;
grant execute on function public.account_active() to authenticated;
grant all on all tables in schema public to service_role;
commit;
