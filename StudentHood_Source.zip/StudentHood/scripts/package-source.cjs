const fs = require('node:fs');
const path = require('node:path');
const { spawnSync } = require('node:child_process');
const root = path.resolve(__dirname, '..');
const output = path.resolve(process.argv[2] || path.join(root, 'StudentHood_Source.zip'));
const script = `
import os,sys,zipfile
from pathlib import Path
root=Path(sys.argv[1]); output=Path(sys.argv[2]); output.parent.mkdir(parents=True,exist_ok=True)
skip={'node_modules','.git','.expo','dist','native-export','.supabase','ios','android'}
with zipfile.ZipFile(output,'w',zipfile.ZIP_DEFLATED) as archive:
 for directory,folders,files in os.walk(root):
  folders[:]=[name for name in folders if name not in skip]
  for name in sorted(files):
   if (name.startswith('.env') and name!='.env.example') or name.endswith(('.zip','.log','.tsbuildinfo')) or name=='.DS_Store':continue
   file=Path(directory)/name
   archive.write(file,Path('StudentHood')/file.relative_to(root))
print(output)
`;
const result = spawnSync('python3', ['-c', script, root, output], { stdio: 'inherit' });
if (result.status !== 0) process.exit(result.status || 1);
if (!fs.existsSync(output)) throw new Error('Archive was not created');
