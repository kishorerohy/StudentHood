# StudentHood

The approved StudentHood interface implemented as one TypeScript/Expo app for web, iPhone, Android and iPad. Headers use the wordmark only. Pulse, Discover, Scenes, Hangs, Crews, Gigs, Ping, Drops and Profile share a Supabase backend.

**Start with [BUILD_GUIDE.md](BUILD_GUIDE.md).** It explains backend setup, local development, website hosting, native builds and store submission.

## Try the interface

Install Node.js 22.13 or newer, open a terminal in this folder, then run:

```bash
npm ci
npm run web
```

Without backend configuration, the app clearly displays a **sample preview**. Sample changes are stored only on that device. Sample activity counts and the Scene cover are illustrative. Sample data is never inserted into a connected database.

## Connect live accounts

1. Create a fresh Supabase project.
2. Execute **all three** SQL files in `supabase/migrations/`, in filename order.
3. Copy `.env.example` to `.env`; add the project's URL and **publishable key**.
4. Set Auth redirect URLs and deploy the `delete-account` function as described in the guide.
5. Restart Expo. Create two accounts and verify real-time updates between devices.

The publishable key belongs in the client. The service role key and webhook secret belong only in the Supabase server environment.

## Included behavior

| Area           | Implementation                                                                                     |
| -------------- | -------------------------------------------------------------------------------------------------- |
| Accounts       | Email signup, confirmation, password login/reset, profile editing, sign-out, account/file deletion |
| Pulse          | Text/photo posts, likes, comments, bookmarks, campus/city filters, owner deletion                  |
| Scenes         | Video upload/playback, likes/comments, Share Scene links                                           |
| Discover/Peeps | Search the loaded directory, request/accept Peeps, profile views, block/report                     |
| Hangs/Crews    | Create, join/leave, private member chats, owner deletion                                           |
| Gigs           | Post opportunities, apply, owner acceptance/decline, social activity notifications                 |
| Ping           | Direct conversations, request acceptance, Hang/Crew chats, unread counts, photo attachments        |
| Drops          | Nonmessage social activity only; message/request notifications remain in Ping                      |
| Real time      | RLS-protected database subscriptions, reconnect refresh and foreground refresh                     |
| Native push    | Optional secure webhook for Ping messages/requests; requires device credentials and server setup   |
| Layout         | Compact phone view, tablet sidebar, larger web discovery rail, iPad landscape support              |

## Development checks

```bash
npm run typecheck
npm run lint
npm test
npm run build:web
npm run check:native
```

The database tests execute the migrations against PostgreSQL in PGlite with mocked Supabase Auth/Storage schemas. They test permission boundaries and business rules. They do **not** test the hosted Supabase transport, authentication email delivery, push providers, physical devices or signed App Store builds. Complete the two-device acceptance steps in the guide against your actual project.

## Project map

```text
src/app/                       Expo Router screens and email callback
src/components/                Responsive UI, dialogs, Ping and authentication
src/lib/                       Supabase SDK, shared state, sample preview, types
supabase/migrations/           Database, RLS, private storage and write limits
supabase/functions/            Authenticated account deletion and Ping push
assets/                       Approved StudentHood branding and preview images
tests/security.test.cjs        Executable PostgreSQL permission tests
docs/ARCHITECTURE.md            Data flow and implementation limits
BUILD_GUIDE.md                 Setup and release instructions
```

This is a functional first release foundation. Production operation still requires your backend, signing accounts, public domain, support/moderation process and device testing. See the architecture notes for scale and delivery limits.
